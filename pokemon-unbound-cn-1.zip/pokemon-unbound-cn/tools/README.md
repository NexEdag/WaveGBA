# 素材抓取工具

站点默认**优先加载 unboundwiki.com 的真实素材**（宝可梦立绘、道馆攻略截图）；
若你的网络无法访问原站，页面会自动回退到本站内置图片，不会出现空白或裂图。

想让站点**完全离线可用**，请按下面的步骤把原站素材抓到本地。

## 1. 先探测能不能抓

```
python3 tools/download.py --check
```

会抽样 20 个地址并返回响应码：

- `200` —— 可以抓，直接进行第 2 步
- `403` —— 原站拦截了当前网络，换网络（比如手机热点）或过一会儿再试

## 2. 抓取素材

```
python3 tools/download.py
```

共 593 个文件（493 只宝可梦立绘 + 超级形态 + 53 张道馆攻略截图），
保存在 `assets/mirror/` 下，约 3–8 MB。已下载过的会跳过，可中断后重跑。

只想先试几个：

```
python3 tools/download.py --limit 20
```

## 3. 切换为本地镜像

```
python3 tools/offline.py
```

页面里的原站外链会被替换为 `assets/mirror/...` 路径，之后完全离线可用。

随时可以切回在线模式：

```
python3 tools/offline.py --online
```

## 文件说明

| 文件 | 作用 |
|---|---|
| `urls.txt` | 593 条原站素材地址清单（URL + 本地保存路径，Tab 分隔） |
| `download.py` | 抓取脚本（支持 `--check`、`--limit`） |
| `offline.py` | 在线 / 离线切换（支持 `--online`） |

## 自己补充素材

`urls.txt` 每行格式为 `完整URL<Tab>images/xxx.jpg 或 sprites/pokemon/xxx.png`。
追加新行后重新执行第 2、3 步即可。

原站素材命名规律：

- 宝可梦立绘：`/wp-content/assets/sprites/pokemon/{英文名}.png`
  例：`pikachu.png`、`kangaskhan-mega.png`、`aegislash-shield.png`
- 道馆截图：`/wp-content/assets/images/gyms/{馆主名}/{序号}-{描述}.jpg`
  例：`gyms/vega/02-pokemon-unbound-gym-entrance-crater-town-gym.jpg`
