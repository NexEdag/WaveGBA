#!/usr/bin/env python3
"""
从 unboundwiki.com 原站抓取真实素材，保存为本地镜像。

用法（在本站任意目录执行均可）：
    python3 tools/download.py            # 抓取全部素材
    python3 tools/download.py --check    # 只检测可达性，不下载
    python3 tools/download.py --limit 50 # 只抓前 50 个（测试用）

抓完后执行 tools/offline.py 即可把页面切换为纯本地图片，完全离线可用。
"""
import os, sys, time, urllib.request, urllib.error, concurrent.futures as cf

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
MIRROR = os.path.join(ROOT, "assets", "mirror")
LIST = os.path.join(HERE, "urls.txt")

HEADERS = {
    "User-Agent": ("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
                   "(KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36"),
    "Accept": "image/avif,image/webp,image/apng,image/svg+xml,image/*,*/*;q=0.8",
    "Accept-Language": "en-US,en;q=0.9",
    "Referer": "https://unboundwiki.com/",
    "Origin": "https://unboundwiki.com",
    "Sec-Fetch-Dest": "image",
    "Sec-Fetch-Mode": "no-cors",
    "Sec-Fetch-Site": "same-site",
}


def load_list(limit=None):
    items = []
    with open(LIST, encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line or "\t" not in line:
                continue
            url, dest = line.split("\t", 1)
            items.append((url, dest.strip()))
    return items[:limit] if limit else items


def probe(url, tries=2):
    """只探测，不下载"""
    for _ in range(tries):
        try:
            req = urllib.request.Request(url, headers=HEADERS, method="GET")
            with urllib.request.urlopen(req, timeout=20) as r:
                r.read(2048)
                return r.status
        except urllib.error.HTTPError as e:
            return e.code
        except Exception:
            time.sleep(0.4)
    return "ERR"


def fetch(item, tries=3):
    url, dest = item
    out = os.path.join(MIRROR, dest)
    if os.path.exists(out) and os.path.getsize(out) > 200:
        return ("skip", dest)
    os.makedirs(os.path.dirname(out), exist_ok=True)
    for t in range(tries):
        try:
            req = urllib.request.Request(url, headers=HEADERS)
            with urllib.request.urlopen(req, timeout=30) as r:
                data = r.read()
            if len(data) < 200:
                return ("fail", dest)
            with open(out, "wb") as f:
                f.write(data)
            return ("ok", dest)
        except urllib.error.HTTPError as e:
            if e.code == 404:
                return ("404", dest)
        except Exception:
            pass
        time.sleep(0.5 * (t + 1))
    return ("fail", dest)


def main():
    args = sys.argv[1:]
    limit = None
    if "--limit" in args:
        limit = int(args[args.index("--limit") + 1])

    items = load_list(limit)
    print("待处理素材：%d 个" % len(items))

    if "--check" in args:
        t0 = time.time()
        codes = {}
        with cf.ThreadPoolExecutor(12) as ex:
            for i, c in enumerate(ex.map(lambda it: probe(it[0]), items[:20]), 1):
                codes[c] = codes.get(c, 0) + 1
        print("抽样 20 个的响应码：", codes, "(%.0fs)" % (time.time() - t0))
        print("200 = 可以抓取；403 = 被原站拦截，请换网络/换时间再试")
        return

    t0 = time.time()
    stat = {}
    done = 0
    with cf.ThreadPoolExecutor(12) as ex:
        for kind, dest in ex.map(fetch, items):
            stat[kind] = stat.get(kind, 0) + 1
            done += 1
            if done % 100 == 0:
                print("  进度 %d/%d  已存:%d  失败:%d  跳过:%d  (%.0fs)" % (
                    done, len(items), stat.get("ok", 0), stat.get("fail", 0),
                    stat.get("skip", 0), time.time() - t0), flush=True)
    print("完成：新下载 %d，已存在 %d，失败 %d，远端无此文件 %d  耗时 %.0fs" % (
        stat.get("ok", 0), stat.get("skip", 0), stat.get("fail", 0),
        stat.get("404", 0), time.time() - t0))
    print("素材目录：" + MIRROR)
    if stat.get("ok", 0) or stat.get("skip", 0):
        print("下一步：python3 tools/offline.py")


if __name__ == "__main__":
    main()
