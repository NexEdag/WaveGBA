#!/usr/bin/env python3
"""
把页面里的原站外链切换为已下载的本地镜像，使站点完全离线可用。
可重复执行：offline.py 切到本地，online.py（本文件加 --online）切回原站。

用法：
    python3 tools/offline.py            # -> 本地镜像（离线）
    python3 tools/offline.py --online   # -> 原站外链（在线）
"""
import os, sys, io, re

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)

IMG = "https://static.unboundwiki.com/wp-content/assets/images/"
SPR = "https://static.unboundwiki.com/wp-content/assets/sprites/pokemon/"
IMG_L = "assets/mirror/images/"
SPR_L = "assets/mirror/sprites/pokemon/"


def walk():
    for f in sorted(os.listdir(ROOT)):
        if f.endswith(".html"):
            yield os.path.join(ROOT, f)
    p = os.path.join(ROOT, "assets", "pkm.js")
    if os.path.exists(p):
        yield p


def main():
    online = "--online" in sys.argv
    a, b = (IMG_L, IMG) if online else (IMG, IMG_L)
    c, d = (SPR_L, SPR) if online else (SPR, SPR_L)

    n = 0
    for path in walk():
        s = io.open(path, encoding="utf-8").read()
        o = s
        s = s.replace(a, b).replace(c, d)
        if s != o:
            io.open(path, "w", encoding="utf-8").write(s)
            n += 1
    print(("已切回原站外链" if online else "已切换为本地镜像") + "，处理文件 %d 个" % n)
    if not online:
        m = os.path.join(ROOT, "assets", "mirror")
        if not os.path.isdir(m) or not os.listdir(m):
            print("注意：本地镜像为空，请先执行 python3 tools/download.py")


if __name__ == "__main__":
    main()
