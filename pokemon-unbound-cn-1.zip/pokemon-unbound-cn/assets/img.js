/* ============ 图片工具：中文名 → 本地 sprite ============ */
(function () {
  var MAP = {};
  if (window.POKE) {
    window.POKE.forEach(function (p) { MAP[p[1]] = p[0]; });
  }

  /* 称号 / 超级形态 → 基础形态 */
  var ALIAS = {
    '超级诅咒娃娃': '诅咒娃娃',
    '超级大嘴娃': '大嘴娃',
    '超级喷火龙': '喷火龙',
    '超级妙蛙花': '妙蛙花',
    '超级水箭龟': '水箭龟',
    '超级胡地': '胡地',
    '超级耿鬼': '耿鬼',
    '超级沙奈朵': '沙奈朵',
    '超级暴飞龙': '暴飞龙',
    '超级巨金怪': '巨金怪',
    '超级拉帝亚斯': '拉帝亚斯',
    '超级拉帝欧斯': '拉帝欧斯',
    '超级蜥蜴王': '蜥蜴王',
    '超级火焰鸡': '火焰鸡',
    '超级巨沼怪': '巨沼怪',
    '超级比雕': '比雕',
    '超级大针蜂': '大针蜂',
    '超级凯罗斯': '凯罗斯',
    '超级赫拉克罗斯': '赫拉克罗斯',
    '超级黑鲁加': '黑鲁加',
    '超级班基拉斯': '班基拉斯',
    '超级巨钳螳螂': '巨钳螳螂',
    '超级大钢蛇': '大钢蛇',
    '超级电龙': '电龙',
    '超级恰雷姆': '恰雷姆',
    '超级雷电兽': '雷电兽',
    '超级巨牙鲨': '巨牙鲨',
    '超级喷火驼': '喷火驼',
    '超级七夕青鸟': '七夕青鸟',
    '超级阿勃梭鲁': '阿勃梭鲁',
    '超级冰鬼护': '冰鬼护',
    '超级暴鲤龙': '暴鲤龙',
    '超级化石翼龙': '化石翼龙',
    '超级袋兽': '袋兽',
    '超级长耳兔': '长耳兔',
    '超级艾路雷朵': '艾路雷朵',
    '超级波士可多拉': '波士可多拉',
    '超级勾魂眼': '勾魂眼',
    '超级差不多娃娃': '差不多娃娃',
    '超级呆壳兽': '呆壳兽',
    '超级大竺葵': '大竺葵',
    '超级蒂安希': '蒂安希',
    '超级超梦': '超梦',
    '超级烈空坐': '烈空坐',
    '原始盖欧卡': '盖欧卡',
    '原始固拉多': '固拉多'
  };

  function id(name) {
    if (!name) return 0;
    if (MAP[name]) return MAP[name];
    if (ALIAS[name] && MAP[ALIAS[name]]) return MAP[ALIAS[name]];
    /* 去掉「超级」「原始」前缀再试 */
    var s = name.replace(/^(超级|原始|阿罗拉|伽勒尔|洗翠|帕底亚)/, '');
    if (MAP[s]) return MAP[s];
    return 0;
  }

  /* 返回 img 标签：原站素材优先，失败回退本地，仍失败则隐藏 */
  window.pkmnImg = function (name, cls) {
    var n = (window.PIDX && window.PIDX[name]) || id(name);
    var c = cls || 'pkmn';
    if (!n) return '';
    var L = 'assets/img/pkm/' + n + '.png';
    var R = window.pkmRemote ? window.pkmRemote(name) : '';
    if (!R) return '<img class="' + c + '" loading="lazy" src="' + L + '" alt="' + name +
      '" onerror="this.style.visibility=\'hidden\'">';
    return '<img class="' + c + '" loading="lazy" src="' + R + '" alt="' + name +
      '" onerror="this.onerror=null;this.src=\'' + L + '\'">';
  };

  /* 返回图片地址；用于 CSS 背景 */
  window.pkmnSrc = function (name) {
    var n = (window.PIDX && window.PIDX[name]) || id(name);
    return n ? 'assets/img/pkm/' + n + '.png' : '';
  };
})();
