/* ============ 站点公共导航 / 页脚（对齐原站结构） ============ */
(function () {
  /* 侧边主菜单 —— 与原站 Menu 顺序一致 */
  var MENU = [
    { t: 'Wiki 首页', h: 'index.html' },
    { t: '攻略', h: 'walkthrough.html' },
    { t: '全部宝可梦', h: 'pokemon.html' },
    { t: '物品', h: 'items.html' },
    { t: '地点', h: 'locations.html' },
    { t: '任务', h: 'missions.html' },
    { t: '道馆', h: 'gyms.html' },
    { t: '进化道具', h: 'evolution-items.html' },
    { t: '超级石', h: 'mega-stones.html' },
    { t: '技能机与秘传机', h: 'tm-hm.html' },
    { t: '基格尔德细胞', h: 'zygarde-cells.html' },
    { t: '携带道具', h: 'held-items.html' },
    { t: 'Z 纯晶', h: 'z-crystals.html' },
    { t: '重要道具', h: 'key-items.html' },
    { t: '招式教学', h: 'move-tutors.html' },
    { t: '团体战巢穴', h: 'raid-dens.html' },
    { t: '传说宝可梦', h: 'legendary.html' },
    { t: '额外与支线内容', h: 'extras.html' },
    { t: '杂项信息', h: 'misc.html' }
  ];

  /* 兄弟 Wiki（原站 All Wikis 下拉） */
  var ALL_WIKIS = [
    { t: '宝可梦 Unbound Wiki', h: 'index.html', on: true },
    { t: 'Elden Ring', ext: true },
    { t: 'Dead Cells', ext: true },
    { t: 'Diablo 4 (D4)', ext: true }
  ];

  /* 浏览 Wiki —— 带原站分类角标 */
  var BROWSE = [
    { t: '攻略', h: 'walkthrough.html', c: '攻略' },
    { t: '游戏机制', h: 'game-mechanics.html', c: '' },
    { t: '全部宝可梦', h: 'pokemon.html', c: '' },
    { t: '所有任务', h: 'missions.html', c: '任务' },
    { t: '物品', h: 'items.html', c: '物品' },
    { t: '地点', h: 'locations.html', c: '地点' },
    { t: '道馆', h: 'gyms.html', c: '' },
    { t: '团体战巢穴', h: 'raid-dens.html', c: '地点' },
    { t: '超级石', h: 'mega-stones.html', c: '物品' },
    { t: 'Z 纯晶', h: 'z-crystals.html', c: '物品' },
    { t: '进化道具', h: 'evolution-items.html', c: '物品' },
    { t: '重要道具', h: 'key-items.html', c: '物品' },
    { t: '四天王与冠军', h: 'elite-four.html', c: '' },
    { t: '基格尔德细胞', h: 'zygarde-cells.html', c: '物品' },
    { t: '所有树果', h: 'berries.html', c: '物品' },
    { t: '所有精灵球', h: 'pokeballs.html', c: '物品' },
    { t: '隐藏道具', h: 'hidden-items.html', c: '物品' },
    { t: '挖掘道具', h: 'mining-items.html', c: '物品' },
    { t: '携带道具', h: 'held-items.html', c: '物品' },
    { t: '有用 NPC', h: 'npcs.html', c: '' },
    { t: '招式教学', h: 'move-tutors.html', c: '' },
    { t: '玛格诺利亚咖啡馆', h: 'magnolia-cafe.html', c: '地点' },
    { t: '传说宝可梦', h: 'legendary.html', c: '' },
    { t: '额外与支线内容', h: 'extras.html', c: '' },
    { t: '杂项信息', h: 'misc.html', c: '' }
  ];

  window.WIKI_NAV = { menu: MENU, browse: BROWSE };

  function cur() {
    return location.pathname.split('/').pop() || 'index.html';
  }

  function mount() {
    var c = cur();

    /* ---- 侧边抽屉菜单（原站 Menu / Close） ---- */
    var drawer =
      '<div class="drawer" id="drawer" aria-hidden="true">' +
        '<div class="drawer-head">' +
          '<span class="dtitle">菜单</span>' +
          '<button class="dclose" id="dclose" aria-label="关闭">✕</button>' +
        '</div>' +
        '<div class="drawer-body">' +
          '<div class="dgroup">' +
            '<div class="dlabel">当前 Wiki</div>' +
            '<a class="dwiki on" href="index.html">宝可梦 Unbound Wiki</a>' +
          '</div>' +
          '<div class="dgroup">' +
            '<div class="dlabel">所有 Wiki</div>' +
            ALL_WIKIS.map(function (w) {
              return w.ext
                ? '<span class="dwiki muted">' + w.t + '</span>'
                : '<a class="dwiki' + (w.on ? ' on' : '') + '" href="' + w.h + '">' + w.t + '</a>';
            }).join('') +
          '</div>' +
          '<div class="dgroup">' +
            '<div class="dlabel">栏目</div>' +
            MENU.map(function (n) {
              return '<a class="ditem' + (n.h === c ? ' on' : '') + '" href="' + n.h + '">' + n.t + '</a>';
            }).join('') +
          '</div>' +
        '</div>' +
      '</div>' +
      '<div class="dbackdrop" id="dbackdrop"></div>';

    /* ---- 顶栏 ---- */
    var head =
      '<header class="topbar"><div class="topbar-inner">' +
        '<button class="burger" id="burger" aria-label="打开菜单">' +
          '<span></span><span></span><span></span><em>菜单</em></button>' +
        '<a class="logo" href="index.html">' +
          '<span class="ball"></span>' +
          '<span class="lname">宝可梦 Unbound Wiki<small>Pokémon Unbound Wiki · 中文版</small></span>' +
        '</a>' +
        '<div class="topright">' +
          '<a class="tlink" href="walkthrough.html">攻略</a>' +
          '<a class="tlink" href="pokemon.html">图鉴</a>' +
          '<button class="themebtn" id="themebtn" aria-label="切换深色/浅色">◐</button>' +
        '</div>' +
      '</div></header>';

    /* ---- 页脚（原站 General / Legals / Useful + 免责声明） ---- */
    var foot =
      '<footer><div class="foot-inner">' +
        '<div class="fcol"><h4>常规</h4>' +
          '<a href="index.html">首页</a>' +
          '<a href="misc.html#about">关于</a>' +
          '<a href="misc.html#contact">联系</a>' +
          '<a href="misc.html#sitemap">站点地图</a></div>' +
        '<div class="fcol"><h4>法律</h4>' +
          '<a href="misc.html#terms">条款与条件</a>' +
          '<a href="misc.html#privacy">隐私政策</a></div>' +
        '<div class="fcol"><h4>实用入口</h4>' +
          '<a href="walkthrough.html">攻略</a>' +
          '<a href="pokemon.html">全部宝可梦</a>' +
          '<a href="locations.html">全部地点</a>' +
          '<a href="misc.html#categories">分类</a></div>' +
      '</div>' +
      '<div class="foot-bot">本站点与 Nintendo、Pokémon、Game Freak 或任何其他相关项目及财产无关，亦未获得其认可。</div>' +
      '</footer>' +
      '<button class="backtop" id="backtop" aria-label="回到顶部">↑</button>';

    document.body.insertAdjacentHTML('afterbegin', drawer);
    document.body.insertAdjacentHTML('afterbegin', head);
    document.body.insertAdjacentHTML('beforeend', foot);

    var open = function (v) {
      document.getElementById('drawer').classList.toggle('open', v);
      document.getElementById('dbackdrop').classList.toggle('open', v);
      document.getElementById('drawer').setAttribute('aria-hidden', v ? 'false' : 'true');
      document.body.style.overflow = v ? 'hidden' : '';
    };
    document.getElementById('burger').onclick = function () { open(true); };
    document.getElementById('dclose').onclick = function () { open(false); };
    document.getElementById('dbackdrop').onclick = function () { open(false); };
    document.addEventListener('keydown', function (e) {
      if (e.key === 'Escape') open(false);
    });

    /* ---- 深色模式：跟随系统，可手动切换并记忆 ---- */
    var root = document.documentElement;
    var KEY = 'uw-theme';
    var saved = null;
    try { saved = localStorage.getItem(KEY); } catch (e) {}
    function apply(t) {
      if (t === 'dark') root.setAttribute('data-theme', 'dark');
      else root.removeAttribute('data-theme');
      var b = document.getElementById('themebtn');
      if (b) b.textContent = t === 'dark' ? '☀' : '◐';
    }
    if (saved) apply(saved);
    else if (window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches) apply('dark');
    var tb2 = document.getElementById('themebtn');
    if (tb2) tb2.onclick = function () {
      var now = root.getAttribute('data-theme') === 'dark' ? 'light' : 'dark';
      apply(now);
      try { localStorage.setItem(KEY, now); } catch (e) {}
    };

    var bt = document.getElementById('backtop');
    bt.onclick = function () { window.scrollTo({ top: 0, behavior: 'smooth' }); };
    window.addEventListener('scroll', function () {
      bt.classList.toggle('show', window.scrollY > 400);
    }, { passive: true });

    /* 图片通道指示：探测原站素材是否可达，并在顶栏显示状态 */
    if (window.pkmRemote) {
      var badge = document.createElement('span');
      badge.className = 'srcbadge wait';
      badge.textContent = '图片检测中';
      document.querySelector('.topbar-inner').appendChild(badge);

      var probe = new Image();
      var url = window.pkmRemote('皮卡丘');
      probe.onload = function () {
        badge.className = 'srcbadge ok';
        badge.textContent = '原站素材';
        badge.title = '正在加载 unboundwiki.com 的真实素材';
        document.body.classList.add('cdn-ok');
      };
      probe.onerror = function () {
        badge.className = 'srcbadge off';
        badge.textContent = '本地素材';
        badge.title = '无法访问原站，已自动回退到本站内置图片';
        document.body.classList.add('cdn-off');
      };
      probe.src = url;
      setTimeout(function () {
        if (!probe.complete || probe.naturalWidth === 0) {
          badge.className = 'srcbadge off';
          badge.textContent = '本地素材';
          badge.title = '无法访问原站，已自动回退到本站内置图片';
        }
      }, 9000);
    }
  }

  /* 首页 "分类" 统计块 */
  window.renderCats = function (id) {
    var box = document.getElementById(id);
    if (!box) return;
    var CATS = [
      ['967', '图鉴 页面', 'pokemon.html', 'vivill-woods'],
      ['104', '地点 页面', 'locations.html', 'frozen-heights'],
      ['129', '技能机与秘传机 页面', 'tm-hm.html', 'crystal-peak'],
      ['84', '任务 页面', 'missions.html', 'great-desert']
    ];
    box.className = 'catgrid';
    box.innerHTML = CATS.map(function (x) {
      return '<a class="cat" href="' + x[2] + '">' +
        '<div class="pic"><img src="assets/img/scene/' + x[3] + '.jpg" alt=""><span class="n">' + x[0] + '</span></div>' +
        '<div class="tx"><b>' + x[1].replace(' 页面', '') + '</b><span>' + x[0] + ' 页面</span></div></a>';
    }).join('');
  };

  /* 首页 "浏览 Wiki" 列表（带原站分类角标） */
  window.renderBrowse = function (id) {
    var box = document.getElementById(id);
    if (!box) return;
    box.className = 'grid c3';
    box.innerHTML = BROWSE.map(function (n) {
      return '<a class="card" href="' + n.h + '">' +
        '<div class="t">' + n.t + '</div>' +
        (n.c ? '<span class="tag">' + n.c + '</span>' : '') +
        '</a>';
    }).join('');
  };

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', mount);
  } else { mount(); }
})();
