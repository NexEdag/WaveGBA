/* 道具 中文名 → 本地图标文件名（图标缺失时自动隐藏，不影响排版） */
window.IIDX = {
  /* 精灵球 */
  "精灵球":"poke-ball","超级球":"great-ball","高级球":"ultra-ball","大师球":"master-ball",
  "先机球":"quick-ball","重复球":"repeat-ball","计时球":"timer-ball","巢穴球":"nest-ball",
  "等级球":"level-ball","月亮球":"moon-ball","友友球":"friend-ball","沉重球":"heavy-ball",
  "速度球":"fast-ball","净网球":"net-ball","潜水球":"dive-ball","黑暗球":"dusk-ball",
  "诱饵球":"lure-ball","治疗球":"heal-ball","豪华球":"luxury-ball","狩猎球":"safari-ball",
  "究极球":"beast-ball","公园球":"park-ball","纪念球":"cherish-ball","梦境球":"dream-ball",
  "甜蜜球":"love-ball","贵重球":"premier-ball","竞赛球":"sport-ball",
  /* 进化石 */
  "日之石":"sun-stone","月之石":"moon-stone","火之石":"fire-stone","雷之石":"thunder-stone",
  "水之石":"water-stone","叶之石":"leaf-stone","冰之石":"ice-stone","光之石":"shiny-stone",
  "暗之石":"dusk-stone","觉醒之石":"dawn-stone","不变之石":"everstone","圆之石":"oval-stone",
  /* 携带 / 交换进化 */
  "金属外套":"metal-coat","王者之证":"kings-rock","龙鳞":"dragon-scale",
  "深海之牙":"deep-sea-tooth","深海之鳞":"deep-sea-scale","升级数据":"upgrade",
  "可疑补丁":"dubious-disc","保护罩":"protector","锐利之爪":"razor-claw",
  "电力增幅器":"electirizer","岩浆增幅器":"magmarizer","冥界之衣":"reaper-cloth",
  "棱镜鳞片":"prism-scale","心之鳞片":"heart-scale","神奇糖果":"rare-candy",
  /* Z 纯晶 */
  "一般Z":"normalium-z","火Z":"firium-z","水Z":"waterium-z","电Z":"electrium-z",
  "草Z":"grassium-z","冰Z":"icium-z","格斗Z":"fightinium-z","毒Z":"poisonium-z",
  "地面Z":"groundium-z","飞行Z":"flyinium-z","超能Z":"psychinium-z","虫Z":"buginium-z",
  "岩石Z":"rockinium-z","幽灵Z":"ghostinium-z","龙Z":"dragonium-z","恶Z":"darkinium-z",
  "钢Z":"steelinium-z","仙子Z":"fairium-z",
  /* 对战携带道具 */
  "生命宝珠":"life-orb","气势披带":"focus-sash","气势头带":"focus-band",
  "专爱头巾":"choice-band","专爱眼镜":"choice-specs","专爱围巾":"choice-scarf",
  "突击背心":"assault-vest","进化辉石":"eviolite","剩饭":"leftovers",
  /* 树果 */
  "文柚果":"sitrus-berry","木子果":"oran-berry","樱桃果":"cheri-berry","桃桃果":"pecha-berry",
  "莓莓果":"rawst-berry","苦莓果":"chesto-berry","番荔果":"aspear-berry","巧可果":"persim-berry",
  /* 贵重 / 其他 */
  "金珠":"nugget","大金珠":"big-nugget","银色王冠":"bottle-cap","金色王冠":"gold-bottle-cap",
  "经验糖果S":"exp-candy-s","经验糖果M":"exp-candy-m","经验糖果L":"exp-candy-l",
  "经验糖果XL":"exp-candy-xl",
  /* 超级石 */
  "妙蛙花石":"venusaurite","喷火龙石 X":"charizardite-x","喷火龙石 Y":"charizardite-y",
  "水箭龟石":"blastoisinite","大针蜂石":"beedrillite","比雕石":"pidgeotite",
  "胡地石":"alakazite","呆壳兽石":"slowbronite","耿鬼石":"gengarite","袋兽石":"kangaskhanite",
  "凯罗斯石":"pinsirite","暴鲤龙石":"gyaradosite","化石翼龙石":"aerodactylite",
  "超梦石 X":"mewtwonite-x","超梦石 Y":"mewtwonite-y","电龙石":"ampharosite","大钢蛇石":"steelixite",
  "巨钳螳螂石":"scizorite","赫拉克罗斯石":"heracronite","黑鲁加石":"houndoominite",
  "班基拉斯石":"tyranitarite","蜥蜴王石":"sceptilite","火焰鸡石":"blazikenite",
  "巨沼怪石":"swampertite","沙奈朵石":"gardevoirite","勾魂眼石":"sablenite",
  "大嘴娃石":"mawilite","波士可多拉石":"aggronite","恰雷姆石":"medichamite",
  "雷电兽石":"manectricite","巨牙鲨石":"sharpedonite","喷火驼石":"cameruptite",
  "七夕青鸟石":"altarianite","诅咒娃娃石":"banettite","阿勃梭鲁石":"absolite",
  "冰鬼护石":"glalitite","暴飞龙石":"salamencite","巨金怪石":"metagrossite",
  "拉帝亚斯石":"latiasite","拉帝欧斯石":"latiosite","长耳兔石":"lopunnite",
  "艾路雷朵石":"galladite","差不多娃娃石":"audinite","蒂安希石":"diancite"
};

/* 自动给表格里的道具名称单元格补上图标 */
window.enhanceItems = function (root) {
  var list = (root || document).querySelectorAll('td.name, td.iname');
  Array.prototype.forEach.call(list, function (td) {
    if (td.getAttribute('data-ic')) return;
    td.setAttribute('data-ic', '1');
    var n = td.textContent.trim();
    var f = (window.IIDX || {})[n];
    if (!f) return;
    td.innerHTML = '<div class="cell"><img class="ic" src="assets/img/item/' + f +
      '.png" alt="" loading="lazy" onerror="this.style.visibility=\'hidden\'"><b>' + n + '</b></div>';
  });
};
document.addEventListener('DOMContentLoaded', function () { window.enhanceItems(); });
