/* WaveGBA -- PC frontend for Windows (Win32 + GDI + waveOut)
 * Author: Edag
 *
 * Same core and same libretro_frontend.c as the SDL2/Linux and Android
 * builds, so behaviour is identical everywhere. This one deliberately has
 * **no third-party dependency** (no SDL2) so it can be cross-compiled with
 * plain mingw-w64 and shipped as a single .exe.
 *
 * Build (mingw-w64):
 *   x86_64-w64-mingw32-gcc -O2 -municode -mwindows -o WaveGBA.exe \
 *       wavegba_win32.c <core sources> -lwinmm -lgdi32 -lcomdlg32 -lshell32
 *
 * Run:  WaveGBA.exe <rom.gba>      (or drag a .gba onto the window)
 *
 * Keys:
 *   Arrows / WASD   d-pad          Z/J  B      X/K  A
 *   Q/U  L          E/I  R         Enter  Start      Shift/Backspace  Select
 *   Space  pause    1..6  speed 0.5x 1x 1.5x 2x 3x 4x
 *   F1 help  F5 save state  F7 load state  F2 battery save  F3 reset
 *   Esc  quit
 */
#include <windows.h>
#include <commdlg.h>
#include <shellapi.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>

#include "libretro_frontend.h"

#define BASE_FPS      59.7275
#define MAX_CATCHUP   6
#define MUTE_ABOVE    2.0
#define WIN_SCALE     3

static const double SPEEDS[] = {0.5, 1.0, 1.5, 2.0, 3.0, 4.0};

static HWND      g_hwnd = NULL;
static emu_frontend_t *g_emu = NULL;

static char g_rom_path[MAX_PATH];
static char g_save_dir[MAX_PATH];
static char g_rom_name[256];

static double g_speed = 1.0;
static int    g_paused = 0;
static int    g_quit = 0;
static int    g_show_help = 0;
static double g_fps = 0.0;

/* ------------------------------------------------------------------ paths */
static const char *base_name(const char *p)
{
   const char *s = strrchr(p, '/');
   const char *b = strrchr(p, '\\');
   if (b && (!s || b > s)) s = b;
   return s ? s + 1 : p;
}

static void strip_ext(char *dst, size_t n, const char *name)
{
   char *dot;
   snprintf(dst, n, "%s", name);
   dot = strrchr(dst, '.');
   if (dot) *dot = '\0';
   for (char *c = dst; *c; c++)
      if (!((*c >= 'A' && *c <= 'Z') || (*c >= 'a' && *c <= 'z') ||
            (*c >= '0' && *c <= '9') || *c == '_' || *c == '-')) *c = '_';
}

/* ------------------------------------------------------------------- load */
static uint8_t *read_file(const char *path, size_t *size)
{
   FILE *f = fopen(path, "rb");
   uint8_t *buf; long n;
   if (!f) return NULL;
   fseek(f, 0, SEEK_END); n = ftell(f); fseek(f, 0, SEEK_SET);
   buf = (uint8_t *)malloc(n > 0 ? n : 1);
   if (!buf) { fclose(f); return NULL; }
   if (fread(buf, 1, n, f) != (size_t)n) { fclose(f); free(buf); return NULL; }
   fclose(f);
   *size = (size_t)n;
   return buf;
}

static int load_rom(const char *path)
{
   size_t size = 0;
   uint8_t *data = read_file(path, &size);
   emu_config_t cfg;
   int ok;

   if (!data) { fprintf(stderr, "cannot read: %s\n", path); return 0; }
   if (size < 0x200) { fprintf(stderr, "not a GBA rom: %s\n", path); free(data); return 0; }

   emu_destroy(&g_emu);
   memset(&cfg, 0, sizeof(cfg));
   cfg.save_dir = g_save_dir;
   strip_ext(g_rom_name, sizeof(g_rom_name), base_name(path));
   cfg.rom_name = g_rom_name;

   g_emu = emu_init(data, size, &cfg);
   free(data);
   ok = g_emu != NULL;
   if (ok) {
      snprintf(g_rom_path, sizeof(g_rom_path), "%s", path);
      emu_load_battery(g_emu);
      printf("loaded: %s (%zu bytes)\n", path, size);
   }
   return ok;
}

/* ------------------------------------------------------------------ audio */
/* waveOut with two half-buffers; the callback keeps whichever is free fed. */
#define AUDIO_BUFS   2
#define AUDIO_FRAMES 1024
static HWAVEOUT g_wout = NULL;
static WAVEHDR  g_hdr[AUDIO_BUFS];
static int16_t  g_pcm[AUDIO_BUFS][AUDIO_FRAMES * 2];

static void audio_feed(void)
{
   static int16_t tmp[4096];
   int i;
   if (!g_wout || !g_emu) return;

   for (i = 0; i < AUDIO_BUFS; i++) {
      if (!(g_hdr[i].dwFlags & WHDR_INQUEUE)) {
         int got, out = 0;
         double sp = g_speed;

         if (g_paused || sp >= MUTE_ABOVE) {
            memset(g_pcm[i], 0, sizeof(g_pcm[i]));
            out = AUDIO_FRAMES;
         } else {
            got = emu_audio_drain(g_emu, tmp, AUDIO_FRAMES * 2);
            if (got <= 0) return;
            /* resample so pitch stays constant: sp>1 decimates, sp<1 repeats */
            for (double idx = 0; idx < got && out < AUDIO_FRAMES; idx += sp) {
               int s = (int)idx;
               g_pcm[i][out * 2]     = tmp[s * 2];
               g_pcm[i][out * 2 + 1] = tmp[s * 2 + 1];
               out++;
            }
            if (out < AUDIO_FRAMES)
               memset(&g_pcm[i][out * 2], 0, (AUDIO_FRAMES - out) * 4);
         }

         g_hdr[i].lpData         = (LPSTR)g_pcm[i];
         g_hdr[i].dwBufferLength = AUDIO_FRAMES * 4;
         g_hdr[i].dwFlags        = 0;
         waveOutPrepareHeader(g_wout, &g_hdr[i], sizeof(WAVEHDR));
         waveOutWrite(g_wout, &g_hdr[i], sizeof(WAVEHDR));
      }
   }
}

static void audio_init(void)
{
   WAVEFORMATEX wf;
   memset(&wf, 0, sizeof(wf));
   wf.wFormatTag      = WAVE_FORMAT_PCM;
   wf.nChannels       = 2;
   wf.nSamplesPerSec  = GBA_SAMPLE_RATE;
   wf.wBitsPerSample  = 16;
   wf.nBlockAlign     = 4;
   wf.nAvgBytesPerSec = GBA_SAMPLE_RATE * 4;

   if (waveOutOpen(&g_wout, WAVE_MAPPER, &wf, 0, 0, CALLBACK_NULL) != MMSYSERR_NOERROR) {
      fprintf(stderr, "audio unavailable\n");
      g_wout = NULL;
   }
}

static void audio_shutdown(void)
{
   if (!g_wout) return;
   waveOutReset(g_wout);
   for (int i = 0; i < AUDIO_BUFS; i++)
      waveOutUnprepareHeader(g_wout, &g_hdr[i], sizeof(WAVEHDR));
   waveOutClose(g_wout);
   g_wout = NULL;
}

/* ------------------------------------------------------------------ input */
static uint32_t poll_keys(void)
{
   uint32_t m = 0;
   if (GetAsyncKeyState(VK_LEFT)  & 0x8000 || GetAsyncKeyState('A') & 0x8000) m |= GBA_BTN_LEFT;
   if (GetAsyncKeyState(VK_RIGHT) & 0x8000 || GetAsyncKeyState('D') & 0x8000) m |= GBA_BTN_RIGHT;
   if (GetAsyncKeyState(VK_UP)    & 0x8000 || GetAsyncKeyState('W') & 0x8000) m |= GBA_BTN_UP;
   if (GetAsyncKeyState(VK_DOWN)  & 0x8000 || GetAsyncKeyState('S') & 0x8000) m |= GBA_BTN_DOWN;
   if (GetAsyncKeyState('Z') & 0x8000 || GetAsyncKeyState('J') & 0x8000) m |= GBA_BTN_B;
   if (GetAsyncKeyState('X') & 0x8000 || GetAsyncKeyState('K') & 0x8000) m |= GBA_BTN_A;
   if (GetAsyncKeyState('Q') & 0x8000 || GetAsyncKeyState('U') & 0x8000) m |= GBA_BTN_L;
   if (GetAsyncKeyState('E') & 0x8000 || GetAsyncKeyState('I') & 0x8000) m |= GBA_BTN_R;
   if (GetAsyncKeyState(VK_SHIFT) & 0x8000 || GetAsyncKeyState(VK_BACK) & 0x8000)
      m |= GBA_BTN_SELECT;
   if (GetAsyncKeyState(VK_RETURN) & 0x8000) m |= GBA_BTN_START;
   return m;
}

/* ----------------------------------------------------------------- render */
/* StretchDIBits with BI_BITFIELDS and 5-6-5 masks takes the core's RGB565
 * framebuffer with zero conversion. */
static void present(HDC hdc, int cw, int ch)
{
   const uint16_t *fb = emu_get_framebuffer(g_emu);
   BITMAPINFOHEADER bi;
   /* Masks must follow the header when biCompression == BI_BITFIELDS. */
   struct { BITMAPINFOHEADER bmi; DWORD r, g, b; } hdr;
   int scale, w, h, x, y;
   HBRUSH black;
   RECT r;

   memset(&hdr, 0, sizeof(hdr));
   bi.biSize        = sizeof(BITMAPINFOHEADER);
   bi.biWidth       = GBA_SCREEN_W;
   bi.biHeight      = -GBA_SCREEN_H;      /* negative = top-down */
   bi.biPlanes      = 1;
   bi.biBitCount    = 16;
   bi.biCompression = BI_BITFIELDS;
   hdr.bmi          = bi;
   hdr.r = 0x0000F800;
   hdr.g = 0x000007E0;
   hdr.b = 0x0000001F;

   scale = cw / GBA_SCREEN_W;
   if (ch / GBA_SCREEN_H < scale) scale = ch / GBA_SCREEN_H;
   if (scale < 1) scale = 1;
   w = GBA_SCREEN_W * scale;
   h = GBA_SCREEN_H * scale;
   x = (cw - w) / 2;
   y = (ch - h) / 2;

   r.left = 0; r.top = 0; r.right = cw; r.bottom = ch;
   black = CreateSolidBrush(RGB(0, 0, 0));
   FillRect(hdc, &r, black);
   DeleteObject(black);

   if (fb)
      StretchDIBits(hdc, x, y, w, h, 0, 0, GBA_SCREEN_W, GBA_SCREEN_H,
                    fb, (BITMAPINFO *)&hdr, DIB_RGB_COLORS, SRCCOPY);

   if (g_show_help) {
      RECT p = {10, 10, 430, 190};
      HBRUSH b = CreateSolidBrush(RGB(20, 20, 30));
      FillRect(hdc, &p, b);
      DeleteObject(b);
      FrameRect(hdc, &p, (HBRUSH)GetStockObject(WHITE_BRUSH));
      SetBkMode(hdc, TRANSPARENT);
      SetTextColor(hdc, RGB(255, 255, 255));
      DrawTextA(hdc,
         "WaveGBA\r\n"
         "方向键/WASD  十字键      Z  B      X  A\r\n"
         "Q/U  L       E/I  R      回车 开始   Shift 选择\r\n"
         "空格 暂停    1-6 倍速(0.5x-4x)\r\n"
         "F5 存档   F7 读档   F2 保存进度   F3 重置\r\n"
         "F1 关闭本帮助      Esc 退出",
         -1, &p, DT_LEFT | DT_WORDBREAK);
   }
}

/* ------------------------------------------------------------------- wnd */
static LRESULT CALLBACK wnd_proc(HWND hw, UINT msg, WPARAM wp, LPARAM lp)
{
   switch (msg) {
   case WM_DESTROY:
      g_quit = 1;
      PostQuitMessage(0);
      return 0;
   case WM_ERASEBKGND:
      return 1;
   case WM_PAINT: {
      PAINTSTRUCT ps;
      RECT cr;
      HDC hdc = BeginPaint(hw, &ps);
      GetClientRect(hw, &cr);
      if (g_emu) present(hdc, cr.right, cr.bottom);
      EndPaint(hw, &ps);
      return 0;
   }
   case WM_DROPFILES: {
      char path[MAX_PATH];
      if (DragQueryFileA((HDROP)wp, 0, path, MAX_PATH) && load_rom(path)) {
         char title[300];
         snprintf(title, sizeof(title), "WaveGBA - %s", g_rom_name);
         SetWindowTextA(hw, title);
         InvalidateRect(hw, NULL, FALSE);
      }
      DragFinish((HDROP)wp);
      return 0;
   }
   case WM_KEYDOWN: {
      int k = (int)wp;
      if (k == VK_ESCAPE) { g_quit = 1; DestroyWindow(hw); return 0; }
      if (k == VK_F1) g_show_help = !g_show_help;
      if (k == VK_SPACE) g_paused = !g_paused;
      if (k >= '1' && k <= '6') {
         g_speed = SPEEDS[k - '1'];
         printf("speed %.1fx%s\n", g_speed, g_speed >= MUTE_ABOVE ? " (muted)" : "");
      }
      if (k == VK_F5) { if (emu_save_state(g_emu, 0) == 0) printf("state saved\n"); }
      if (k == VK_F7) { if (emu_load_state(g_emu, 0) == 0) printf("state loaded\n"); }
      if (k == VK_F2) { if (emu_save_battery(g_emu) == 0) printf("battery saved\n"); }
      if (k == VK_F3) { emu_reset(g_emu); printf("reset\n"); }
      InvalidateRect(hw, NULL, FALSE);
      return 0;
   }
   }
   return DefWindowProcA(hw, msg, wp, lp);
}

/* ------------------------------------------------------------------- main */
int main(int argc, char **argv)
{
   const char *rom = (argc > 1) ? argv[1] : NULL;
   int bench_frames = 0;
   WNDCLASSA wc;
   double accum = 0.0;
   DWORD last, fps_timer;
   int fps_frames = 0;
   MSG msg;

   printf("WaveGBA -- %s %s\n", emu_get_core_name(), emu_get_core_version());
   printf("author: Edag\n\n");

   {
      const char *appdata = getenv("APPDATA");
      if (appdata) snprintf(g_save_dir, sizeof(g_save_dir), "%s\\WaveGBA", appdata);
      else         snprintf(g_save_dir, sizeof(g_save_dir), ".");
      CreateDirectoryA(g_save_dir, NULL);
   }

   for (int i = 1; i < argc; i++)
      if (!strcmp(argv[i], "--frames") && i + 1 < argc) bench_frames = atoi(argv[i + 1]);

   if (!rom) {
      /* No ROM on the command line: offer a file picker. */
      OPENFILENAMEA ofn;
      char path[MAX_PATH] = "";
      memset(&ofn, 0, sizeof(ofn));
      ofn.lStructSize = sizeof(ofn);
      ofn.lpstrFilter = "GBA ROM\0*.gba\0All files\0*.*\0";
      ofn.lpstrFile   = path;
      ofn.nMaxFile    = MAX_PATH;
      ofn.Flags       = OFN_FILEMUSTEXIST | OFN_HIDEREADONLY;
      if (!GetOpenFileNameA(&ofn)) {
         printf("no rom selected\n");
         return 1;
      }
      rom = path;
   }

   if (!load_rom(rom)) return 1;

   /* Headless self-test: drive the core and report, no window. */
   if (bench_frames > 0) {
      struct { LARGE_INTEGER s, e, f; } t;
      const uint16_t *fb;
      int lit = 0, i;
      long audio = 0;
      static int16_t tmp[8192];
      double secs, fps;

      QueryPerformanceFrequency(&t.f);
      QueryPerformanceCounter(&t.s);
      for (i = 0; i < bench_frames; i++) {
         emu_run_frame(g_emu, 0);
         audio += emu_audio_drain(g_emu, tmp, 4096);
      }
      QueryPerformanceCounter(&t.e);
      secs = (double)(t.e.QuadPart - t.s.QuadPart) / (double)t.f.QuadPart;
      fps  = bench_frames / secs;
      fb   = emu_get_framebuffer(g_emu);
      for (i = 0; i < GBA_SCREEN_W * GBA_SCREEN_H; i++) if (fb[i]) lit++;
      printf("frames        : %d\n", bench_frames);
      printf("elapsed       : %.3f s\n", secs);
      printf("fps           : %.1f (%.1fx realtime)\n", fps, fps / BASE_FPS);
      printf("nonblack px   : %d / %d\n", lit, GBA_SCREEN_W * GBA_SCREEN_H);
      printf("audio frames  : %ld\n", audio);
      printf("save state    : %s\n", emu_save_state(g_emu, 0) == 0 ? "ok" : "FAILED");
      printf("load state    : %s\n", emu_load_state(g_emu, 0) == 0 ? "ok" : "FAILED");
      emu_destroy(&g_emu);
      return (lit > 0 && audio > 0) ? 0 : 2;
   }

   memset(&wc, 0, sizeof(wc));
   wc.lpfnWndProc   = wnd_proc;
   wc.hInstance     = GetModuleHandleA(NULL);
   wc.lpszClassName = "WaveGBA";
   wc.hCursor       = LoadCursorA(NULL, IDC_ARROW);
   wc.hIcon         = LoadIconA(NULL, IDI_APPLICATION);
   if (!RegisterClassA(&wc)) { fprintf(stderr, "RegisterClass failed\n"); return 1; }

   {
      char title[300];
      snprintf(title, sizeof(title), "WaveGBA - %s", g_rom_name);
      g_hwnd = CreateWindowExA(0, "WaveGBA", title,
                               WS_OVERLAPPEDWINDOW | WS_VISIBLE,
                               CW_USEDEFAULT, CW_USEDEFAULT,
                               GBA_SCREEN_W * WIN_SCALE + 16,
                               GBA_SCREEN_H * WIN_SCALE + 39,
                               NULL, NULL, wc.hInstance, NULL);
   }
   if (!g_hwnd) { fprintf(stderr, "CreateWindow failed\n"); return 1; }
   DragAcceptFiles(g_hwnd, TRUE);

   audio_init();

   last = fps_timer = GetTickCount();

   while (!g_quit) {
      DWORD now;
      double elapsed;

      while (PeekMessageA(&msg, NULL, 0, 0, PM_REMOVE)) {
         if (msg.message == WM_QUIT) { g_quit = 1; break; }
         TranslateMessage(&msg);
         DispatchMessageA(&msg);
      }
      if (g_quit) break;

      now = GetTickCount();
      elapsed = (now - last) / 1000.0;
      last = now;
      if (elapsed > 0.25) elapsed = 0.25;     /* do not avalanche after a stall */

      if (!g_paused) {
         int frames, i;
         uint32_t mask = poll_keys();
         accum += elapsed * BASE_FPS * g_speed;
         frames = (int)accum;
         accum -= frames;
         if (frames > MAX_CATCHUP) frames = MAX_CATCHUP;
         for (i = 0; i < frames; i++)
            emu_run_frame(g_emu, mask);
      }

      audio_feed();
      InvalidateRect(g_hwnd, NULL, FALSE);

      fps_frames++;
      if (now - fps_timer >= 1000) {
         char title[300];
         g_fps = fps_frames * 1000.0 / (now - fps_timer);
         fps_frames = 0; fps_timer = now;
         snprintf(title, sizeof(title), "WaveGBA - %s - %.0f fps - %.1fx",
                  g_rom_name, g_fps, g_speed);
         SetWindowTextA(g_hwnd, title);
      }
      Sleep(1);
   }

   emu_save_battery(g_emu);
   emu_destroy(&g_emu);
   audio_shutdown();
   return 0;
}
