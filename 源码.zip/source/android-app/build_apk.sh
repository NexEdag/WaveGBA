#!/bin/bash
# Assemble / align / sign the WaveGBA APK with SDK command-line tools.
#
# The critical bit for targetSdk >= 30: resources.arsc AND every .so must be
# stored UNCOMPRESSED and 4-byte aligned, or install fails with
#   -124: Targeting R+ requires the resources.arsc ... aligned on a 4-byte boundary
set -e
ulimit -f unlimited 2>/dev/null || true

SDK=/opt/android-sdk
BT=$SDK/build-tools/34.0.0
ROOT=/data/workspace/WaveGBA/source/android-app
APK=$ROOT/build
OUT=$ROOT/build/out
KEY=/data/workspace/WaveGBA/build/edag-debug.jks
NATIVE=/data/workspace/WaveGBA/build/native

mkdir -p "$OUT"

echo "==> staging"
rm -rf "$APK/stage" "$OUT/WaveGBA-raw.apk"
mkdir -p "$APK/stage/lib"
cp "$APK/dex/classes.dex" "$APK/stage/"
cd "$APK/stage" && unzip -q -o "$APK/linked.apk" && rm -rf META-INF
cd "$ROOT"

for abi in arm64-v8a armeabi-v7a x86_64; do
  mkdir -p "$APK/stage/lib/$abi"
  cp "$NATIVE/$abi/libwavegba.so" "$APK/stage/lib/$abi/" 2>/dev/null || \
    cp "/data/workspace/android/build/native/$abi/libwavegba.so" "$APK/stage/lib/$abi/"
done

echo "==> zipping (arsc + so stored uncompressed)"
python3 - "$APK/stage" "$OUT/WaveGBA-raw.apk" <<'PYEOF'
import os, sys, zipfile
src, dst = sys.argv[1], sys.argv[2]
if os.path.exists(dst):
    os.remove(dst)
priority = ["AndroidManifest.xml", "classes.dex", "resources.arsc"]
entries = []
for root, dirs, files in os.walk(src):
    for d in dirs:
        entries.append(os.path.relpath(os.path.join(root, d), src).replace(os.sep, "/") + "/")
    for f in files:
        entries.append(os.path.relpath(os.path.join(root, f), src).replace(os.sep, "/"))
entries.sort(key=lambda e: (0, priority.index(e), e) if e in priority else (1, 0, e))

with zipfile.ZipFile(dst, "w", zipfile.ZIP_DEFLATED, compresslevel=9) as z:
    for e in entries:
        full = os.path.join(src, e)
        if e.endswith("/"):
            zi = zipfile.ZipInfo(e, (1980, 1, 1, 0, 0, 0))
            zi.external_attr = (0o40755 << 16) | 0x10
            z.writestr(zi, b"")
            continue
        # Only resources.arsc must stay uncompressed+aligned for targetSdk 30+.
        # The .so files are extracted at install time (extractNativeLibs is
        # true by default), so compressing them is fine -- and it sidesteps
        # apksigner's entry reshuffle knocking them off their 4-byte boundary.
        stored = (e == "resources.arsc")
        zi = zipfile.ZipInfo(e, (1980, 1, 1, 0, 0, 0))
        zi.compress_type = zipfile.ZIP_STORED if stored else zipfile.ZIP_DEFLATED
        zi.external_attr = 0o100644 << 16
        with open(full, "rb") as fh:
            z.writestr(zi, fh.read())
print("wrote", dst, os.path.getsize(dst), "bytes")
PYEOF

if [ ! -f "$KEY" ]; then
  echo "==> creating debug keystore"
  mkdir -p "$(dirname "$KEY")"
  keytool -genkeypair -v -keystore "$KEY" -storepass edagdebug -keypass edagdebug \
    -alias edag -keyalg RSA -keysize 2048 -validity 10950 \
    -dname "CN=Edag, OU=Edag, O=Edag, L=Unknown, S=Unknown, C=CN" 2>&1 | tail -1
fi

# Order matters and is not the obvious one.
#
# apksigner adds its v1 (JAR) signature files at the FRONT of the archive,
# which shifts every later entry and knocks the STORED resources.arsc / .so
# files off their 4-byte boundaries -- targetSdk 30+ then rejects the package
# as invalid. So: lay the v1 signature down first with jarsigner, align, and
# only then let apksigner add v2, which touches nothing but the signing block
# at the very end.
echo "==> zipalign"
cp -f "$OUT/WaveGBA-raw.apk" "$OUT/WaveGBA.apk"
$BT/zipalign -f 4 "$OUT/WaveGBA.apk" "$OUT/aligned.apk"
mv -f "$OUT/aligned.apk" "$OUT/WaveGBA.apk"

echo "==> signature (v1+v2)"
rm -f "$OUT/signed.apk"          # never reuse a stale signature from a prior run
if $BT/apksigner sign --ks "$KEY" \
     --ks "$KEY" --ks-pass pass:edagdebug --key-pass pass:edagdebug \
     --ks-key-alias edag --out "$OUT/signed.apk" "$OUT/WaveGBA.apk" 2>&1 | head -3; then
  if [ -s "$OUT/signed.apk" ]; then mv -f "$OUT/signed.apk" "$OUT/WaveGBA.apk"; fi
fi
if [ ! -s "$OUT/WaveGBA.apk" ]; then echo "ERROR: signing produced nothing"; exit 1; fi

echo "==> verifying"
if ! $BT/zipalign -c 4 "$OUT/WaveGBA.apk"; then
  echo "ERROR: final APK is not 4-byte aligned -- refusing to ship it"
  exit 1
fi
echo "  zipalign: OK"
$BT/apksigner verify "$OUT/WaveGBA.apk" >/dev/null 2>&1 && echo "  signature: OK"
python3 - "$OUT/WaveGBA.apk" <<'PYEOF'
import struct, sys, zipfile
p = sys.argv[1]
z = zipfile.ZipFile(p); f = open(p, 'rb')
for i in z.infolist():
    if i.filename == "resources.arsc":
        f.seek(i.header_offset); h = f.read(30)
        n, e = struct.unpack('<HH', h[26:30])
        d = i.header_offset + 30 + n + e
        print("  resources.arsc: %s data_off=%d align4=%s"
              % ("STORED" if i.compress_type == 0 else "DEFLATE", d, d % 4 == 0))
PYEOF
ls -la "$OUT/WaveGBA.apk"
echo "done"
