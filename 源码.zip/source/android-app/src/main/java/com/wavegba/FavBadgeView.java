package com.wavegba;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.util.AttributeSet;
import android.view.View;

/**
 * Favourite badge: a filled star on a round chip.
 *
 * This is a top-level class rather than a nested one so the layout can name
 * it plainly. A nested class has to be referenced as Outer$Inner in XML,
 * which this build's aapt2 rejects as not well-formed.
 *
 * The star is drawn from its ten vertices rather than set as a "★" glyph on
 * a TextView. Two reasons: the glyph's shape depends on whichever font the
 * device substitutes, so it can come out lopsided or hollow; and a shape
 * drawable cannot express a star at all.
 *
 * The chip carries a shadow and a hairline rim so it reads as sitting on top
 * of the cover art instead of printed into it. Covers are arbitrary captured
 * frames, so there is no guaranteed contrast behind the badge to rely on.
 */
public final class FavBadgeView extends View {

    private final Paint shadow = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint plate  = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint rim    = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint star   = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Path  sp     = new Path();

    public FavBadgeView(Context c) { this(c, null); }

    /** The constructor inflation calls. */
    public FavBadgeView(Context c, AttributeSet a) {
        super(c, a);
        plate.setStyle(Paint.Style.FILL);
        rim.setStyle(Paint.Style.STROKE);
        star.setStyle(Paint.Style.FILL);
    }

    private float dp(float v) {
        return v * getResources().getDisplayMetrics().density;
    }

    @Override
    protected void onMeasure(int wSpec, int hSpec) {
        int w = (int) dp(22);
        setMeasuredDimension(w, w);
    }

    @Override
    protected void onDraw(Canvas c) {
        float w = getWidth(), h = getHeight();
        if (w <= 0 || h <= 0) return;

        float cx = w / 2f, cy = h / 2f;
        float rad = Math.min(w, h) / 2f - dp(2);

        // Shadow first, so the plate covers the half that overlaps it.
        shadow.setColor(0x66000000);
        c.drawCircle(cx + dp(0.5f), cy + dp(1f), rad, shadow);

        plate.setColor(Theme.accent());
        c.drawCircle(cx, cy, rad, plate);

        rim.setStrokeWidth(dp(1));
        rim.setColor(0x59FFFFFF);
        c.drawCircle(cx, cy, rad - dp(0.5f), rim);

        // Ten vertices alternating between the point radius and the valley
        // radius. The valley radius is what makes it read as a star rather
        // than a pentagon.
        float R = rad * 0.62f;
        float r = R * 0.42f;
        sp.rewind();
        for (int i = 0; i < 10; i++) {
            double ang = -Math.PI / 2 + i * Math.PI / 5;
            float rr = (i % 2 == 0) ? R : r;
            float x = cx + (float) (Math.cos(ang) * rr);
            // Nudged down a hair: a star's visual centre sits below its
            // bounding box centre because the mass is in the lower arms.
            float y = cy + (float) (Math.sin(ang) * rr) + dp(0.5f);
            if (i == 0) sp.moveTo(x, y); else sp.lineTo(x, y);
        }
        sp.close();
        // The theme background, not a fixed dark: on a light accent the chip
        // is light and a dark glyph is right, and the badge follows the
        // accent colour the user picked.
        star.setColor(Theme.bg());
        c.drawPath(sp, star);
    }
}
