package com.wavegba;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;

/** A floating fast-forward button: tap it to switch the emulation speed,
 *  tap again to go back to the previous one.
 *
 *  Long-press (over 350ms) and drag to reposition; the spot is remembered in
 *  SharedPreferences so it stays where the user put it. A drag never counts
 *  as a tap, so moving the button cannot flip the speed by accident. */
public class FastForwardButton extends View {

    public interface Listener {
        void onFastForward(boolean active);
    }

    private static final long DRAG_THRESHOLD_MS = 350;

    private Listener listener;
    private boolean active = false;
    private boolean dragging = false;

    /** Centre position in pixels; null until the first layout. */
    private float cx = -1, cy = -1;
    private float radius;
    private float downX, downY, downTime;
    private float startCx, startCy;

    private final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint fillOn = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint rim = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint glyph = new Paint(Paint.ANTI_ALIAS_FLAG);

    public FastForwardButton(Context c) { super(c); init(); }
    public FastForwardButton(Context c, AttributeSet a) { super(c, a); init(); }
    public FastForwardButton(Context c, AttributeSet a, int s) { super(c, a, s); init(); }

    private void init() {
        fill.setStyle(Paint.Style.FILL);
        fill.setARGB(70, 23, 23, 28);
        fillOn.setStyle(Paint.Style.FILL);
        fillOn.setARGB(190, 168, 85, 247);        // violet when held
        rim.setStyle(Paint.Style.STROKE);
        rim.setARGB(90, 255, 255, 255);
        glyph.setStyle(Paint.Style.FILL_AND_STROKE);
        glyph.setARGB(235, 255, 255, 255);
        glyph.setStrokeCap(Paint.Cap.ROUND);
    }

    public void setListener(Listener l) { listener = l; }

    /** Reflect an externally chosen speed without firing the listener, so
     *  the button and the speed menu cannot get out of sync. */
    public void setActive(boolean on) {
        if (active == on) return;
        active = on;
        invalidate();
    }

    public boolean isActive() { return active; }

    /** Restore a saved spot, in fractions of the view size. */
    public void restorePos(float fx, float fy) {
        if (fx >= 0f && fy >= 0f) { cx = fx; cy = fy; stored = true; }
    }

    private boolean stored = false;

    @Override
    protected void onSizeChanged(int w, int h, int ow, int oh) {
        radius = Math.min(w, h) * 0.055f;
        if (radius < 22) radius = 22;
        if (radius > 42) radius = 42;
        glyph.setStrokeWidth(Math.max(2.5f, radius * 0.16f));

        if (cx < 0 || !stored) {
            // Default: upper-right area, clear of the menu button.
            cx = 0.88f; cy = 0.16f; stored = true;
        }
        clampTo(w, h);
    }

    private void clampTo(int w, int h) {
        float r = radius + 4;
        float x = cx <= 1.0f ? cx * w : cx;      // tolerate px or fraction
        float y = cy <= 1.0f ? cy * h : cy;
        x = Math.max(r, Math.min(w - r, x));
        y = Math.max(r, Math.min(h - r, y));
        cx = x; cy = y;
    }

    private void fire(boolean on) {
        if (active == on) return;
        active = on;
        invalidate();
        if (listener != null) listener.onFastForward(on);
    }

    @Override
    public boolean onTouchEvent(MotionEvent e) {
        switch (e.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                if (Math.hypot(e.getX() - cx, e.getY() - cy) > radius * 1.6f) return false;
                downX = e.getX(); downY = e.getY(); downTime = e.getEventTime();
                startCx = cx; startCy = cy;
                dragging = false;
                return true;

            case MotionEvent.ACTION_MOVE:
                if (!dragging && e.getEventTime() - downTime > DRAG_THRESHOLD_MS)
                    dragging = true;
                if (dragging) {
                    cx = startCx + (e.getX() - downX);
                    cy = startCy + (e.getY() - downY);
                    clampTo(getWidth(), getHeight());
                    invalidate();
                }
                return true;

            case MotionEvent.ACTION_UP:
            case MotionEvent.ACTION_CANCEL:
                if (dragging) {
                    savePos();                    // a drag is a move, not a tap
                    dragging = false;
                } else {
                    fire(!active);                // tap toggles the speed
                }
                return true;
        }
        return false;
    }

    private void savePos() {
        int w = getWidth(), h = getHeight();
        if (w <= 0 || h <= 0) return;
        getContext().getSharedPreferences("wavegba", Context.MODE_PRIVATE).edit()
                .putFloat("ff_x", cx / w)
                .putFloat("ff_y", cy / h)
                .apply();
    }

    @Override
    protected void onDraw(Canvas c) {
        if (cx < 0) return;
        float r = radius;
        RectF box = new RectF(cx - r, cy - r, cx + r, cy + r);
        c.drawOval(box, active ? fillOn : fill);
        c.drawOval(box, rim);

        // Double chevron pointing right.
        float d = r * 0.26f;
        float hgt = r * 0.46f;
        for (int i = 0; i < 2; i++) {
            float ox = cx - d + i * d * 1.35f;
            c.drawLine(ox - d * 0.45f, cy - hgt, ox + d * 0.45f, cy, glyph);
            c.drawLine(ox + d * 0.45f, cy, ox - d * 0.45f, cy + hgt, glyph);
        }
    }
}
