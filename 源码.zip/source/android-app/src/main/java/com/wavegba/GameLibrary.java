package com.wavegba;

import android.graphics.Bitmap;
import android.util.Log;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.File;
import java.io.FileOutputStream;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

/** The game library: one entry per ROM the user has added.
 *
 *  Persisted as a small JSON file next to the save directory rather than a
 *  SQLite database -- the collection is a few dozen items at most, and a
 *  plain file is far easier to inspect and repair by hand.
 *
 *  A GBA ROM carries no embedded artwork, so a newly added game gets a
 *  generated placeholder cover; the real one is captured from the last
 *  on-screen frame when the player leaves the game. */
public final class GameLibrary {

    private static final String TAG = "WaveGBA.library";
    private static final String FILE = "games.json";
    private static final String COVER_DIR = "Covers";
    private static final String ROM_DIR = "ROMs";

    /** One library entry. */
    public static final class Entry {
        public String id;           // stable key, derived from the ROM title
        public String title;
        public String uri;          // content:// or file:// the ROM came from
        public String code;         // 4-char game code, e.g. AZLE
        public String origin;       // uri it was imported from (informational)
        public boolean named;       // true once the player supplied a name
        public boolean favorite;    // starred: sorted first, filterable
        public long favAt;          // ms epoch when starred, 0 if not
        public int seq;             // display number, 1..N, never reused
        public long added;          // ms epoch
        public long lastPlayed;     // ms epoch, 0 = never
        public boolean hasCover;

        public String coverName() { return safe(id) + ".png"; }

        static String safe(String s) {
            return s.replaceAll("[^A-Za-z0-9_.-]", "_");
        }
    }

    private final File root;      // WaveGBA/
    private final List<Entry> entries = new ArrayList<Entry>();
    /** Next display number. Monotonic: deleting #2 must not renumber #3. */
    private int nextSeq = 1;

    /** Star or unstar an entry. */
    public void setFavorite(String id, boolean fav) {
        Entry e = find(id);
        if (e == null) return;
        e.favorite = fav;
        e.favAt = fav ? System.currentTimeMillis() : 0L;
        save();
    }

    public int favoriteCount() {
        int n = 0;
        for (Entry e : entries) if (e.favorite) n++;
        return n;
    }

    /** Entries ordered for display: starred first, then by last played.
     *
     *  Starred games form their own block rather than merely sorting ahead
     *  within the played order -- otherwise a starred game untouched for
     *  months still sits below everything recent and starring it looks like
     *  it did nothing. */
    public List<Entry> sorted() {
        List<Entry> out = new ArrayList<Entry>(entries);
        java.util.Collections.sort(out, new Comparator<Entry>() {
            public int compare(Entry a, Entry b) {
                if (a.favorite != b.favorite) return a.favorite ? -1 : 1;
                if (a.favorite && a.favAt != b.favAt)
                    return a.favAt > b.favAt ? -1 : 1;
                long la = a.lastPlayed, lb = b.lastPlayed;
                if (la != lb) return la > lb ? -1 : 1;
                return Long.valueOf(a.added).compareTo(b.added);
            }
        });
        return out;
    }

    /** Starred entries only, most recently starred first. */
    public List<Entry> favorites() {
        List<Entry> out = new ArrayList<Entry>();
        for (Entry e : entries) if (e.favorite) out.add(e);
        java.util.Collections.sort(out, new Comparator<Entry>() {
            public int compare(Entry a, Entry b) {
                return a.favAt > b.favAt ? -1 : (a.favAt < b.favAt ? 1 : 0);
            }
        });
        return out;
    }

    /** The WaveGBA folder that holds Save/, Covers/ and games.json.
     *
     *  saveDir is .../WaveGBA/Save, so its parent is already the root --
     *  appending "WaveGBA" again would put the library in
     *  .../WaveGBA/WaveGBA and silently orphan every entry. */
    public static File rootFor(File saveDir) {
        if (saveDir != null) {
            File parent = saveDir.getParentFile();
            if (parent != null && "Save".equalsIgnoreCase(saveDir.getName())) return parent;
            if (parent != null) return parent;
            return saveDir;
        }
        return new File(android.os.Environment.getExternalStorageDirectory(), "WaveGBA");
    }

    public GameLibrary(File saveDir, File rootOverride) {
        root = (rootOverride != null) ? rootOverride : rootFor(saveDir);
        ensureTree();
        load();
        migrateLegacy();
        backfillSeq();
    }

    public GameLibrary(File saveDir) {
        this(saveDir, null);
    }

    /** Create the whole tree up front so the folder is never half-built --
     *  ROMs/ used to appear only after the first import, which made an empty
     *  library look like a bug. */
    private void ensureTree() {
        root.mkdirs();
        for (String d : new String[]{COVER_DIR, ROM_DIR, "Save", "Macros", "Screenshots"})
            new File(root, d).mkdirs();
    }

    public File coversDir() { return new File(root, COVER_DIR); }

    public File root() { return root; }

    /** How many ROMs we hold a copy of. */
    public int romCount() {
        File[] fs = romsDir().listFiles((d, n) -> n.endsWith(".gba"));
        return fs == null ? 0 : fs.length;
    }

    /** Imported ROMs live here, owned by the app.
     *
     *  Keeping a private copy is what makes the library reliable: a
     *  content:// URI from a file manager can stop resolving at any time --
     *  the provider may not grant a persistable permission, the file may be
     *  moved, or the app that served it may be uninstalled. A file we own
     *  cannot go stale. */
    public File romsDir() {
        File d = new File(root, ROM_DIR);
        d.mkdirs();
        return d;
    }

    /** A file:// uri pointing at our own copy, or null if it is not there. */
    public String localUriFor(String id, String fallback) {
        File f = new File(romsDir(), Entry.safe(id) + ".gba");
        if (f.exists() && f.length() > 0) return "file://" + f.getAbsolutePath();
        return fallback;
    }

    public List<Entry> all() {
        // Most recently played first; never-played entries go last by name.
        List<Entry> out = new ArrayList<Entry>(entries);
        java.util.Collections.sort(out, new Comparator<Entry>() {
            public int compare(Entry a, Entry b) {
                if (a.lastPlayed != b.lastPlayed) return Long.valueOf(b.lastPlayed).compareTo(a.lastPlayed);
                return a.title.compareToIgnoreCase(b.title);
            }
        });
        return out;
    }

    /** "3 · Pokemon Silver" -- the number makes identically named ROMs
     *  distinguishable and guarantees a non-empty label. */
    public static String label(Entry e) {
        if (e == null) return "rom";
        String t = (e.title == null || e.title.trim().isEmpty()) ? "rom" : e.title.trim();
        return e.seq > 0 ? (e.seq + " · " + t) : t;
    }

    /** Record a name chosen by the player. Once set, nothing derived from
     *  the ROM may replace it. */
    public Entry name(String id, String title) {
        Entry e = find(id);
        if (e == null || title == null) return e;
        String t = title.trim();
        if (t.isEmpty()) return e;
        e.title = t;
        e.named = true;
        save();
        return e;
    }

    public Entry find(String id) {
        for (Entry e : entries) if (e.id.equals(id)) return e;
        return null;
    }

    /** Add or refresh a ROM.
     *
     *  id and title are deliberately separate: id must stay tied to the save
     *  name (so saves keep working if the display name changes), while title
     *  is what the home screen shows -- the ROM's file name.
     *  Re-putting an existing id also refreshes its title, so switching to
     *  file-name display automatically fixes up older entries. */
    public Entry put(String id, String title, String uri, String code) {
        return put(id, title, uri, code, null);
    }

    /* ------------------------------------------------------- 文件名获取 */

    /** Best-effort file name for a uri.
     *
     *  Getting a real name out of a content:// uri is unreliable: some
     *  providers only answer an explicit projection, others never expose
     *  _display_name at all, and the last path segment is often a numeric id
     *  or our own generated name. So try every route and reject anything
     *  that looks like it came from us. */
    public static String fileNameOf(android.content.Context ctx, android.net.Uri uri) {
        if (uri == null) return null;
        String name = null;

        if ("file".equals(uri.getScheme()) && uri.getPath() != null) {
            name = new File(uri.getPath()).getName();
        } else {
            android.database.Cursor c = null;
            try {
                // Explicit projection: a null projection often omits the
                // display-name column entirely.
                c = ctx.getContentResolver().query(
                        uri, new String[]{"_display_name"}, null, null, null);
                if (c != null && c.moveToFirst()) {
                    int i = c.getColumnIndex("_display_name");
                    if (i >= 0) name = c.getString(i);
                }
            } catch (Throwable ignored) {
            } finally {
                if (c != null) try { c.close(); } catch (Throwable ignored2) { }
            }

            if (name == null || name.trim().isEmpty()) {
                // Some pickers answer a full query even when the projection
                // above fails.
                android.database.Cursor c2 = null;
                try {
                    c2 = ctx.getContentResolver().query(uri, null, null, null, null);
                    if (c2 != null && c2.moveToFirst()) {
                        for (String col : new String[]{"_display_name", "_data", "name"}) {
                            int i = c2.getColumnIndex(col);
                            if (i < 0) continue;
                            String v = c2.getString(i);
                            if (v != null && !v.trim().isEmpty()) { name = v; break; }
                        }
                    }
                } catch (Throwable ignored) {
                } finally {
                    if (c2 != null) try { c2.close(); } catch (Throwable ignored2) { }
                }
            }
        }

        if (name == null || name.trim().isEmpty()) {
            String seg = uri.getLastPathSegment();
            if (seg != null) name = seg;
        }
        if (name == null) return null;

        name = name.trim();
        int slash = name.lastIndexOf('/');
        if (slash >= 0) name = name.substring(slash + 1);
        int dot = name.lastIndexOf('.');
        if (dot > 0) name = name.substring(0, dot);
        name = name.trim();

        if (name.isEmpty() || looksGenerated(name)) return null;

        // A bare numeric id or a raw uri fragment (e.g. "msf:48213",
        // "document/47") is what some pickers hand back as the last segment.
        // It is not a name a player would recognise, so prefer the cart title.
        if (name.matches("^\\d+$")) return null;
        if (name.indexOf(':') >= 0) return null;
        if (name.matches("^[0-9a-fA-F]{16,}$")) return null;

        return name;
    }

    /** Cart title from the ROM header, e.g. "POKEMON EMER".
     *  Not as nice as a file name, but infinitely better than "rom". */
    public static String cartTitle(byte[] rom) {
        if (rom == null || rom.length < 0xAC) return null;
        StringBuilder sb = new StringBuilder();
        for (int i = 0xA0; i < 0xAC; i++) {
            int c = rom[i] & 0xFF;
            if (c >= 0x20 && c < 0x7F) sb.append((char) c);
        }
        String t = sb.toString().trim();
        return t.isEmpty() ? null : t;
    }

    /** Matches the id we generate from a ROM's CRC, e.g. "ga65334ff".
     *  Such a string is never a real file name, so we refuse to display it. */
    public static boolean looksGenerated(String s) {
        if (s == null) return true;
        String t = s.trim();
        if (t.isEmpty()) return true;
        return t.matches("^g[0-9a-fA-F]{8}$");
    }

    public Entry put(String id, String title, String uri, String code, String origin) {
        id = Entry.safe(id);
        Entry e = find(id);
        if (e == null) {
            e = new Entry();
            e.id = id;
            e.added = System.currentTimeMillis();
            e.lastPlayed = 0;
            entries.add(e);
        }
        if (e.seq <= 0) e.seq = nextSeq++;
        // A title of null/blank/generated must not overwrite a real file name:
        // opening an imported ROM hands us the copy's path (gaXXXXXXXX.gba),
        // which would otherwise replace the name the user actually sees.
        // A name the player typed is final: nothing derived from the ROM may
        // replace it, ever. This is the guard that keeps a hand-written name
        // from reverting to the cart title on the next launch.
        if (e.named) {
            /* keep the chosen name */
        } else if (!looksGenerated(title)) {
            e.title = title;
        } else if (e.title == null || e.title.trim().isEmpty() || looksGenerated(e.title)) {
            e.title = "rom";
        }
        e.uri = uri;
        e.code = code;
        if (origin != null && !origin.isEmpty()) e.origin = origin;
        return e;
    }

    public void touch(String id, long when) {
        Entry e = find(id);
        if (e != null) { e.lastPlayed = when; save(); }
    }

    public void remove(String id) {
        Entry e = find(id);
        if (e == null) return;
        entries.remove(e);
        File c = new File(coversDir(), e.coverName());
        if (c.exists()) c.delete();
        save();
    }

    /** Store the captured frame as this game's cover. */
    public boolean saveCover(String id, Bitmap bmp) {
        if (bmp == null) return false;
        File out = new File(coversDir(), Entry.safe(id) + ".png");
        boolean ok = false;
        try {
            FileOutputStream fos = new FileOutputStream(out);
            bmp.compress(Bitmap.CompressFormat.PNG, 90, fos);
            fos.flush();
            fos.close();
            ok = out.exists() && out.length() > 0;
        } catch (Throwable t) {
            Log.e(TAG, "封面保存失败", t);
        }
        Entry e = find(id);
        if (e != null) e.hasCover = ok;
        return ok;
    }

    public File coverFile(Entry e) { return new File(coversDir(), e.coverName()); }

    /* ------------------------------------------------------------ storage */

    private File file() { return new File(root, FILE); }

    /** Number any entry that predates seq, oldest first so the order reads
     *  naturally. Written back immediately so the numbers stay put. */
    private void backfillSeq() {
        boolean dirty = false;
        List<Entry> need = new ArrayList<Entry>();
        for (Entry e : entries) if (e.seq <= 0) need.add(e);
        if (need.isEmpty()) return;
        java.util.Collections.sort(need, new Comparator<Entry>() {
            public int compare(Entry a, Entry b) {
                if (a.added != b.added) return Long.valueOf(a.added).compareTo(b.added);
                return a.title.compareToIgnoreCase(b.title);
            }
        });
        for (Entry e : need) { e.seq = nextSeq++; dirty = true; }
        if (dirty) save();
    }

    /** Early builds put the library one level too deep (.../WaveGBA/WaveGBA).
     *  Adopt any entries found there so a user's existing games survive. */
    private void migrateLegacy() {
        File legacy = new File(root, "WaveGBA");
        File src = new File(legacy, FILE);
        if (!src.exists()) return;
        try {
            File dst = file();
            if (dst.exists() && dst.length() > 0) return;
            java.io.FileInputStream in = new java.io.FileInputStream(src);
            java.io.FileOutputStream out = new java.io.FileOutputStream(dst);
            byte[] buf = new byte[1 << 16];
            int n;
            while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
            in.close();
            out.close();

            File lc = new File(legacy, COVER_DIR);
            if (lc.isDirectory()) {
                File[] cs = lc.listFiles();
                if (cs != null) for (File c : cs) {
                    File to = new File(coversDir(), c.getName());
                    if (to.exists()) continue;
                    java.io.FileInputStream ci = new java.io.FileInputStream(c);
                    java.io.FileOutputStream co = new java.io.FileOutputStream(to);
                    while ((n = ci.read(buf)) > 0) co.write(buf, 0, n);
                    ci.close();
                    co.close();
                }
            }
            Log.i(TAG, "已从旧路径迁移游戏库 " + src);
            load();
        } catch (Throwable t) {
            Log.w(TAG, "迁移旧游戏库失败", t);
        }
    }

    private void load() {
        entries.clear();
        File f = file();
        if (!f.exists()) return;
        try {
            byte[] raw = new byte[(int) f.length()];
            java.io.FileInputStream in = new java.io.FileInputStream(f);
            int got = in.read(raw);
            in.close();
            String text = new String(raw, 0, Math.max(0, got), "UTF-8");
            JSONArray arr = new JSONArray(text);
            java.util.LinkedHashMap<String, Entry> byId = new java.util.LinkedHashMap<>();
            for (int i = 0; i < arr.length(); i++) {
                JSONObject o = arr.getJSONObject(i);
                Entry e = new Entry();
                e.id = o.optString("id", "");
                e.title = o.optString("title", e.id);
                e.uri = o.optString("uri", "");
                e.code = o.optString("code", "");
                e.added = o.optLong("added", 0);
                e.lastPlayed = o.optLong("lastPlayed", 0);
                e.seq = o.optInt("seq", 0);
                e.origin = o.optString("origin", "");
                e.named = o.optBoolean("named", false);
                e.favorite = o.optBoolean("favorite", false);
                e.favAt = o.optLong("favAt", 0L);
                if (e.id.length() == 0) continue;
                e.hasCover = new File(coversDir(), e.coverName()).exists();
                // Last write wins: keeps the newest uri/title for a given id.
                Entry prev = byId.get(e.id);
                if (prev != null) entries.remove(prev);
                byId.put(e.id, e);
                entries.add(e);
                if (e.seq >= nextSeq) nextSeq = e.seq + 1;
            }
        } catch (Throwable t) {
            Log.e(TAG, "读取游戏库失败", t);
        }
    }

    public void save() {
        try {
            JSONArray arr = new JSONArray();
            for (Entry e : entries) {
                JSONObject o = new JSONObject();
                o.put("id", e.id);
                o.put("title", e.title);
                o.put("uri", e.uri);
                o.put("code", e.code);
                o.put("added", e.added);
                o.put("lastPlayed", e.lastPlayed);
                o.put("seq", e.seq);
                o.put("origin", e.origin == null ? "" : e.origin);
                o.put("named", e.named);
                o.put("favorite", e.favorite);
                o.put("favAt", e.favAt);
                arr.put(o);
            }
            File f = file();
            File tmp = new File(root, FILE + ".tmp");
            if (!root.exists() && !root.mkdirs()) Log.w(TAG, "无法创建 " + root);
            FileOutputStream fos = new FileOutputStream(tmp);
            fos.write(arr.toString(2).getBytes("UTF-8"));
            fos.flush();
            fos.close();
            if (f.exists()) f.delete();
            tmp.renameTo(f);          // write-then-rename, never a half file
        } catch (Throwable t) {
            Log.e(TAG, "保存游戏库失败", t);
        }
    }
}
