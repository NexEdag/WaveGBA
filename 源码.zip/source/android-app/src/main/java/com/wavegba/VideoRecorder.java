package com.wavegba;

import java.io.File;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.util.ArrayList;

/** Records frames as Motion-JPEG inside an AVI container.
 *
 *  Why this instead of MediaCodec:
 *
 *  - MediaCodec / MediaMuxer need API 16 / 18. This project compiles against
 *    an API 14 android.jar, so they would have to be reached by reflection,
 *    and a reflected codec cannot be smoke-tested here at all.
 *  - MJPEG in AVI is plain file writing. Every byte is ours, so the encoder
 *    can be built and validated on a desktop JVM against ffprobe before it
 *    ever reaches a phone.
 *
 *  Each frame is a self-contained JPEG, so there is no inter-frame prediction
 *  to get wrong and no drift. The cost is size: expect roughly 8-15 KB per
 *  240x160 frame, i.e. 1.5-4 MB for ten seconds.
 *
 *  Not thread safe; call from the emulation/encoder thread only. */
public final class VideoRecorder {

    private static final int RIFF = fourcc("RIFF");
    private static final int AVI_ = fourcc("AVI ");
    private static final int LIST = fourcc("LIST");
    private static final int HDRL = fourcc("hdrl");
    private static final int MOVI = fourcc("movi");
    private static final int AVih = fourcc("avih");
    private static final int STRL = fourcc("strl");
    private static final int STRH = fourcc("strh");
    private static final int STRF = fourcc("strf");
    private static final int IDX1 = fourcc("idx1");
    private static final int MJPG = fourcc("MJPG");
    private static final int VIDS = fourcc("vids");
    // Stream 0, compressed DIB. The leading "00" is two ASCII digit zeros
    // (0x30 0x30) -- using NUL bytes instead makes the chunk unrecognisable
    // and every frame silently fails to decode.
    private static final int DIB_ = fourcc("00dc");

    private final RandomAccessFile raf;
    private final int width, height, fps;

    /** Byte offset of the 'movi' list payload, the base for index offsets. */
    private long moviDataStart;
    private final ArrayList<Integer> frameSizes = new ArrayList<>();
    private long riffSizePos, moviSizePos, frameCountPos;
    private boolean closed = false;

    private final File out;

    public VideoRecorder(File out, int width, int height, int fps) throws IOException {
        if (width <= 0 || height <= 0) throw new IOException("bad frame size");
        this.width = width;
        this.height = height;
        this.fps = Math.max(1, fps);
        out.getParentFile().mkdirs();
        this.out = out;
        raf = new RandomAccessFile(out, "rw");
        raf.setLength(0);
        writeHeaders();
    }

    /** 'RIFF' as a little-endian int: putInt(0x46464952) emits "RIFF". */
    private static int fourcc(String s) {
        byte[] b = s.getBytes(java.nio.charset.Charset.forName("US-ASCII"));
        int v = 0;
        for (int i = 3; i >= 0; i--) v = (v << 8) | (i < b.length ? (b[i] & 0xFF) : 0);
        return v;
    }

    private ByteBuffer le(int cap) {
        return ByteBuffer.allocate(cap).order(ByteOrder.LITTLE_ENDIAN);
    }

    private void writeHeaders() throws IOException {
        // RIFF 'AVI ' <size>  -- size patched in close()
        ByteBuffer h = le(12);
        h.putInt(RIFF);
        riffSizePos = 4;
        h.putInt(0);
        h.putInt(AVI_);
        raf.write(h.array());

        // ---- LIST 'hdrl' ----
        ByteBuffer avih = mainHeader();
        ByteBuffer strh = streamHeader();
        ByteBuffer strf = streamFormat();

        // A LIST chunk's size counts its own type fourcc, so 'hdrl' and
        // 'strl' must be included in the totals below. (8 = fourcc + size.)
        int strlPayload = 8 + strh.capacity() + 8 + strf.capacity();
        int hdlrPayload = 4 /* 'hdrl' */ + 8 + avih.capacity()
                        + 8 /* LIST+size */ + 4 /* 'strl' */ + strlPayload;

        ByteBuffer l = le(8 + hdlrPayload);
        l.putInt(LIST);
        l.putInt(hdlrPayload);
        l.putInt(HDRL);
        // Every chunk needs its fourcc before its size. The first version
        // wrote size+payload straight after 'hdrl', so 'avih'/'strh'/'strf'
        // were missing and the whole header was 12 bytes short of where the
        // offsets assumed it would be.
        l.putInt(AVih).putInt(avih.capacity()).put(avih.array());
        l.putInt(LIST).putInt(strlPayload).putInt(STRL);
        l.putInt(STRH).putInt(strh.capacity()).put(strh.array());
        l.putInt(STRF).putInt(strf.capacity()).put(strf.array());
        raf.write(l.array());

        // ---- LIST 'movi' ----
        ByteBuffer m = le(12);
        m.putInt(LIST);
        moviSizePos = raf.getFilePointer() + 4;
        m.putInt(0);
        m.putInt(MOVI);
        raf.write(m.array());
        moviDataStart = raf.getFilePointer();
    }

    /** MainAVIHeader, 56 bytes. dwTotalFrames is patched in close(). */
    private ByteBuffer mainHeader() {
        ByteBuffer b = le(56);
        b.putInt((int) Math.round(1_000_000.0 / fps));   // dwMicroSecPerFrame
        b.putInt(0);                               // dwMaxBytesPerSec (0 = unused)
        b.putInt(0);                               // dwPaddingGranularity
        b.putInt(0x00000810);                      // AVIF_HASINDEX | AVIF_ISINTERLEAVED
        frameCountPos = 0;                         // resolved relative below
        b.putInt(0);                               // dwTotalFrames (patched)
        b.putInt(0);                               // dwInitialFrames
        b.putInt(1);                               // dwStreams
        b.putInt(0);                               // dwSuggestedBufferSize
        b.putInt(width);
        b.putInt(height);
        b.put(new byte[16]);                       // dwReserved[4]
        return b;
    }

    /** AVIStreamHeader, 56 bytes. dwLength is patched in close(). */
    private ByteBuffer streamHeader() {
        ByteBuffer b = le(56);
        b.putInt(VIDS);
        b.putInt(MJPG);
        b.putInt(0);
        b.putShort((short) 0);                     // wPriority
        b.putShort((short) 0);                     // wLanguage
        b.putInt(0);                               // dwInitialFrames
        b.putInt(1);                               // dwScale
        b.putInt(fps);                             // dwRate
        b.putInt(0);                               // dwStart
        b.putInt(0);                               // dwLength (patched)
        b.putInt(0);                               // dwSuggestedBufferSize
        b.putInt(-1);                              // dwQuality (-1 = default)
        b.putInt(0);                               // dwSampleSize
        b.putShort((short) 0);                     // rcFrame.left
        b.putShort((short) 0);                     // rcFrame.top
        b.putShort((short) width);                 // rcFrame.right
        b.putShort((short) height);                // rcFrame.bottom
        return b;
    }

    /** BITMAPINFOHEADER, 40 bytes, with biCompression = MJPG. */
    private ByteBuffer streamFormat() {
        ByteBuffer b = le(40);
        b.putInt(40);
        b.putInt(width);
        b.putInt(height);
        b.putShort((short) 1);                     // biPlanes
        b.putShort((short) 24);                    // biBitCount
        b.putInt(MJPG);                            // biCompression
        b.putInt(width * height * 3);
        b.putInt(0);
        b.putInt(0);
        b.putInt(0);
        b.putInt(0);
        return b;
    }

    /** Append one JPEG-encoded frame. */
    public void writeFrame(byte[] jpeg) throws IOException {
        if (closed) throw new IOException("recorder closed");
        if (jpeg == null || jpeg.length == 0) return;

        long off = raf.getFilePointer() - moviDataStart;
        ByteBuffer hdr = le(8);
        hdr.putInt(DIB_);
        hdr.putInt(jpeg.length);
        raf.write(hdr.array());
        raf.write(jpeg);
        // Chunks are word aligned; a pad byte is not counted in the size.
        if ((jpeg.length & 1) != 0) raf.write(0);

        frameSizes.add(jpeg.length);
        indexOffsets.add(off);
    }

    private final ArrayList<Long> indexOffsets = new ArrayList<>();

    public int frameCount() { return frameSizes.size(); }

    /** The file being written, so the host can report it after closing. */
    public File file() { return out; }

    /** Finalise: write the index, then patch every size field. */
    public void close() {
        if (closed) return;
        closed = true;
        try {
            long moviEnd = raf.getFilePointer();

            // ---- idx1 ----
            int n = frameSizes.size();
            ByteBuffer idx = le(8 + n * 16);
            idx.putInt(IDX1);
            idx.putInt(n * 16);
            for (int i = 0; i < n; i++) {
                idx.putInt(DIB_);
                idx.putInt(0x00000010);            // AVIIF_KEYFRAME: every MJPEG frame is one
                idx.putInt(indexOffsets.get(i).intValue());
                idx.putInt(frameSizes.get(i));
            }
            raf.write(idx.array());

            long fileEnd = raf.getFilePointer();

            // movi list size = its payload + the fourcc it wraps
            int moviSize = (int) (moviEnd - moviDataStart) + 4;
            raf.seek(moviSizePos);
            raf.write(leBuf(moviSize));

            // Patch dwTotalFrames and dwLength.
            //
            // Absolute offsets, spelled out rather than derived: an earlier
            // version added the 'avih' fourcc to the running total twice and
            // landed on dwFlags, corrupting the header so ffprobe reported
            // "Something went wrong during header parsing" and found no
            // streams at all.
            //
            //   0  RIFF / 4 size / 8 'AVI '
            //  12  LIST / 16 size / 20 'hdrl' / 24 'avih' / 28 size / 32 data
            //  32  MainAVIHeader(56), dwTotalFrames at +16 -> 48
            //  88  LIST / 92 size / 96 'strl' / 100 'strh' / 104 size / 108 data
            // 108  AVIStreamHeader(56), dwLength at +32 -> 140
            raf.seek(48);
            raf.write(leBuf(n));
            raf.seek(140);
            raf.write(leBuf(n));

            raf.seek(riffSizePos);
            raf.write(leBuf((int) (fileEnd - 8)));

            raf.getFD().sync();
            raf.close();
        } catch (IOException e) {
            try { raf.close(); } catch (IOException ignored) { }
        }
    }

    private static byte[] leBuf(int v) {
        return ByteBuffer.allocate(4).order(ByteOrder.LITTLE_ENDIAN).putInt(v).array();
    }
}
