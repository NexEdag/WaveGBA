package com.wavegba;

import android.media.AudioFormat;
import android.media.AudioManager;
import android.media.AudioTrack;
import android.util.Log;

/** Pulls PCM frames out of the core and feeds an AudioTrack.
 *
 *  Audio always plays at 1x, whatever the emulation is doing. The core emits a
 *  fixed number of samples per emulated frame, so at 2x it produces two
 *  seconds of sound per real second; the surplus has to go somewhere or the
 *  stream would run further and further behind.
 *
 *  It is discarded, here, in batches, and the join is cross-faded. That last
 *  part is the whole trick: throwing away a run of samples leaves the waveform
 *  discontinuous, and at the rate these discards happen that discontinuity is
 *  not a click you can ignore, it is what turns the output into noise. Fading
 *  across the splice keeps the waveform continuous, so what you hear is the
 *  music with content missing, not a buzz.
 *
 *  Below 1x the mirror problem applies -- too little audio rather than too
 *  much -- and there it is left alone. Filling real time would mean inventing
 *  samples, and every way of doing that (repeating a short block, holding one
 *  sample) adds an artifact of its own that is worse than the brief gaps an
 *  underrun produces. */
public final class AudioPlayer implements Runnable {

    /** Receives the PCM that is about to be played, for recording.
     *
     *  Fed the raw frames the core produced, before speed resampling: the
     *  recorder timestamps at the core's own 32000 Hz, and feeding it the
     *  resampled stream would make the pitch-shifted playback rate disagree
     *  with those timestamps. */
    public interface PcmSink {
        void onPcm(short[] pcm, int frames);
    }

    private volatile PcmSink sink;

    /** null disables. Called from the audio thread, so it must be cheap and
     *  must not throw. */
    public void setPcmSink(PcmSink s) { sink = s; }

    private static final String TAG = "WaveGBA.audio";
    /** ~4 frames of buffering: low enough to stay under ~20ms of latency. */
    private static final int FRAMES_PER_READ = 512;

    private final Thread thread = new Thread(this, "gba-audio");
    private volatile boolean running = false;
    private volatile boolean muted = false;
    private volatile double speed = 1.0;
    /** 0.0 .. 1.0 output gain. */
    private volatile float volume = 1.0f;
    private AudioTrack track;
    private final short[] scratch = new short[FRAMES_PER_READ * 2];
    /* Resampled + gain-applied output, kept separate from the drain buffer
       because resampling reads and writes the same span. */
    private final short[] buf = new short[FRAMES_PER_READ * 2];

    /* FIFO between the core and the AudioTrack.
     *
     *  Needed because the drain gives back whatever the core has, in whatever
     *  size, while playback has to run on wall-clock time. The FIFO absorbs
     *  the difference; its fill level is what tells us how much surplus has
     *  piled up. */
    private static final int FIFO_CAP = 2048;
    /** Fill level to return to after a discard. Also the steady-state latency:
     *  256 frames is 8ms, low enough that a button press still feels in sync. */
    private static final int FIFO_TARGET = 256;
    /** Above this, discard down to the target. The gap between the two sets
     *  how much surplus accumulates before acting, which is how often a splice
     *  happens: measured over a second of 440Hz, 1024/256/48 gives 110 splices
     *  at 4x, 1536 gives 71. Fewer splices means less of the output is fade
     *  rather than music, so 1536 it is. It has to stay comfortably above what
     *  one drain can add, or even 1x would start discarding. */
    private static final int FIFO_HIGH = 1536;
    /** Frames cross-faded across a splice. 64 is 2ms: long enough to smooth a
     *  join, short enough not to smear transients. */
    private static final int XFADE = 64;

    private final short[] fifo = new short[FIFO_CAP * 2];
    /** Index of the oldest frame. */
    private int fifoHead = 0;
    private int fifoCount = 0;


    public void start() {
        if (running) return;
        running = true;
        thread.start();
    }

    public void stop() {
        running = false;
        thread.interrupt();
        try { thread.join(500); } catch (InterruptedException ignored) {}
        releaseTrack();
    }

    public void setMuted(boolean m) { muted = m; }

    public boolean isMuted() { return muted; }

    /** 0.0 .. 1.0. Applied per-sample rather than via AudioTrack.setVolume(),
     *  because that call is API 21+ and this build targets API 23 with an
     *  older android.jar on the build machine. */
    public void setVolume(float v) {
        volume = Math.max(0f, Math.min(1f, v));
    }

    public float getVolume() { return volume; }

    /** Kept for the emulator loop's sake, but no longer used to resample.
     *
     *  The playback rate used to follow the emulation speed, so running at 2x
     *  made the music play twice as fast. Keeping the pitch was the easy part;
     *  speeding the whole soundtrack up is what made fast-forward unpleasant
     *  to actually sit through. Audio now always plays at 1x and the speed
     *  only affects the picture. */
    public void setSpeed(double s) { speed = Math.max(0.25, Math.min(64.0, s)); }

    /* ------------------------------------------------------------ FIFO --- */

    /** Append drained frames at the tail. Anything that does not fit is
     *  dropped rather than overwriting the head: the FIFO is only ever asked
     *  to hold a few hundred frames past its high-water mark, so overflow
     *  cannot happen in practice, and corrupting the read position would be
     *  far worse than losing the newest audio. */
    private void fifoAppend(short[] src, int frames) {
        int room = FIFO_CAP - fifoCount;
        int n = Math.min(frames, room);
        if (n <= 0) return;
        int start = (fifoHead + fifoCount) % FIFO_CAP;
        int first = Math.min(n, FIFO_CAP - start);
        System.arraycopy(src, 0, fifo, start * 2, first * 2);
        if (n > first) {
            System.arraycopy(src, first * 2, fifo, 0, (n - first) * 2);
        }
        fifoCount += n;
    }

    /** Drop the oldest `d` frames, cross-fading across the join.
     *
     *  Plain dropping is what produced the noise: the sample after the cut
     *  bears no relation to the sample before it, and at a hundred-plus
     *  splices a second that is a buzz, not a click. Mixing the tail of the
     *  region being discarded into the head of what survives means playback
     *  continues from where it was and eases onto the new material, so the
     *  waveform stays continuous. */
    private void fifoDrop(int d) {
        if (d <= 0) return;
        if (d > fifoCount) d = fifoCount;

        int x = XFADE;
        if (d + x > fifoCount) x = fifoCount - d;
        for (int i = 0; i < x; i++) {
            float w = i / (float) x;          // 0 -> 1 across the fade
            int ai = (fifoHead + i) % FIFO_CAP;        // tail of the cut
            int bi = (fifoHead + d + i) % FIFO_CAP;    // head of what remains
            fifo[bi * 2]     = (short) (fifo[bi * 2]     * w + fifo[ai * 2]     * (1f - w));
            fifo[bi * 2 + 1] = (short) (fifo[bi * 2 + 1] * w + fifo[ai * 2 + 1] * (1f - w));
        }
        fifoHead = (fifoHead + d) % FIFO_CAP;
        fifoCount -= d;
    }

    /** Take up to `n` frames from the head. Returns how many were copied. */
    private int fifoRead(short[] dst, int n) {
        n = Math.min(n, fifoCount);
        if (n <= 0) return 0;
        int first = Math.min(n, FIFO_CAP - fifoHead);
        System.arraycopy(fifo, fifoHead * 2, dst, 0, first * 2);
        if (n > first) {
            System.arraycopy(fifo, 0, dst, first * 2, (n - first) * 2);
        }
        fifoHead = (fifoHead + n) % FIFO_CAP;
        fifoCount -= n;
        return n;
    }


    private void ensureTrack() {
        if (track != null) return;
        int min = AudioTrack.getMinBufferSize(
                NativeBridge.SAMPLE_RATE,
                AudioFormat.CHANNEL_OUT_STEREO,
                AudioFormat.ENCODING_PCM_16BIT);
        int buf = Math.max(min, FRAMES_PER_READ * 4);
        try {
            track = new AudioTrack(AudioManager.STREAM_MUSIC,
                    NativeBridge.SAMPLE_RATE,
                    AudioFormat.CHANNEL_OUT_STEREO,
                    AudioFormat.ENCODING_PCM_16BIT,
                    buf, AudioTrack.MODE_STREAM);
            track.play();
        } catch (Exception e) {
            Log.e(TAG, "AudioTrack 创建失败: " + e);
            track = null;
        }
    }

    private void releaseTrack() {
        if (track != null) {
            try { track.stop(); track.release(); } catch (Exception ignored) {}
            track = null;
        }
    }

    @Override
    public void run() {
        ensureTrack();
        while (running) {
            int frames = NativeBridge.nativeAudioDrain(scratch);

            // Hand the core's own frames to the recorder regardless of mute:
            // a muted phone should still produce a video with sound.
            if (frames > 0) {
                PcmSink sk = sink;
                if (sk != null) {
                    try { sk.onPcm(scratch, frames); }
                    catch (Throwable t) { Log.w(TAG, "PCM 回调失败", t); sink = null; }
                }
            }

            if (muted) {
                // Not appended: with nothing being played the FIFO would just
                // fill and then be discarded, so this keeps it empty and ready
                // for when mute is lifted.
                try { Thread.sleep(2); } catch (InterruptedException e) { return; }
                continue;
            }
            if (frames > 0) fifoAppend(scratch, frames);

            if (track == null || fifoCount == 0) {
                try { Thread.sleep(2); } catch (InterruptedException e) { return; }
                continue;
            }

            // Discard surplus before reading, never after: reading first would
            // mean the discarded samples had already been decided on, and the
            // splice would land in the middle of what was just handed over.
            if (fifoCount > FIFO_HIGH) fifoDrop(fifoCount - FIFO_TARGET);

            int out = fifoRead(buf, FRAMES_PER_READ);

            if (out > 0) {
                // Gain applied per sample: AudioTrack.setVolume() is API 21+
                // and this build's android.jar predates it.
                float g = volume;
                if (g < 0.999f) {
                    for (int n = 0; n < out * 2; n++) {
                        int v = (int) (buf[n] * g);
                        if (v > 32767) v = 32767; else if (v < -32768) v = -32768;
                        buf[n] = (short) v;
                    }
                }
                try { track.write(buf, 0, out * 2); }
                catch (Exception e) { Log.e(TAG, "写入失败: " + e); }
            } else {
                try { Thread.sleep(2); } catch (InterruptedException e) { return; }
            }
        }
    }
}
