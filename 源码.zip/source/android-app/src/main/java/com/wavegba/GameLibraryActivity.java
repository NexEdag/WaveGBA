package com.wavegba;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Shader;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;
import java.util.List;

/** Home screen: a grid of the user's games with cover art and last-played
 *  time. A floating "+" in the bottom-right adds a new ROM.
 *
 *  Uses GridView rather than RecyclerView because this build compiles against
 *  a very old android.jar that has no RecyclerView at all. */
public class GameLibraryActivity extends Activity {

    private static final String TAG = "WaveGBA.library";
    private static final int REQ_PICK = 41;
    private static final int REQ_TREE = 42;

    /* Search. Below this many games the box stays hidden: with two games a
     * search field costs a row and saves nothing. Three is where scanning
     * starts to take longer than typing. */
    private static final int SEARCH_MIN_GAMES = 3;
    /** How far a card shrinks while held. Small enough to read as a press
     *  rather than as the layout resizing. */
    private static final float PRESS_SCALE = 0.94f;

    /** Shrink a card, immediately.
     *
     *  Plain setScaleX/setScaleY rather than an animation. Both a
     *  ViewPropertyAnimator and a ScaleAnimation were tried here and neither
     *  showed up on device -- the property path needs the view's render node
     *  and the tween path goes through the parent's draw-time transform, and
     *  the card is a plain inflated layout inside a ScrollView with neither
     *  guaranteed. Setting the properties directly and invalidating is applied
     *  on the next draw unconditionally.
     *
     *  No transition curve: the point is that the press registers, and a
     *  snap is unambiguous where a 90ms tween at 4% was easy to miss. */
    private static void setCardScale(View v, float s) {
        if (v == null) return;
        v.setScaleX(s);
        v.setScaleY(s);
        v.invalidate();
    }

    /** false = 全部, true = 只看收藏. */
    private boolean showFavOnly = false;
    private android.widget.LinearLayout tabBar = null;
    private android.widget.TextView tabAll = null, tabFav = null;
    private android.widget.EditText searchBox;
    private TextView searchHint;
    private String query = "";

    private GameLibrary library;
    private File saveDir;
    private static final String PREF_SAVE_DIR = "save_dir";
    private static final int REQ_STORAGE = 77;
    private boolean askedPermission = false;
    /** Held so the naming dialog can be dismissed from commitName(). */
    private android.app.AlertDialog namingDialog = null;
    private android.widget.LinearLayout gridHost;
    private View scrollView;
    private TextView empty;
    private List<GameLibrary.Entry> shown;
    /** Measured column width, so the cover aspect ratio is right. */
    private int colWidth = 0;
    private int coverHeight = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        saveDir = resolveSaveDir();
        library = new GameLibrary(saveDir);
        buildUi();
        refresh();
        // Bug fix: this used to test writable(saveDir), but saveDir is
        // already the resolved folder and the private fallback is always
        // writable -- so the condition never fired and the app silently used
        // the private folder forever. Test the folder we actually want.
        if (!writable(preferredSaveDir()) || !hasStorageAccess()) {
            // Without all-files access the library is written to the private
            // fallback, which Android wipes on uninstall -- the user then
            // finds /sdcard/WaveGBA empty. Ask up front.
            requestStorageAccess();
        }
        updateStorageNote();
        migrateFromPrivate();
    }

    /** Cold start with public access just granted: onCreate already resolved
     *  to the public folder, so onResume sees no change and would skip the
     *  migration. Do it here too. */
    private void migrateFromPrivate() {
        File priv = fallbackSaveDir().getParentFile();      // .../files/WaveGBA
        File pub = preferredSaveDir().getParentFile();      // /sdcard/WaveGBA
        if (saveDir == null || isPrivatePath(saveDir)) return;
        if (priv == null || pub == null || priv.equals(pub)) return;
        if (!priv.exists()) return;
        copyTree(priv, pub);
        library = new GameLibrary(saveDir);
        refresh();
    }

    /** Layout is a vertical LinearLayout, not a FrameLayout with hand-tuned
     *  padding offsets.
     *
     *  The header (title + storage note) used to be a fixed 58dp gap above the
     *  grid; as soon as the note wrapped to two lines it overlapped the first
     *  row of cards. Stacking them means the grid starts wherever the header
     *  ends, whatever height that turns out to be. */
    /** The screen comes from activity_library.xml.
     *
     *  The previous version assembled this in code and positioned the header
     *  with fixed offsets, which overlapped the first row of cards as soon as
     *  the storage note wrapped. Letting the framework do the layout means the
     *  grid starts wherever the header ends, whatever height that is. */
    private void buildUi() {
        Theme.load(getSharedPreferences("wavegba", MODE_PRIVATE));
        setContentView(R.layout.activity_library);
        getWindow().getDecorView().setBackgroundColor(Theme.bg());

        heading = (TextView) findViewById(R.id.title);
        countView = (TextView) findViewById(R.id.count);
        storageNote = (TextView) findViewById(R.id.storage_note);
        gridHost = (android.widget.LinearLayout) findViewById(R.id.grid_host);
        scrollView = findViewById(R.id.scroll);
        empty = (TextView) findViewById(R.id.empty);

        android.util.DisplayMetrics m = getResources().getDisplayMetrics();
        int pad = (int) (20 * m.density);
        spacingPx = (int) (14 * m.density);
        int minCol = (int) (112 * m.density);

        int usable = m.widthPixels - 2 * pad + spacingPx;
        cols = usable / (minCol + spacingPx);
        if (cols < 2) cols = 2;
        if (cols > 5) cols = 5;
        colWidth = usable / cols - spacingPx;
        // 3:2 is the GBA's own aspect ratio, so centre-cropping a captured
        // frame to this size loses no picture.
        coverHeight = Math.round(colWidth * 2f / 3f);

        // Tabs sit above the grid: gridHost is the vertical list of rows, so
        // its parent is the layout that also holds the heading.
        if (gridHost != null && gridHost.getParent()
                instanceof android.widget.LinearLayout) {
            buildTabBar((android.widget.LinearLayout) gridHost.getParent());
        }

        searchBox = (android.widget.EditText) findViewById(R.id.search);
        searchHint = (TextView) findViewById(R.id.search_hint);
        if (searchBox != null) {
            searchBox.addTextChangedListener(new android.text.TextWatcher() {
                public void beforeTextChanged(CharSequence s, int a, int b, int c) { }
                public void onTextChanged(CharSequence s, int a, int b, int c) { }
                public void afterTextChanged(android.text.Editable e) {
                    query = e == null ? "" : e.toString();
                    refresh();
                }
            });
            searchBox.setOnEditorActionListener(
                    new android.widget.TextView.OnEditorActionListener() {
                public boolean onEditorAction(android.widget.TextView v,
                                              int actionId,
                                              android.view.KeyEvent ev) {
                    // Close the keyboard on 搜索/回车: the results are already
                    // filtered, leaving it up just hides half the grid.
                    android.view.inputmethod.InputMethodManager imm =
                            (android.view.inputmethod.InputMethodManager)
                                    getSystemService(INPUT_METHOD_SERVICE);
                    if (imm != null) imm.hideSoftInputFromWindow(v.getWindowToken(), 0);
                    v.clearFocus();
                    return true;
                }
            });
        }

        TextView fab = (TextView) findViewById(R.id.fab);
        fab.setBackgroundDrawable(fabBackground());
        fab.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) { showAddMenu(); }
        });
    }

    /** Fill the grid: one horizontal LinearLayout per row, each card given
     *  layout_weight=1 so the parent measures it. Rows are built here rather
     *  than by a GridView because the AdapterView measured its children to a
     *  zero-ish width inside this slot. */
    private void renderGrid() {
        if (gridHost == null) return;
        gridHost.removeAllViews();
        int n = shown.size();
        if (n == 0) return;

        float density = getResources().getDisplayMetrics().density;
        for (int i = 0; i < n; i += cols) {
            android.widget.LinearLayout row = new android.widget.LinearLayout(this);
            row.setOrientation(android.widget.LinearLayout.HORIZONTAL);
            android.widget.LinearLayout.LayoutParams rp =
                    new android.widget.LinearLayout.LayoutParams(
                            ViewGroup.LayoutParams.MATCH_PARENT,
                            ViewGroup.LayoutParams.WRAP_CONTENT);
            if (i + cols < n) rp.bottomMargin = (int) (18 * density);
            gridHost.addView(row, rp);

            for (int j = 0; j < cols; j++) {
                int idx = i + j;
                android.widget.LinearLayout.LayoutParams cp =
                        new android.widget.LinearLayout.LayoutParams(
                                0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
                if (j > 0) cp.leftMargin = spacingPx;

                if (idx >= n) {
                    // Keep the row geometry: an empty spacer so the last row
                    // does not stretch its single card across the screen.
                    View spacer = new View(this);
                    row.addView(spacer, cp);
                    continue;
                }

                View card = getLayoutInflater()
                        .inflate(R.layout.item_game, row, false);
                bindCard(card, shown.get(idx));
                row.addView(card, cp);
            }
        }
    }

    private void bindCard(View card, final GameLibrary.Entry e) {
        ImageView cover = (ImageView) card.findViewById(R.id.cover);
        TextView name = (TextView) card.findViewById(R.id.name);
        TextView when = (TextView) card.findViewById(R.id.when);
        View badge = card.findViewById(R.id.fav_badge);

        // Swap in the accented variant of the card background so a favourite
        // is visible while scrolling, not just from the star in its title.
        // Both drawables are the same geometry, so the grid cannot shift.
        card.setBackgroundResource(e.favorite
                ? R.drawable.card_game_fav : R.drawable.card_game);
        if (badge != null) {
            badge.setVisibility(e.favorite ? View.VISIBLE : View.GONE);
        }

        android.view.ViewGroup.LayoutParams lp = cover.getLayoutParams();
        if (lp != null) {
            lp.height = coverHeight;
            cover.setLayoutParams(lp);
        }
        cover.setImageDrawable(coverFor(e));

        // A star on the title so a favourite is identifiable without opening
        // the long-press menu -- especially in 收藏 view, where everything
        // being starred makes the tab itself the only other cue.
        name.setText(e.favorite ? ("★ " + GameLibrary.label(e))
                : GameLibrary.label(e));
        if (e.lastPlayed > 0) {
            when.setText(relativeTime(e.lastPlayed));
            when.setTextColor(Theme.accent());
        } else {
            when.setText("尚未运行");
            when.setTextColor(Theme.textSecondary());
        }

        // Press feedback: the card shrinks a touch and springs back.
        //
        // A view Animation rather than ViewPropertyAnimator. The property
        // animator moves the View's own scale properties, which needs the
        // view to be laid out and hardware-accelerated to show up; a view
        // animation is applied by the parent while drawing, so it works
        // regardless. The card only ever needs a visual squeeze -- nothing
        // reads its bounds -- so there is nothing lost.
        //
        // Returns false throughout, so the click and long-click listeners
        // below still fire: consuming the event here would make the card dead.
        card.setOnTouchListener(new View.OnTouchListener() {
            public boolean onTouch(View v, android.view.MotionEvent ev) {
                switch (ev.getActionMasked()) {
                    case android.view.MotionEvent.ACTION_DOWN:
                        setCardScale(v, PRESS_SCALE);
                        break;
                    case android.view.MotionEvent.ACTION_UP:
                    case android.view.MotionEvent.ACTION_CANCEL:
                        // CANCEL matters: scrolling the grid out from under a
                        // held finger fires it, and without this the card
                        // would stay shrunk.
                        setCardScale(v, 1f);
                        break;
                }
                return false;
            }
        });
        card.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) { open(e); }
        });
        card.setOnLongClickListener(new View.OnLongClickListener() {
            public boolean onLongClick(View v) { confirmRemove(e); return true; }
        });
    }


    /** Favourite badge: a filled star on a rounded chip, drawn rather than
     *  declared.
     *
     *  Two reasons not to use the ★ glyph on a TextView. Its shape varies
     *  between the fonts different devices substitute, so it can come out
     *  lopsided or as an outline-only glyph; and a shape drawable cannot
     *  express a star at all. Drawing the ten vertices gives the same star
     *  everywhere.
     *
     *  The chip carries a shadow and a hairline rim so it reads as sitting on
     *  top of the cover art rather than printed into it -- covers are
     *  arbitrary screenshots and there is no guarantee of contrast. */
    /** Rounded gradient button with a soft outer glow, drawn rather than
     *  declared: <shape> gradients are supported but the glow needs a second
     *  pass with a blur, which XML cannot express. */


    private Drawable fabBackground() {
        int size = (int) (60 * getResources().getDisplayMetrics().density);
        Bitmap bmp = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(bmp);

        Paint glow = new Paint(Paint.ANTI_ALIAS_FLAG);
        glow.setColor(0x557C3AED);
        c.drawRoundRect(new android.graphics.RectF(0, 0, size, size),
                size * 0.5f, size * 0.5f, glow);

        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        p.setShader(new LinearGradient(0, 0, size, size,
                0xFF7C3AED, 0xFF22D3EE, Shader.TileMode.CLAMP));
        float inset = size * 0.06f;
        c.drawRoundRect(new android.graphics.RectF(
                        inset, inset, size - inset, size - inset),
                size * 0.44f, size * 0.44f, p);
        return new BitmapDrawable(getResources(), bmp);
    }

    private TextView heading;
    private TextView countView;
    private int cols = 2;
    private int spacingPx = 14;

    private TextView storageNote = null;

    /** Tell the player where their data is. A silent fallback to a folder
     *  that vanishes on uninstall is worse than any error message. */
    private void updateStorageNote() {
        if (storageNote == null) return;
        boolean pub = saveDir != null
                && saveDir.getAbsolutePath().startsWith(
                        android.os.Environment.getExternalStorageDirectory()
                                .getAbsolutePath());
        if (pub) {
            storageNote.setText("数据目录：" + saveDir.getAbsolutePath());
            storageNote.setTextColor(0xFF6B7280);
        } else {
            storageNote.setText("\u26a0 \u6570\u636e\u5b58\u5728\u79c1\u6709\u76ee\u5f55\uff08\u5378\u8f7d\u4f1a\u4e22\u5931\uff09\n\u70b9\u6b64\u6388\u6743\u5e76\u8fc1\u5230 " + preferredSaveDir().getParentFile().getAbsolutePath());
            storageNote.setTextColor(0xFFF87171);
        }
        storageNote.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                if (!writable(preferredSaveDir()) || !hasStorageAccess()) {
                    askedPermission = false;      // allow asking again
                    requestStorageAccess();
                } else {
                    Toast.makeText(GameLibraryActivity.this,
                            "权限已具备，正在重新载入", Toast.LENGTH_SHORT).show();
                    onResume();
                }
            }
        });
    }

    private void titleCount(int n) {
        if (heading == null) return;
        String s = n > 0 ? ("WaveGBA  ·  " + n + " 个游戏") : "WaveGBA";
        if (library != null) s += "\n" + library.root().getAbsolutePath();
        heading.setText(s);
    }

    /* --------------------------------------------------------- 首次引导 -- */

    /** Three-step intro, shown only on a genuinely first run.
     *
     *  Gated on the library being empty as well as the seen flag: someone who
     *  has already added games does not need telling how, and someone who
     *  removed them all has already seen it once. */
    private void maybeShowGuide() {
        if (library == null || !library.all().isEmpty()) return;
        android.content.SharedPreferences sp =
                getSharedPreferences("wavegba", MODE_PRIVATE);
        if (sp.getBoolean("guide_seen", false)) return;
        sp.edit().putBoolean("guide_seen", true).apply();
        showGuide();
    }

    private void showGuide() {
        float d = getResources().getDisplayMetrics().density;
        android.widget.ScrollView sv = new android.widget.ScrollView(this);
        android.widget.LinearLayout box = new android.widget.LinearLayout(this);
        box.setOrientation(android.widget.LinearLayout.VERTICAL);
        int pad = (int) (18 * d);
        box.setPadding(pad, pad, pad, pad);

        android.widget.TextView head = new android.widget.TextView(this);
        head.setText("欢迎使用 WaveGBA");
        head.setTextSize(18);
        head.setTextColor(Theme.accent());
        head.setPadding(0, 0, 0, (int) (12 * d));
        box.addView(head);

        String[][] steps = {
                {"1", "准备 ROM 文件",
                        "模拟器不自带游戏。把 .gba（或 .zip）文件放到手机里，"
                                + "或用下载目录里已有的文件。"},
                {"2", "点右下角 + 添加",
                        "可以选择单个文件，也可以选「扫描文件夹」批量导入。"
                                + "添加时 ROM 会复制到 WaveGBA/ROMs/ 并让你命名。"},
                {"3", "点卡片开始",
                        "库里点游戏卡片直接进游戏。长按卡片可重命名、收藏或移除。"},
        };
        for (String[] st : steps) {
            android.widget.LinearLayout row =
                    new android.widget.LinearLayout(this);
            row.setOrientation(android.widget.LinearLayout.HORIZONTAL);
            android.widget.LinearLayout.LayoutParams rp =
                    new android.widget.LinearLayout.LayoutParams(
                            android.widget.LinearLayout.LayoutParams.MATCH_PARENT,
                            android.widget.LinearLayout.LayoutParams.WRAP_CONTENT);
            rp.setMargins(0, 0, 0, (int) (12 * d));
            row.setLayoutParams(rp);

            android.widget.TextView num = new android.widget.TextView(this);
            num.setText(st[0]);
            num.setTextSize(14);
            num.setTextColor(Theme.accent());
            num.setWidth((int) (26 * d));
            row.addView(num);

            android.widget.LinearLayout txt =
                    new android.widget.LinearLayout(this);
            txt.setOrientation(android.widget.LinearLayout.VERTICAL);
            android.widget.TextView t1 = new android.widget.TextView(this);
            t1.setText(st[1]);
            t1.setTextSize(15);
            t1.setTextColor(Theme.textPrimary());
            android.widget.TextView t2 = new android.widget.TextView(this);
            t2.setText(st[2]);
            t2.setTextSize(13);
            t2.setTextColor(Theme.textSecondary());
            t2.setPadding(0, (int) (3 * d), 0, 0);
            txt.addView(t1);
            txt.addView(t2);
            row.addView(txt);
            box.addView(row);
        }

        android.widget.TextView note = new android.widget.TextView(this);
        note.setText("提示：ROM 版权归各自所有，请自备正版镜像。");
        note.setTextSize(12);
        note.setTextColor(Theme.textSecondary());
        note.setPadding(0, (int) (8 * d), 0, 0);
        box.addView(note);

        sv.addView(box);
        new AlertDialog.Builder(this, R.style.DialogTheme)
                .setView(sv)
                .setPositiveButton("知道了", null)
                .setNeutralButton("重新查看",
                        new android.content.DialogInterface.OnClickListener() {
                    public void onClick(android.content.DialogInterface dlg, int w) {
                        getSharedPreferences("wavegba", MODE_PRIVATE)
                                .edit().putBoolean("guide_seen", false).apply();
                        showGuide();
                    }
                })
                .setCancelable(true)
                .show();
    }

    /** 全部 / ★收藏 切换条。
     *
     *  Only shown once something is starred: a two-tab bar where the second
     *  tab is always empty is just noise. */
    private void buildTabBar(android.widget.LinearLayout host) {
        float d = getResources().getDisplayMetrics().density;
        tabBar = new android.widget.LinearLayout(this);
        tabBar.setOrientation(android.widget.LinearLayout.HORIZONTAL);
        android.widget.LinearLayout.LayoutParams lp =
                new android.widget.LinearLayout.LayoutParams(
                        android.widget.LinearLayout.LayoutParams.MATCH_PARENT,
                        android.widget.LinearLayout.LayoutParams.WRAP_CONTENT);
        lp.setMargins((int) (12 * d), (int) (2 * d), (int) (12 * d), (int) (6 * d));
        tabBar.setLayoutParams(lp);

        tabAll = tabView("全部");
        tabFav = tabView("★ 收藏");
        tabBar.addView(tabAll);
        tabBar.addView(tabFav);
        host.addView(tabBar, host.indexOfChild(host) >= 0 ? 1 : 0);
    }

    private android.widget.TextView tabView(String text) {
        float d = getResources().getDisplayMetrics().density;
        android.widget.TextView t = new android.widget.TextView(this);
        t.setText(text);
        t.setTextSize(13);
        t.setGravity(android.view.Gravity.CENTER);
        int padV = (int) (7 * d);
        t.setPadding((int) (16 * d), padV, (int) (16 * d), padV);
        android.widget.LinearLayout.LayoutParams lp =
                new android.widget.LinearLayout.LayoutParams(
                        android.widget.LinearLayout.LayoutParams.WRAP_CONTENT,
                        android.widget.LinearLayout.LayoutParams.WRAP_CONTENT);
        lp.setMargins(0, 0, (int) (8 * d), 0);
        t.setLayoutParams(lp);
        t.setOnClickListener(new android.view.View.OnClickListener() {
            public void onClick(android.view.View v) {
                boolean wantFav = (v == tabFav);
                if (wantFav == showFavOnly) return;
                showFavOnly = wantFav;
                refresh();
            }
        });
        return t;
    }

    private void updateTabs() {
        if (tabBar == null) return;
        int n = library == null ? 0 : library.favoriteCount();
        // Hidden until a favourite exists; the tabs would otherwise offer a
        // view that is permanently empty.
        tabBar.setVisibility(n > 0 ? android.view.View.VISIBLE : android.view.View.GONE);
        if (tabAll != null) paintTab(tabAll, !showFavOnly, "全部");
        if (tabFav != null) paintTab(tabFav, showFavOnly, "★ 收藏 " + n);
    }

    private void paintTab(android.widget.TextView t, boolean on, String text) {
        t.setText(text);
        float d = getResources().getDisplayMetrics().density;
        android.graphics.drawable.GradientDrawable g =
                new android.graphics.drawable.GradientDrawable();
        g.setCornerRadius(14 * d);
        if (on) {
            g.setColor(Theme.accentAlpha(48));
            g.setStroke(Math.max(1, (int) d), Theme.accent());
            t.setTextColor(Theme.accent());
        } else {
            g.setColor(Theme.surface());
            g.setStroke(Math.max(1, (int) d), Theme.divider());
            t.setTextColor(Theme.textSecondary());
        }
        t.setBackgroundDrawable(g);
    }

    private void refresh() {
        maybeShowGuide();
        for (GameLibrary.Entry e : library.all()) backfillTitle(e);
        // sorted() puts starred games first; the filter then narrows to them.
        List<GameLibrary.Entry> all = showFavOnly
                ? library.favorites() : library.sorted();

        shown = match(all, query);
        titleCount(library.all().size());
        updateTabs();

        boolean searching = query != null && query.trim().length() > 0;
        if (searchBox != null) {
            searchBox.setVisibility(all.size() >= SEARCH_MIN_GAMES
                    ? View.VISIBLE : View.GONE);
        }
        if (searchHint != null) {
            if (searching) {
                searchHint.setVisibility(View.VISIBLE);
                searchHint.setText(shown.isEmpty()
                        ? "没有匹配「" + query.trim() + "」的游戏"
                        : "匹配 " + shown.size() + " / " + all.size() + " 个游戏");
            } else {
                searchHint.setVisibility(View.GONE);
            }
        }

        renderGrid();
        boolean none = shown.isEmpty();
        if (empty != null) {
            empty.setVisibility(none ? View.VISIBLE : View.GONE);
            if (none && searching) {
                empty.setText("没有匹配「" + query.trim() + "」的游戏\n换个关键词试试");
            } else if (none) {
                if (showFavOnly) {
                    empty.setText("还没有收藏\n长按游戏卡片可收藏");
                } else {
                    empty.setText("还没有游戏\n点右下角 + 添加");
                }
            }
        }
        if (scrollView != null) {
            scrollView.setVisibility(none ? View.GONE : View.VISIBLE);
        }
    }

    /* --------------------------------------------------------- 搜索匹配 -- */

    /** Filter by name.
     *
     *  The visible label is "编号 · 文件名", so a bare number has to match the
     *  number, not just the text -- someone with twenty games remembers "the
     *  one marked 7" far more readily than its file name. */
    static List<GameLibrary.Entry> match(List<GameLibrary.Entry> all, String q) {
        List<GameLibrary.Entry> out = new java.util.ArrayList<GameLibrary.Entry>();
        if (q == null || q.trim().isEmpty()) return all;
        String needle = q.trim().toLowerCase(java.util.Locale.US);
        for (GameLibrary.Entry e : all) {
            if (hits(e, needle)) out.add(e);
        }
        return out;
    }

    private static boolean hits(GameLibrary.Entry e, String needle) {
        // Exact number: "7" should find "7 · ...", not every name containing
        // a 7 somewhere in its file name.
        if (e.seq > 0 && Integer.toString(e.seq).equals(needle)) return true;

        String title = e.title == null ? "" : e.title.toLowerCase(java.util.Locale.US);
        if (title.contains(needle)) return true;

        // Pinyin initials: typing "pm" to find 宝可梦. Without this a Chinese
        // library is unsearchable on a keyboard that cannot type its name.
        String initials = initialsOf(e.title);
        if (initials.contains(needle)) return true;

        String code = e.code == null ? "" : e.code.toLowerCase(java.util.Locale.US);
        return code.contains(needle);
    }

    /** First letters of each Chinese character's pinyin, lowercased.
     *
     *  Typing "pm" to find 宝可梦. Without this a Chinese library is
     *  unsearchable from a keyboard that cannot type its name.
     *
     *  Han characters are ordered by radical in Unicode, NOT by pinyin, so
     *  the initial cannot be read off a code-point range -- an earlier attempt
     *  tried exactly that and produced empty initials for every name. GB2312
     *  does sort its level-1 block by pinyin, so the character is encoded to
     *  GB2312 and looked up by its qu-wei position. Characters outside GB2312
     *  simply drop out, which only costs matches on rare names. */
    static String initialsOf(String name) {
        if (name == null) return "";
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < name.length(); ) {
            int cp = name.codePointAt(i);
            i += Character.charCount(cp);
            char c = initialFor(cp);
            if (c != 0) sb.append(c);
        }
        return sb.toString().toLowerCase(java.util.Locale.US);
    }

    /** Qu-wei (section/position) numbers where each pinyin initial starts in
     *  the GB2312 level-1 block, in pinyin order. */
    private static final int[] PY_BOUND = {
            1601, 1637, 1833, 2078, 2274, 2302, 2433, 2594, 2787, 3106, 3212,
            3472, 3635, 3722, 3730, 3858, 4027, 4086, 4390, 4558, 4684, 4925,
            5249
    };
    private static final String PY_INITIAL = "abcdefghjklmnopqrstwxyz";

    private static char initialFor(int cp) {
        if (cp >= 'a' && cp <= 'z') return (char) cp;
        if (cp >= 'A' && cp <= 'Z') return (char) (cp - 'A' + 'a');
        if (cp < 0x4E00 || cp > 0x9FA5) return 0;      // not a Han character
        try {
            byte[] b = new String(Character.toChars(cp)).getBytes("GB2312");
            if (b.length != 2) return 0;
            int hi = b[0] & 0xFF, lo = b[1] & 0xFF;
            if (hi < 0xB0 || hi > 0xF7 || lo < 0xA1 || lo > 0xFE) return 0;
            int quwei = (hi - 0xA0) * 100 + (lo - 0xA0);
            int at = -1, lo2 = 0, hi2 = PY_BOUND.length - 1;
            while (lo2 <= hi2) {
                int mid = (lo2 + hi2) >>> 1;
                if (quwei >= PY_BOUND[mid]) { at = mid; lo2 = mid + 1; }
                else hi2 = mid - 1;
            }
            return at < 0 ? 0 : PY_INITIAL.charAt(at);
        } catch (Throwable t) {
            return 0;   // no GB2312 on this device: degrade, do not crash
        }
    }

    /** One ROM brought into the library. */
    private static final class Imported {
        String id;
        String name;       // best-effort display name
        byte[] header;     // first 0xC0 bytes, or null
    }

    /** Copy a ROM into WaveGBA/ROMs. Blocking; call off the UI thread.
     *
     *  Streams straight to disk and computes the CRC as it goes, so a 32MB
     *  ROM never has to sit in memory. */
    private Imported copyRom(android.net.Uri src) throws Exception {
        Imported r = new Imported();
        java.io.InputStream in = null;
        java.io.FileOutputStream out = null;
        try {
            in = getContentResolver().openInputStream(src);
            if (in == null) throw new java.io.IOException("null stream");

            // Sniff the magic rather than trusting the extension: ROMs arrive
            // as .gba, .bin, .zip and everything else, and a file called .gba
            // that is really a zip is common enough to matter.
            java.io.PushbackInputStream pb = new java.io.PushbackInputStream(in, 4);
            byte[] magic = new byte[4];
            int got = 0;
            while (got < 4) {
                int k = pb.read(magic, got, 4 - got);
                if (k <= 0) break;
                got += k;
            }
            boolean isZip = got == 4
                    && (magic[0] & 0xFF) == 0x50 && (magic[1] & 0xFF) == 0x4B
                    && (magic[2] & 0xFF) == 0x03 && (magic[3] & 0xFF) == 0x04;
            pb.unread(magic, 0, got);

            java.io.InputStream body;
            String innerName = null;
            if (isZip) {
                java.util.zip.ZipInputStream zis = new java.util.zip.ZipInputStream(pb);
                java.util.zip.ZipEntry ze;
                while ((ze = zis.getNextEntry()) != null) {
                    String n = ze.getName();
                    if (ze.isDirectory() || n == null) continue;
                    String low = n.toLowerCase(java.util.Locale.US);
                    // macOS resource forks sort first and are junk.
                    if (low.startsWith("__macosx") || low.contains("/__macosx")) continue;
                    if (low.endsWith(".gba") || low.endsWith(".bin") || low.endsWith(".agb")) {
                        innerName = n;
                        break;
                    }
                }
                if (innerName == null) throw new java.io.IOException("压缩包里没有 GBA ROM");
                body = zis;
            } else {
                body = pb;
            }

            File dir = library.romsDir();
            File tmp = new File(dir, "import.tmp");
            out = new java.io.FileOutputStream(tmp);

            java.util.zip.CRC32 crc = new java.util.zip.CRC32();
            byte[] buf = new byte[1 << 16];
            int n;
            long total = 0;
            byte[] head0 = new byte[0xC0];
            int headGot = 0;
            while ((n = body.read(buf)) > 0) {
                out.write(buf, 0, n);
                crc.update(buf, 0, n);
                if (headGot < 0xC0) {
                    int take = Math.min(0xC0 - headGot, n);
                    System.arraycopy(buf, 0, head0, headGot, take);
                    headGot += take;
                }
                total += n;
            }
            if (headGot >= 0xAC) {
                r.header = new byte[headGot];
                System.arraycopy(head0, 0, r.header, 0, headGot);
            }
            out.flush();
            try { out.getFD().sync(); } catch (Throwable ignored) { }
            out.close();
            out = null;
            body.close();
            body = null;

            if (total < 0x200) throw new java.io.IOException("too small");

            // CRC is taken over the extracted ROM, not the archive, so the
            // same game gets the same id whether it arrived zipped or not --
            // which is what makes de-duplication work across the two.
            r.id = String.format(java.util.Locale.US, "g%08x", crc.getValue());
            File dst = new File(dir, GameLibrary.Entry.safe(r.id) + ".gba");
            if (dst.exists()) dst.delete();
            if (!tmp.renameTo(dst)) {
                java.io.FileInputStream fi = new java.io.FileInputStream(tmp);
                java.io.FileOutputStream fo = new java.io.FileOutputStream(dst);
                while ((n = fi.read(buf)) > 0) fo.write(buf, 0, n);
                fi.close();
                fo.close();
                tmp.delete();
            }

            // Inside a zip the entry name is the only real name available;
            // the archive's own name names the archive, not the game.
            if (innerName != null) {
                r.name = new File(innerName).getName();
            } else {
                r.name = fileNameOf(src);
            }
            return r;
        } finally {
            try { if (out != null) out.close(); } catch (Throwable ignored) { }
            try { if (in != null) in.close(); } catch (Throwable ignored) { }
        }
    }

    /** Pick one file, import it, then ask for a name. */
    private void importRom(android.net.Uri src) {
        new Thread(new Runnable() {
            public void run() {
                Imported r = null;
                Throwable err = null;
                try { r = copyRom(src); }
                catch (Throwable t) { err = t; }

                final Imported done = r;
                final Throwable failure = err;
                runOnUiThread(new Runnable() {
                    public void run() {
                        if (failure != null || done == null || done.id == null) {
                            Log.e(TAG, "导入失败", failure);
                            Toast.makeText(GameLibraryActivity.this,
                                    "导入失败，换个文件管理器试试", Toast.LENGTH_LONG).show();
                            return;
                        }
                        // Prefer the real file name; fall back to the cart
                        // title rather than "rom".
                        String title = done.name;
                        if (title == null || title.trim().isEmpty()
                                || GameLibrary.looksGenerated(title)) {
                            String cart = GameLibrary.cartTitle(done.header);
                            if (cart != null) title = cart;
                        }
                        if (title == null || title.trim().isEmpty()) title = "rom";
                        askName(done.id, title, done.header, src.toString());
                    }
                });
            }
        }).start();
    }

    /** Import a whole batch. Names come from the file names -- asking once
     *  per file would mean N dialogs for a folder scan. Anything the player
     *  wants renamed can be renamed by long-pressing its card afterwards. */
    private void importMany(final java.util.List<Candidate> picked) {
        final android.app.ProgressDialog pd = new android.app.ProgressDialog(this);
        pd.setMessage("正在导入…");
        pd.setProgressStyle(android.app.ProgressDialog.STYLE_HORIZONTAL);
        pd.setMax(picked.size());
        pd.setCancelable(false);
        pd.show();

        new Thread(new Runnable() {
            public void run() {
                int added = 0, skipped = 0, failed = 0;
                for (int i = 0; i < picked.size(); i++) {
                    Candidate c = picked.get(i);
                    final int at = i + 1;
                    runOnUiThread(new Runnable() {
                        public void run() {
                            pd.setProgress(at);
                            pd.setMessage("正在导入 " + at + "/" + picked.size());
                        }
                    });
                    try {
                        Imported r = copyRom(c.uri);
                        if (r == null || r.id == null) { failed++; continue; }
                        if (library.find(r.id) != null) { skipped++; continue; }

                        String title = r.name;
                        if (title == null || title.trim().isEmpty()
                                || GameLibrary.looksGenerated(title)) {
                            String cart = GameLibrary.cartTitle(r.header);
                            if (cart != null) title = cart;
                        }
                        if (title == null || title.trim().isEmpty()) title = "rom";
                        title = stripExt(title);

                        library.put(r.id, title,
                                "file://" + new File(library.romsDir(),
                                        GameLibrary.Entry.safe(r.id) + ".gba").getAbsolutePath(),
                                "", null);
                        // Only mark it named when the name is a real one. A
                        // generated name has to stay eligible for backfill.
                        if (!GameLibrary.looksGenerated(title) && !"rom".equals(title)) {
                            library.name(r.id, title);
                        }
                        added++;
                    } catch (Throwable t) {
                        failed++;
                        Log.w(TAG, "批量导入失败：" + c.name, t);
                    }
                }
                library.save();
                final int a = added, sk = skipped, f = failed;
                runOnUiThread(new Runnable() {
                    public void run() {
                        pd.dismiss();
                        Toast.makeText(GameLibraryActivity.this,
                                "导入完成：新增 " + a + " 个"
                                        + (sk > 0 ? "，已存在 " + sk + " 个" : "")
                                        + (f > 0 ? "，失败 " + f + " 个" : ""),
                                Toast.LENGTH_LONG).show();
                        refresh();
                    }
                });
            }
        }).start();
    }

    private static String stripExt(String name) {
        if (name == null) return null;
        int i = name.lastIndexOf('.');
        return i > 0 ? name.substring(0, i) : name;
    }

    /* ------------------------------------------------------ 文件夹扫描 --- */

    /** A ROM found by scanning a folder. */
    private static final class Candidate {
        android.net.Uri uri;
        String name;
        long size;
        boolean checked = true;
    }

    private static final int SCAN_MAX_DEPTH = 6;
    private static final int SCAN_MAX_FOUND = 200;

    /** Ask for a folder, then walk it for ROMs. */
    private void pickFolder() {
        try {
            // ACTION_OPEN_DOCUMENT_TREE is API 21+; reached by name because
            // this build's android.jar predates it.
            Intent i = new Intent("android.intent.action.OPEN_DOCUMENT_TREE");
            MainActivity.addPersistableFlags(i);
            startActivityForResult(i, REQ_TREE);
        } catch (Throwable t) {
            Log.e(TAG, "无法打开文件夹选择器", t);
            Toast.makeText(this, "无法打开文件夹选择器", Toast.LENGTH_SHORT).show();
        }
    }

    private void scanFolder(final android.net.Uri treeUri) {
        final android.app.ProgressDialog pd = new android.app.ProgressDialog(this);
        pd.setMessage("正在扫描文件夹…");
        pd.setCancelable(true);
        pd.show();

        new Thread(new Runnable() {
            public void run() {
                final java.util.List<Candidate> found =
                        new java.util.ArrayList<Candidate>();
                Throwable err = null;
                try {
                    // DocumentsContract is missing from this build's
                    // android.jar but present on every device we run on (API
                    // 19+), so reach it by name. The column names are fixed
                    // public constants, so they are written literally.
                    Class<?> dc = Class.forName("android.provider.DocumentsContract");
                    java.lang.reflect.Method getTreeId =
                            dc.getMethod("getTreeDocumentId", android.net.Uri.class);
                    java.lang.reflect.Method buildChild = dc.getMethod(
                            "buildChildDocumentsUriUsingTree",
                            android.net.Uri.class, String.class);
                    java.lang.reflect.Method buildDoc = dc.getMethod(
                            "buildDocumentUriUsingTree",
                            android.net.Uri.class, String.class);

                    String treeId = (String) getTreeId.invoke(null, treeUri);
                    walk(treeUri, treeId, 0, found, buildChild, buildDoc);
                } catch (Throwable t) {
                    err = t;
                }

                final Throwable failure = err;
                runOnUiThread(new Runnable() {
                    public void run() {
                        pd.dismiss();
                        if (failure != null) {
                            Log.e(TAG, "扫描失败", failure);
                            Toast.makeText(GameLibraryActivity.this,
                                    "扫描失败，换个文件管理器试试",
                                    Toast.LENGTH_LONG).show();
                            return;
                        }
                        if (found.isEmpty()) {
                            Toast.makeText(GameLibraryActivity.this,
                                    "这个文件夹里没有找到 GBA ROM（.gba / .bin / .agb / .zip）",
                                    Toast.LENGTH_LONG).show();
                            return;
                        }
                        showScanResults(found);
                    }
                });
            }
        }).start();
    }

    private void walk(android.net.Uri treeUri, String docId, int depth,
                      java.util.List<Candidate> out,
                      java.lang.reflect.Method buildChild,
                      java.lang.reflect.Method buildDoc) {
        if (depth > SCAN_MAX_DEPTH || out.size() >= SCAN_MAX_FOUND) return;

        android.net.Uri children;
        try {
            children = (android.net.Uri) buildChild.invoke(null, treeUri, docId);
        } catch (Throwable t) {
            return;
        }
        android.database.Cursor c = null;
        try {
            c = getContentResolver().query(children,
                    new String[]{"document_id", "_display_name", "mime_type", "_size"},
                    null, null, null);
            if (c == null) return;
            int iId = c.getColumnIndex("document_id");
            int iName = c.getColumnIndex("_display_name");
            int iMime = c.getColumnIndex("mime_type");
            int iSize = c.getColumnIndex("_size");
            while (c.moveToNext() && out.size() < SCAN_MAX_FOUND) {
                String id = iId >= 0 ? c.getString(iId) : null;
                if (id == null) continue;
                String name = iName >= 0 ? c.getString(iName) : null;
                String mime = iMime >= 0 ? c.getString(iMime) : null;
                long size = iSize >= 0 ? c.getLong(iSize) : -1;

                if ("vnd.android.document/directory".equals(mime)) {
                    walk(treeUri, id, depth + 1, out, buildChild, buildDoc);
                    continue;
                }
                if (name == null) continue;
                String low = name.toLowerCase(java.util.Locale.US);
                if (!(low.endsWith(".gba") || low.endsWith(".bin")
                        || low.endsWith(".agb") || low.endsWith(".zip"))) continue;

                android.net.Uri u;
                try {
                    u = (android.net.Uri) buildDoc.invoke(null, treeUri, id);
                } catch (Throwable t) {
                    continue;
                }
                if (u == null) continue;

                Candidate cd = new Candidate();
                cd.uri = u;
                cd.name = name;
                cd.size = size;
                out.add(cd);
            }
        } catch (Throwable t) {
            Log.w(TAG, "扫描子目录失败", t);
        } finally {
            if (c != null) try { c.close(); } catch (Throwable ignored) { }
        }
    }

    private void showScanResults(final java.util.List<Candidate> found) {
        String[] names = new String[found.size()];
        boolean[] checked = new boolean[found.size()];
        for (int i = 0; i < found.size(); i++) {
            Candidate c = found.get(i);
            names[i] = stripExt(c.name)
                    + (c.size > 0 ? "  ·  " + (c.size / 1024) + " KB" : "");
            checked[i] = true;
        }
        new AlertDialog.Builder(this, R.style.DialogTheme)
                .setTitle("找到 " + found.size() + " 个 ROM")
                .setMultiChoiceItems(names, checked,
                        (d, which, isChecked) -> found.get(which).checked = isChecked)
                .setPositiveButton("导入选中", (d, w) -> {
                    d.dismiss();
                    java.util.List<Candidate> picked =
                            new java.util.ArrayList<Candidate>();
                    for (Candidate c : found) if (c.checked) picked.add(c);
                    if (picked.isEmpty()) {
                        Toast.makeText(this, "没有选中任何 ROM", Toast.LENGTH_SHORT).show();
                        return;
                    }
                    importMany(picked);
                })
                .setNegativeButton("取消", null)
                .show();
    }

    /** The + button: one file, or a whole folder. */
    private void showAddMenu() {
        String[] items = {"选择单个文件", "扫描文件夹（批量导入）"};
        new AlertDialog.Builder(this, R.style.DialogTheme)
                .setTitle("添加游戏")
                .setItems(items, (d, which) -> {
                    d.dismiss();
                    if (which == 0) pickRom();
                    else pickFolder();
                })
                .show();
    }

    /** Ask the player what to call this game.
     *
     *  Everything else we can derive is unreliable: the file manager may not
     *  expose a display name, and the cart title is only 12 uppercase
     *  characters. Asking once at import time is the one approach that always
     *  yields the name the player actually wants. */
    private void askName(final String id, final String guess,
                         final byte[] head, final String originUri) {
        final android.widget.EditText input = new android.widget.EditText(this);
        input.setSingleLine(true);
        input.setText(guess == null ? "" : guess);
        input.setHint("游戏名");
        input.setSelectAllOnFocus(true);
        input.setImeOptions(android.view.inputmethod.EditorInfo.IME_ACTION_DONE);
        int pad = (int) (16 * getResources().getDisplayMetrics().density);
        input.setPadding(pad, pad, pad, pad);

        android.widget.LinearLayout box = new android.widget.LinearLayout(this);
        box.setOrientation(android.widget.LinearLayout.VERTICAL);
        box.setPadding(pad, 0, pad, 0);
        box.addView(input);

        android.widget.TextView tip = new android.widget.TextView(this);
        tip.setText("重命名后可长按卡片再次修改");
        tip.setTextColor(0xFF9AA3AF);
        tip.setTextSize(12);
        tip.setPadding(0, (int) (8 * getResources().getDisplayMetrics().density), 0, 0);
        box.addView(tip);

        // Enter on the keyboard confirms, so naming is a two-keystroke job.
        input.setOnEditorActionListener(
                new android.widget.TextView.OnEditorActionListener() {
            public boolean onEditorAction(android.widget.TextView v, int actionId,
                                          android.view.KeyEvent event) {
                if (actionId == android.view.inputmethod.EditorInfo.IME_ACTION_DONE
                        || (event != null && event.getKeyCode()
                            == android.view.KeyEvent.KEYCODE_ENTER
                            && event.getAction() == android.view.KeyEvent.ACTION_UP)) {
                    commitName(id, input, head, originUri);
                    return true;
                }
                return false;
            }
        });

        final android.app.AlertDialog dlg = new android.app.AlertDialog.Builder(
                this, R.style.DialogTheme)
                .setTitle("给这个游戏起个名")
                .setView(box)
                .setPositiveButton("确定", null)      // wired below: no auto-dismiss
                .setNegativeButton("取消", null)
                .create();

        dlg.setOnShowListener(new android.content.DialogInterface.OnShowListener() {
            public void onShow(android.content.DialogInterface d) {
                dlg.getButton(android.app.AlertDialog.BUTTON_POSITIVE)
                   .setOnClickListener(new android.view.View.OnClickListener() {
                    public void onClick(android.view.View v) {
                        commitName(id, input, head, originUri);
                    }
                });
                dlg.getButton(android.app.AlertDialog.BUTTON_NEGATIVE)
                   .setOnClickListener(new android.view.View.OnClickListener() {
                    public void onClick(android.view.View v) {
                        finishNaming(id, guess, originUri, false);
                    }
                });
            }
        });
        dlg.setCanceledOnTouchOutside(false);
        namingDialog = dlg;
        dlg.show();
    }

    /** Read the field, and only proceed when it is actually filled in --
     *  otherwise the entry would be created with an empty name. */
    private void commitName(String id, android.widget.EditText input,
                            byte[] head, String originUri) {
        String v = input.getText().toString().trim();
        if (v.isEmpty()) {
            Toast.makeText(this, "请输入游戏名", Toast.LENGTH_SHORT).show();
            return;
        }
        finishNaming(id, v, originUri, true);
    }

    private void finishNaming(String id, String title, String originUri,
                              boolean thenLaunch) {
        if (namingDialog != null) {
            try { namingDialog.dismiss(); } catch (Throwable ignored) { }
            namingDialog = null;
        }
        if (title == null || title.trim().isEmpty()) {
            title = "rom";
        }
        library.put(id, title.trim(),
                "file://" + new File(library.romsDir(),
                        GameLibrary.Entry.safe(id) + ".gba").getAbsolutePath(),
                "", originUri);
        library.save();
        library.name(id, title);
        refresh();

        if (thenLaunch) {
            String local = library.localUriFor(id, null);
            if (local != null) launch(android.net.Uri.parse(local));
        }
    }

    /** File name for display, from the picker's own metadata. */
    private String fileNameOf(android.net.Uri uri) {
        return GameLibrary.fileNameOf(this, uri);
    }

    /* ---------------------------------------------------------- storage --- */

    private File preferredSaveDir() {
        return new File(android.os.Environment.getExternalStorageDirectory(), "WaveGBA/Save");
    }

    private File fallbackSaveDir() {
        File ext = getExternalFilesDir(null);
        return new File(ext != null ? ext : getFilesDir(), "WaveGBA/Save");
    }

    /** Reuses whatever MainActivity settled on, so both screens agree. */
    /** See MainActivity.resolveSaveDir: public directory first, always, and
     *  the private fallback is never remembered. */
    private File resolveSaveDir() {
        File preferred = preferredSaveDir();
        if (writable(preferred)) {
            getSharedPreferences("wavegba", MODE_PRIVATE).edit()
                    .putString(PREF_SAVE_DIR, preferred.getAbsolutePath()).apply();
            return preferred;
        }

        String saved = getSharedPreferences("wavegba", MODE_PRIVATE)
                .getString(PREF_SAVE_DIR, null);
        if (saved != null) {
            File f = new File(saved);
            if (writable(f) && !isPrivatePath(f)) return f;
        }

        File fb = fallbackSaveDir();
        writable(fb);                    // best effort, still usable
        return fb;
    }

    /** Anything under Android/data/<pkg> is app-private: wiped on uninstall
     *  and invisible to file managers. Never mistake it for a real choice. */
    private boolean isPrivatePath(File f) {
        String p = f.getAbsolutePath();
        for (String marker : new String[]{"/Android/data/", "/data/data/"}) {
            if (p.contains(marker)) return true;
        }
        return false;
    }

    /** mkdirs + a real write probe: mkdirs() alone can lie. */
    private boolean writable(File d) {
        try {
            if (!d.exists() && !d.mkdirs()) return false;
            if (!d.isDirectory()) return false;
            File probe = new File(d, ".wavegba_probe");
            probe.createNewFile();
            boolean ok = probe.exists();
            probe.delete();
            return ok;
        } catch (Throwable t) {
            return false;
        }
    }

    private boolean hasStorageAccess() {
        if (android.os.Build.VERSION.SDK_INT >= 30) {
            try {
                java.lang.reflect.Method m = android.os.Environment.class
                        .getMethod("isExternalStorageManager");
                return Boolean.TRUE.equals(m.invoke(null));
            } catch (Throwable t) {
                return false;
            }
        }
        if (android.os.Build.VERSION.SDK_INT >= 23) {
            try {
                java.lang.reflect.Method m = android.content.Context.class
                        .getMethod("checkSelfPermission", String.class);
                int r = (Integer) m.invoke(this,
                        android.Manifest.permission.WRITE_EXTERNAL_STORAGE);
                return r == getPackageManager().PERMISSION_GRANTED;
            } catch (Throwable t) {
                Log.w(TAG, "checkSelfPermission 不可用", t);
            }
        }
        return true;
    }

    /** Explain first, then jump to the setting.
     *
     *  A bare startActivity() to a settings page is easy to miss and looks
     *  like the app just flashed and came back. Showing what to toggle first
     *  is the difference between "granted" and "why is /sdcard/WaveGBA empty". */
    private void requestStorageAccess() {
        if (askedPermission) return;      // never loop: the setting is manual
        askedPermission = true;

        if (writable(preferredSaveDir())) { refresh(); return; }

        new android.app.AlertDialog.Builder(this, R.style.DialogTheme)
                .setTitle("需要「所有文件访问权限」")
                .setMessage("WaveGBA 想把所有数据放在根目录的\n"
                        + preferredSaveDir().getParentFile().getAbsolutePath()
                        + "\n（游戏、存档、封面，卸载后依然保留）\n\n"
                        + "请在接下来的页面里找到本应用，打开「允许访问所有文件」。\n"
                        + "不授权的话数据会存到 Android/data/ 里，卸载即丢失。")
                .setPositiveButton("去设置", new android.content.DialogInterface.OnClickListener() {
                    public void onClick(android.content.DialogInterface d, int w) {
                        openAllFilesAccessSetting();
                    }
                })
                .setNegativeButton("以后再说", null)
                .show();
    }

    private void openAllFilesAccessSetting() {
        try {
            Intent i;
            if (android.os.Build.VERSION.SDK_INT >= 30) {
                i = new Intent("android.settings.MANAGE_APP_ALL_FILES_ACCESS_PERMISSION");
                i.setData(android.net.Uri.parse("package:" + getPackageName()));
            } else {
                i = new Intent("android.settings.APPLICATION_DETAILS_SETTINGS");
                i.setData(android.net.Uri.parse("package:" + getPackageName()));
            }
            startActivity(i);
        } catch (Throwable t) {
            Log.w(TAG, "无法打开存储权限设置", t);
            Toast.makeText(this, "无法打开设置页，请手动在系统设置里授权",
                    Toast.LENGTH_LONG).show();
        }
    }

    /** Copy the library index and covers from one WaveGBA root to another. */
    private void copyTree(File from, File to) {
        if (from == null || to == null || from.equals(to)) return;
        try {
            to.mkdirs();
            File[] files = from.listFiles();
            if (files == null) return;
            for (File f : files) {
                File dst = new File(to, f.getName());
                if (f.isDirectory()) { copyTree(f, dst); continue; }
                if (dst.exists()) continue;
                java.io.FileInputStream in = new java.io.FileInputStream(f);
                java.io.FileOutputStream out = new java.io.FileOutputStream(dst);
                byte[] buf = new byte[1 << 16];
                int n;
                while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
                in.close();
                out.close();
            }
        } catch (Throwable t) {
            Log.w(TAG, "目录迁移失败", t);
        }
    }

    private void pickRom() {
        try {
            // ACTION_OPEN_DOCUMENT is API 19+; this build's android.jar is
            // older, so reach it the same way MainActivity does: by name.
            Intent i = new Intent("android.intent.action.OPEN_DOCUMENT");
            i.addCategory(Intent.CATEGORY_OPENABLE);
            i.setType("*/*");
            MainActivity.addPersistableFlags(i);
            startActivityForResult(i, REQ_PICK);
        } catch (Throwable t) {
            Log.e(TAG, "无法打开文件选择器", t);
            Toast.makeText(this, "无法打开文件选择器", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (req == REQ_PICK && res == RESULT_OK && data != null && data.getData() != null) {
            MainActivity.persistUri(this, data.getData());   // harmless if refused
            importRom(data.getData());
        } else if (req == REQ_TREE && res == RESULT_OK && data != null
                && data.getData() != null) {
            MainActivity.persistUri(this, data.getData());
            // Hold the grant: the scan runs for seconds and the imports come
            // after, well past the picker's one-shot access. Reached by
            // reflection because this build's android.jar predates the method
            // and the flag; both are API 19+ / public constants.
            try {
                android.content.ContentResolver cr = getContentResolver();
                int flags = Intent.class.getField("FLAG_GRANT_READ_URI_PERMISSION")
                        .getInt(null);
                int persist = Intent.class.getField("FLAG_GRANT_PERSISTABLE_URI_PERMISSION")
                        .getInt(null);
                java.lang.reflect.Method m = cr.getClass().getMethod(
                        "takePersistableUriPermission",
                        android.net.Uri.class, int.class);
                m.invoke(cr, data.getData(), flags | persist);
            } catch (Throwable ignored) { }
            scanFolder(data.getData());
        }
    }

    private void launch(android.net.Uri uri) {
        Intent i = new Intent(this, MainActivity.class);
        i.putExtra(MainActivity.EXTRA_ROM_URI, uri.toString());
        startActivity(i);
    }

    /* ------------------------------------------------------------ adapter */


    /** Give a poor title one more chance: if we still hold the ROM, read the
     *  cart title out of it and use that instead of a generated id. */
    private void backfillTitle(GameLibrary.Entry e) {
        if (e.named) return;                       // player chose this name
        if (!GameLibrary.looksGenerated(e.title) && !"rom".equals(e.title)) return;
        File f = new File(library.romsDir(), GameLibrary.Entry.safe(e.id) + ".gba");
        if (!f.exists()) return;
        byte[] h = new byte[0xC0];
        try {
            java.io.FileInputStream in = new java.io.FileInputStream(f);
            int got = in.read(h);
            in.close();
            if (got < 0xAC) return;
        } catch (Throwable t) {
            return;
        }
        String cart = GameLibrary.cartTitle(h);
        if (cart == null) return;
        e.title = cart;
        library.save();
    }

    /** Open an entry: always prefer our imported copy over the original
     *  content:// uri, which may no longer resolve. */
    private void open(GameLibrary.Entry e) {
        String local = library.localUriFor(e.id, null);
        if (local != null) { launch(android.net.Uri.parse(local)); return; }

        android.net.Uri u = null;
        try { u = android.net.Uri.parse(e.uri); } catch (Throwable ignored) { }
        if (u != null && readable(u)) { launch(u); return; }

        Toast.makeText(this, "这个游戏的文件已失效，请长按移除后重新添加",
                Toast.LENGTH_LONG).show();
    }

    /** Cheap probe: can we still open this uri at all? */
    private boolean readable(android.net.Uri u) {
        try {
            java.io.InputStream in = getContentResolver().openInputStream(u);
            if (in == null) return false;
            byte[] b = new byte[16];
            int n = in.read(b);
            in.close();
            return n > 0;
        } catch (Throwable t) {
            return false;
        }
    }

    private void confirmRemove(final GameLibrary.Entry e) {
        String has = library.localUriFor(e.id, null);
        final String favAction = e.favorite ? "取消收藏" : "★ 收藏（置顶）";
        java.util.List<String> list = new java.util.ArrayList<String>();
        list.add(favAction);
        list.add("重命名");
        if (has == null) list.add("重新导入 ROM");
        list.add("从库中移除");
        final String[] actions = list.toArray(new String[0]);

        new AlertDialog.Builder(this, R.style.DialogTheme)
                .setTitle(GameLibrary.label(e))
                .setItems(actions, new android.content.DialogInterface.OnClickListener() {
                    public void onClick(android.content.DialogInterface d, int which) {
                        String a = actions[which];
                        if (a.equals(favAction)) {
                            library.setFavorite(e.id, !e.favorite);
                            Toast.makeText(GameLibraryActivity.this,
                                    e.favorite ? "已收藏，置顶显示" : "已取消收藏",
                                    Toast.LENGTH_SHORT).show();
                            // Unstarring the last favourite while its tab is
                            // open would leave the view permanently empty.
                            if (showFavOnly && library.favoriteCount() == 0)
                                showFavOnly = false;
                            refresh();
                            return;
                        }
                        if (a.equals("重命名")) { promptRename(e); return; }
                        if (a.equals("重新导入 ROM")) { pickRomFor(e); return; }
                        confirmRemoveNow(e);
                    }
                })
                .setNegativeButton("取消", null)
                .show();
    }

    private void confirmRemoveNow(final GameLibrary.Entry e) {
        new AlertDialog.Builder(this, R.style.DialogTheme)
                .setTitle("移除 " + GameLibrary.label(e) + "？")
                .setMessage("不会删除 ROM 文件和存档")
                .setPositiveButton("移除", new android.content.DialogInterface.OnClickListener() {
                    public void onClick(android.content.DialogInterface d, int w) {
                        library.remove(e.id);
                        refresh();
                    }
                })
                .setNegativeButton("取消", null)
                .show();
    }

    /** Re-import a ROM for an entry whose copy is missing, keeping its name
     *  and number. */
    private android.net.Uri reimportUri = null;

    private void pickRomFor(GameLibrary.Entry e) {
        try {
            Intent i = new Intent("android.intent.action.OPEN_DOCUMENT");
            i.addCategory(Intent.CATEGORY_OPENABLE);
            i.setType("*/*");
            MainActivity.addPersistableFlags(i);
            startActivityForResult(i, REQ_PICK);
        } catch (Throwable t) {
            Toast.makeText(this, "无法打开文件选择器", Toast.LENGTH_SHORT).show();
        }
    }

    /** Lets the user fix an entry whose name came out as a generated id. */
    private void promptRename(final GameLibrary.Entry e) {
        final android.widget.EditText input = new android.widget.EditText(this);
        input.setSingleLine(true);
        input.setText(GameLibrary.looksGenerated(e.title) ? "" : e.title);
        input.setHint("游戏名");
        int pad = (int) (16 * getResources().getDisplayMetrics().density);
        input.setPadding(pad, pad, pad, pad);

        android.widget.LinearLayout box = new android.widget.LinearLayout(this);
        box.setOrientation(android.widget.LinearLayout.VERTICAL);
        box.setPadding(pad, 0, pad, 0);
        box.addView(input);

        if (GameLibrary.looksGenerated(e.title)) {
            android.widget.TextView tip = new android.widget.TextView(this);
            tip.setText("当前显示的是自动生成的编号名，建议改成文件名");
            tip.setTextColor(0xFF9AA3AF);
            tip.setTextSize(12);
            box.addView(tip);
        }

        new AlertDialog.Builder(this, R.style.DialogTheme)
                .setTitle("重命名")
                .setView(box)
                .setPositiveButton("保存", new android.content.DialogInterface.OnClickListener() {
                    public void onClick(android.content.DialogInterface d, int w) {
                        String v = input.getText().toString().trim();
                        if (v.isEmpty()) return;
                        library.name(e.id, v);
                        refresh();
                    }
                })
                .setNegativeButton("取消", null)
                .show();
    }

    /** Rounded card backing so the grid reads as a set of tiles. */
    private Drawable cardBackground() {
        float density = getResources().getDisplayMetrics().density;
        int r = (int) (14 * density);
        android.graphics.drawable.GradientDrawable g =
                new android.graphics.drawable.GradientDrawable();
        g.setColor(0xFF17171C);
        g.setCornerRadius(r);
        return g;
    }

    /** Clip a bitmap to rounded corners.
     *
     *  Done in code because there is no XML or View attribute for it on the
     *  old platform this builds against: the cover is inset inside a rounded
     *  card, and square corners there look like a bug. */
    private static Bitmap roundCorners(Bitmap src, float radius) {
        if (src == null) return null;
        int w = src.getWidth(), h = src.getHeight();
        if (w <= 0 || h <= 0) return src;
        Bitmap out = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(out);
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        android.graphics.RectF box = new android.graphics.RectF(0, 0, w, h);
        c.drawRoundRect(box, radius, radius, p);
        p.setXfermode(new android.graphics.PorterDuffXfermode(
                android.graphics.PorterDuff.Mode.SRC_IN));
        c.drawBitmap(src, 0, 0, p);
        return out;
    }

    private Drawable coverFor(GameLibrary.Entry e) {
        int w = colWidth > 0 ? colWidth : 96;
        int h = coverHeight > 0 ? coverHeight : 72;
        File f = library.coverFile(e);
        if (f.exists()) {
            Bitmap raw = BitmapFactory.decodeFile(f.getAbsolutePath());
            if (raw != null) {
                // Center-crop to the tile size first, then round the corners:
                // rounding a full-size shot would round away most of the image
                // once scaled down.
                Bitmap scaled = android.media.ThumbnailUtils
                        .extractThumbnail(raw, w, h);
                if (scaled != raw) raw.recycle();
                return new BitmapDrawable(getResources(), rounded(scaled));
            }
        }
        return placeholder(GameLibrary.label(e), w, h);
    }

    /** Round the corners of an already-scaled bitmap. */
    private Bitmap rounded(Bitmap src) {
        float density = getResources().getDisplayMetrics().density;
        int r = Math.min((int) (12 * density), Math.min(src.getWidth(), src.getHeight()) / 2);
        Bitmap out = Bitmap.createBitmap(src.getWidth(), src.getHeight(),
                Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(out);
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        c.drawRoundRect(new android.graphics.RectF(0, 0, src.getWidth(), src.getHeight()),
                r, r, p);
        p.setXfermode(new android.graphics.PorterDuffXfermode(
                android.graphics.PorterDuff.Mode.SRC_IN));
        c.drawBitmap(src, 0, 0, p);
        if (out != src) src.recycle();
        return out;
    }

    /** A generated cover: gradient keyed off the title, so every game looks
     *  distinct even before it has been played once. */
    private Drawable placeholder(String title, int w, int h) {
        if (w <= 0) w = 96;
        if (h <= 0) h = 78;
        Bitmap bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(bmp);

        int hash = title == null ? 0 : title.hashCode();
        int h1 = Color.HSVToColor(new float[]{Math.abs(hash % 360), 0.55f, 0.95f});
        int h2 = Color.HSVToColor(new float[]{(Math.abs(hash % 360) + 40) % 360, 0.6f, 0.7f});
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        p.setShader(new LinearGradient(0, 0, w, h, h1, h2, Shader.TileMode.CLAMP));
        c.drawRect(0, 0, w, h, p);

        String letter = (title == null || title.length() == 0)
                ? "?" : title.substring(0, 1).toUpperCase();
        Paint t = new Paint(Paint.ANTI_ALIAS_FLAG);
        t.setColor(0xCCFFFFFF);
        t.setTextSize(Math.min(w, h) * 0.42f);
        t.setTextAlign(Paint.Align.CENTER);
        t.setTypeface(android.graphics.Typeface.create("sans-serif-medium",
                android.graphics.Typeface.NORMAL));
        android.graphics.Paint.FontMetrics fm = t.getFontMetrics();
        c.drawText(letter, w / 2f, h / 2f - (fm.ascent + fm.descent) / 2, t);
        float r = 10 * getResources().getDisplayMetrics().density;
        return new BitmapDrawable(getResources(), roundCorners(bmp, r));
    }

    /** "刚刚 / 5 分钟前 / 3 天前 / 2025-10-01" */
    private static String relativeTime(long ms) {
        long diff = System.currentTimeMillis() - ms;
        if (diff < 0) diff = 0;
        long min = diff / 60000;
        if (min < 1) return "刚刚";
        if (min < 60) return min + " 分钟前";
        long hr = min / 60;
        if (hr < 24) return hr + " 小时前";
        long day = hr / 24;
        if (day < 30) return day + " 天前";
        return new java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.US)
                .format(new java.util.Date(ms));
    }
}
