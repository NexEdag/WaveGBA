package com.wavegba;

import android.app.Activity;
import android.graphics.Bitmap;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.Settings;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.content.pm.ActivityInfo;
import android.content.res.Configuration;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.ImageView;
import android.widget.ScrollView;
import android.widget.Button;
import android.graphics.BitmapFactory;
import android.widget.LinearLayout;
import android.widget.FrameLayout;
import android.widget.Toast;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.InputStream;

/** Single-screen host: picks a ROM, then runs it full screen with a touch pad.
 *  界面文案已汉化，并带倍速（0.5x ~ 4x）控制。 */
public class MainActivity extends Activity implements VirtualPad.Listener {

    private static final String TAG = "WaveGBA";
    private static final int REQ_ROM     = 1001;
    private static final int REQ_STORAGE = 1002;

    /** 可选的倍速档位。
     *
     *  The top few are aspirational: simulating GBA at 16x is 955 frames a
     *  second, which no phone currently manages. They are offered anyway
     *  because the useful ceiling depends on the game and the device, and
     *  because there is no way to find out what a given phone can do other
     *  than trying. What stops this from being misleading is that the menu
     *  reports the speed actually being achieved, not just the one asked for. */
    private static final double[] SPEEDS = {0.5, 1.0, 1.5, 2.0, 3.0, 4.0,
                                            6.0, 8.0, 12.0, 16.0, 24.0, 32.0, 64.0};
    private static final String[] SPEED_LABELS = {"0.5x 慢放", "1.0x 正常", "1.5x",
                                                  "2.0x", "3.0x", "4.0x",
                                                  "6.0x", "8.0x", "12.0x", "16.0x",
                                                  "24.0x", "32.0x", "64.0x"};

    /** Above this, audio is muted while playing.
     *
     *  Not a preference -- a limit of the way audio reaches us. The core writes
     *  into an 8192-frame ring, and the batch callback silently drops whatever
     *  does not fit. At 32x a pass produces 17145 frames, so 16633 are thrown
     *  away every 16.7ms: what is left is a 520ms hole followed by a fragment,
     *  sixty times a second. The discontinuity is created inside the core, so
     *  no amount of smoothing here can turn it back into music.
     *
     *  8x is where it stops being recognisable. Measured as the fraction of
     *  output that is cross-fade rather than audio: 4x is 15%, 8x is 35%,
     *  16x is 75%, and past that the splices overlap. */
    private static final double AUDIO_MAX_SPEED = 8.0;

    /* 屏幕方向，含义与 MyBoy 的 Screen orientation 一致 */
    /** 应用版本，与 AndroidManifest 的 versionName 保持一致。 */
    private static final String APP_VERSION = "1.1.1";

    /** 更新日志，显示在"关于"里。 */
    private static final String CHANGELOG =
            "更新日志\n"
            + "v1.1.1（当前）\n"
            + "· 新增：倍速档位扩展到 64x，共 13 档\n"
            + "  - 0.5 / 1 / 1.5 / 2 / 3 / 4 / 6 / 8 / 12 / 16 / 24 / 32 / 64\n"
            + "  - 跑不到设定值时菜单如实显示\u201c实际 Nx\u201d\n"
            + "  - 快进键不再把已在 4x 以上的速度降回 4x\n"
            + "· 新增：8x 及以上自动降低画面刷新率\n"
            + "  - 8x 画 30fps、16x 画 20fps、32x 及以上 15fps\n"
            + "  - 录屏时始终逐帧，跳帧会丢掉视频里的帧\n"
            + "· 调整：8x 以上自动静音\n"
            + "  - 核心音频环形缓冲仅 8192 帧，32x 每周期丢 16633 帧\n"
            + "  - 断裂在核心侧产生，Java 侧无法还原\n"
            + "· 修复：录屏视频慢放一倍\n"
            + "  - onFrameDrawn() 每轮被调用两次，时间戳推进了两倍\n"
            + "· 实测：NEON 无收益，未启用\n"
            + "  - 三处调用点无函数实现，且 gba.c 未 include neon.h\n"
            + "  - -O3 已自动展开为 NEON 寄存器直写，手写版指令数更多\n"
            + "  - 端到端基准差值在噪声内；4 个 ROM 的 hash 完全一致\n"
            + "· 重构：三个 ABI 的 native so 用当前源码完整重编\n"
            + "\n"
            + "v1.1.0\n"
            + "· 新增：圆形 HSV 色盘取色——角度选色相，半径选饱和度\n"
            + "  - 取代原来的彩虹滑条；滑条只能调色相，饱和度是写死的\n"
            + "  - 手指落在哪就取哪个颜色，真正所见即所得\n"
            + "\nv1.0.5\n"
            + "· 修复：L / R 键位错位\n"
            + "  - 按 L 无反应、按 R 触发 L、真正的 R 从未被触发\n"
            + "  - 位定义改为 JOYPAD_L = 10 / JOYPAD_R = 11\n"
            + "· 修复：电池存档写成非标准的 136KB\n"
            + "  - 写完后裁剪到 512B / 8KB / 32KB / 64KB / 128KB 标准尺寸\n"
            + "  - 现在导出的 .sav 可被 mGBA / MyBoy 等直接识别\n"
            + "· 修复：录屏开始后菜单仍显示\u201c录制视频\u201d，不会变成\u201c停止录制\u201d\n"
            + "  - 顺带修掉再点一次会开第二个编码器、留下坏文件的问题\n"
            + "  - 录制中菜单显示已录时长\n"
            + "· 修复：库界面卡片不显示 / 文字互相重叠\n"
            + "  - 布局改为 XML 分层；网格改用 ScrollView + 权重行，不再依赖 GridView\n"
            + "· 修复：点\u201c关闭画面平滑\u201d后画面卡住\n"
            + "  - 菜单项执行完统一恢复模拟循环\n"
            + "· 修复：文件管理器不给 \u201c所有文件访问权限\u201d 时数据落到私有目录\n"
            + "  - 公共目录每次都先试，回退目录不再写入偏好\n"
            + "· 新增：屏幕录制，输出 MP4 / H.264 到 WaveGBA/Videos\n"
            + "  - 设备不支持时自动回退 MJPEG / AVI\n"
            + "· 新增：存档导出 / 导入（zip 打包 .sav 与 10 个槽位）\n"
            + "· 新增：按键布局编辑器——拖动按键、全局大小、透明度\n"
            + "· 新增：存档槽位缩略图——存/读档时显示每个槽位的实际画面\n"
            + "· 新增：画面缩放——适应屏幕 / 整数缩放（像素完美）/ 拉伸铺满\n"
            + "· 新增：画面边框——GBA 机身 / 渐变 / 关闭，可选\n"
            + "· 新增：屏幕录制可选是否含声音（AAC 32kHz 立体声），菜单实时标注\n"
            + "· 新增：快速存档 / 快速读档——一步存到最近使用的槽位\n"
            + "· 新增：游戏库搜索——按名称过滤，支持编号与拼音首字母（阈值 3 个）\n"
            + "· 新增：快速存档 / 读档虚拟按键（SAVE / LOAD），独立于 10 个普通槽位\n"
            + "· 优化：按键布局按拇指活动弧重排，L/R 移到易按位置\n"
            + "· 新增：菜单分类可点标题展开/收起，状态会记住\n"
            + "· 新增：选择文件夹批量扫描导入 ROM（支持 zip 内 ROM）\n"
            + "\n"
            + "v1.0.4\n"
            + "· 修复：打开游戏不自动读取存档\n"
            + "  - 每 15 秒自动写盘；onStop / 切换游戏前也会先落盘\n"
            + "  - 存档检索覆盖所有历史命名与目录，取最新的一份\n"
            + "· 新增：游戏库主界面——封面网格、上次运行时间、右下角 + 添加\n"
            + "· 新增：宏——按键录制与逐帧回放，可存文件、可循环\n"
            + "· 新增：按键显示（Input Display），屏幕底部实时显示当前按键\n"
            + "· 新增：连发键——可为 A/B/L/R 等键单独开启自动连打，速度可调\n"
            + "· 新增：游戏信息——读取卡带头显示编号、厂商、版本、地区\n"
            + "· 新增：屏幕快进键——点一下切到 4x，再点一下恢复原倍速\n"
            + "  - 长按 350ms 以上可拖动位置，位置自动记住\n"
            + "· 新增：音量调节（静音 / 25% / 50% / 75% / 100%）\n"
            + "  - 音量与静音状态跨会话保持\n"
            + "\n"
            + "v1.0.3\n"
            + "· 新增：一键截图，保存到 WaveGBA/Screenshots\n"
            + "  - 截图包含当前滤镜与亮度，与屏幕所见一致\n"
            + "· 新增：画面滤镜（关闭 / LCD 网格 / 扫描线）\n"
            + "· 新增：画面亮度调节（60%～140%）\n"
            + "\n"
            + "v1.0.2\n"
            + "· 修复：竖屏时虚拟按键互相重叠\n"
            + "  - 布局改为直接计算像素圆心，每个间距满足 >= r1+r2\n"
            + "  - 十字键臂长取 1.45r，保证斜对角不相切\n"
            + "  - 顺带修掉横屏臂长差 1.6px 的临界重叠\n"
            + "\n"
            + "v1.0.1\n"
            + "· 修复：重启后读档列表为空\n"
            + "  - 存档名改用 ROM 内部标题，不再随文件路径变化\n"
            + "  - 存档目录跨会话保持固定，并自动迁移旧目录的存档\n"
            + "· 修复：加载 ROM 时闪退（JNI 桥接未链接进 so）\n"
            + "· 新增：即时存档扩展到 10 个槽位，读档可自由选择\n"
            + "· 新增：屏幕方向切换（自动/横屏/反向横屏/竖屏/反向竖屏）\n"
            + "· 新增：存档统一放到 /sdcard/WaveGBA/Save\n"
            + "· 新增：倍速 0.5x～4x，音调不变\n"
            + "· 新增：应用图标\n"
            + "· 外观：虚拟按键改为描边式玻璃圆盘，青绿强调色\n"
            + "· 外观：菜单与对话框改为深色主题，图标重绘\n"
            + "\n"
            + "v1.0.0\n"
            + "· 首个版本，Windows / Linux / Android 三平台\n"
            + "· vba-next 核心 + 位图模式渲染优化（+13~16%）";

    private static final int ORIENT_AUTO        = 0;
    private static final int ORIENT_LANDSCAPE   = 1;
    private static final int ORIENT_REV_LAND    = 2;
    private static final int ORIENT_PORTRAIT    = 3;
    private static final int ORIENT_REV_PORT    = 4;
    private static final String[] ORIENT_LABELS = {
            "自动（跟随系统）", "横屏", "反向横屏", "竖屏", "反向竖屏"
    };

    private EmulatorView screen;
    private VirtualPad pad;
    private EmulatorThread loop;
    private AudioPlayer audio;
    private String currentRomName = "rom";
    /** What to show the user; the save name is the content hash. */
    private String romDisplayName = "rom";

    /* ------------------------------------------------------------ 功能：录屏 */
    private VideoRecorder recorder = null;   /* MJPEG/AVI fallback */
    private Mp4Recorder mp4 = null;          /* preferred: H.264/MP4 */
    private long recordStartMs = 0;
    private int recordSkip = 0;          // encode every (recordSkip+1)th frame
    private int recordTick = 0;
    private static final int RECORD_FPS = 30;


    /** Save name older releases used; kept so their saves can still be found. */
    private String legacySaveName = null;
    private int orientation = ORIENT_AUTO;
    private boolean verticalLayout = false;

    /** 即时存档槽位数。核心 emu_save_state() 接受 slot 0..9。 */
    private static final String[] FILTER_LABELS = {"关闭", "LCD 网格", "扫描线"};
    private static final float[] BRIGHTNESS = {0.6f, 0.8f, 1.0f, 1.2f, 1.4f};
    private static final String[] BRIGHTNESS_LABELS = {"60% 偏暗", "80%", "100% 标准", "120%", "140% 偏亮"};

    /** Keys that can be flagged for autofire. */
    private static final String[] KEY_NAMES = {"A", "B", "L", "R", "START", "SELECT",
                                              "上", "下", "左", "右"};

    /** Numbered slots shown in the picker: indices 0..8, i.e. 槽位 1..9.
     *
     *  It was 10, but the core rejects slot > 9 (see emu_save_state), so the
     *  quick slot -- which is index 9, written as .state9 -- had nowhere legal
     *  to live. Nine numbered slots plus one quick slot is the most the core
     *  can address. */
    private static final int SLOT_COUNT = 9;
    private File saveDir;
    private Uri pendingRom = null;
    private FastForwardButton ffButton;

    /** Battery autosave. Without this, swiping the app out of Recents can
     *  kill the process before onPause/onDestroy runs, so the .sav never
     *  reaches disk and the next launch has nothing to load. */
    private android.os.Handler saveHandler = null;
    private static final long AUTOSAVE_MS = 15000;

    /* Macro record/replay: a run-length list of (frame, mask) change points.
     * Frame-exact because EmulatorThread asks for input once per frame. */
    private final java.util.ArrayList<int[]> macro = new java.util.ArrayList<>();
    private boolean recording = false;
    private boolean replaying = false;
    private boolean macroLoop = false;
    private int macroFrameIndex = 0;
    private int macroCursor = 0;
    private String macroName = null;

    /** On-screen readout of the keys currently held. */
    private android.widget.TextView inputDisplay = null;
    private boolean inputDisplayOn = false;

    /* Turbo (autofire): holding a flagged key emits a square wave instead of
     * a constant press. */
    private int turboKeys = 0;
    private int rawMask = 0;
    private boolean turboPhase = false;
    private android.os.Handler turboHandler;
    private int turboHz = 15;
    /** First 0xC0 bytes of the ROM, used by the info dialog. */
    private byte[] romHeader = null;
    private double savedSpeed = 1.0;
    private static final String PREF_SAVE_DIR = "save_dir";

    /** ROM to open, supplied by the library screen. */
    public static final String EXTRA_ROM_URI = "rom_uri";
    private GameLibrary library;
    private String pendingUriString = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // One SharedPreferences for the whole method. onCreate was fetching it
        // ten-odd times; the framework caches the instance so this is mostly
        // about not repeating the same lookup and edit chains, but it also
        // keeps the startup path readable.
        final SharedPreferences prefs = getSharedPreferences("wavegba", MODE_PRIVATE);

        screen = (EmulatorView) findViewById(R.id.screen);
        if (screen != null) screen.applyTheme();
        loadMenuCollapsed();
        Theme.load(prefs);
        getWindow().getDecorView().setBackgroundColor(Theme.bg());
        rtcMode = prefs
                .getInt("rtc_mode", 1);
        if (screen != null) {
            // Older builds stored a boolean; -1 keeps "not set" from reading
            // as mode 0 so a fresh install still defaults to fit.
            int sm = prefs
                    .getInt("scale_mode", -1);
            if (sm < 0) {
                sm = prefs
                        .getBoolean("integer_scaling", false)
                        ? EmulatorView.SCALE_INTEGER : EmulatorView.SCALE_FIT;
            }
            screen.setScaleMode(sm);
            screen.setBezel(prefs
                    .getInt("bezel", EmulatorView.BEZEL_NONE));
            // These three were changed only in memory, so every setting a user
            // picked in 画面 was back to the default on the next launch.
            // Default true: the GBA picture is 240x160 and a phone screen is
            // several times that, so an unsmoothed upscale looks like stair
            // steps until someone deliberately turns it off.
            screen.setSmoothing(prefs.getBoolean("smoothing", true));
            screen.setFilter(prefs.getInt("filter", 0));
            screen.setBrightness(prefs.getFloat("brightness", 1.0f));
        }
        pad = (VirtualPad) findViewById(R.id.pad);
        if (pad != null) pad.applyTheme();
        pad.setListener(this);
        pad.setFunctionListener(new VirtualPad.FunctionListener() {
            public void onFunctionKey(int bit) {
                if (bit == VirtualPad.FN_QUICK_SAVE) quickSave();
                else if (bit == VirtualPad.FN_QUICK_LOAD) quickLoad();
            }
        });
        pad.setLayoutListener(json -> {
            if (json != null) savePadLayout(json);
        });
        applyPadLayout();

        ffButton = new FastForwardButton(this);
        ffButton.setListener(on -> applyFastForward(on));
        ffButton.restorePos(prefs.getFloat("ff_x", -1), prefs.getFloat("ff_y", -1));
        attachOverlay(ffButton);

        turboHandler = new android.os.Handler();
        inputDisplayOn = prefs
                .getBoolean("input_display", false);
        turboKeys = prefs.getInt("turbo_keys", 0);
        turboHz   = prefs.getInt("turbo_hz", 15);
        pad.setTurboKeys(turboKeys);


        orientation = prefs.getInt("orientation", ORIENT_AUTO);
        applyOrientation(orientation);

        // Create <external storage>/WaveGBA/Save before anything else, so it
        // exists the moment the app is first launched.
        saveDir = resolveSaveDir();
        library = new GameLibrary(saveDir);
        pendingUriString = getIntent().getStringExtra(EXTRA_ROM_URI);

        pendingRom = getIntent() != null ? getIntent().getData() : null;
        if (saveDir == null || !hasStorageAccess()) {
            // We cannot reach the public folder yet: ask, then continue.
            requestStorageAccess();
        } else {
            startFlow();
        }
    }

    /* ---------------------------------------------------------- storage --- */

    /** The folder we want: <external storage>/WaveGBA/Save. */
    private File preferredSaveDir() {
        return new File(Environment.getExternalStorageDirectory(), "WaveGBA/Save");
    }

    /** No-permission fallback: <app external files>/WaveGBA/Save. */
    private File fallbackSaveDir() {
        return new File(getExternalFilesDir(null), "WaveGBA/Save");
    }

    /** True when we can write to the public external storage root.
     *  Both helpers are reached by reflection: the android.jar on the build
     *  machine is older than API 30, but the runtime framework has them. */
    private boolean hasStorageAccess() {
        if (Build.VERSION.SDK_INT >= 30) {
            try {
                java.lang.reflect.Method m =
                        Environment.class.getMethod("isExternalStorageManager");
                return Boolean.TRUE.equals(m.invoke(null));
            } catch (Throwable t) {
                Log.w(TAG, "isExternalStorageManager 不可用", t);
                return false;
            }
        }
        if (Build.VERSION.SDK_INT >= 23) {
            try {
                java.lang.reflect.Method m = android.content.Context.class
                        .getMethod("checkSelfPermission", String.class);
                int r = (Integer) m.invoke(this,
                        android.Manifest.permission.WRITE_EXTERNAL_STORAGE);
                return r == PackageManager.PERMISSION_GRANTED;
            } catch (Throwable t) {
                Log.w(TAG, "checkSelfPermission 不可用", t);
            }
        }
        return true;   // installed permissions on older systems
    }

    /** mkdirs + a real write probe, because mkdirs() alone can lie. */
    private boolean ensureDir(File d) {
        try {
            boolean created = false;
            if (!d.exists()) {
                created = d.mkdirs();
                if (!created) return false;
            }
            if (!d.isDirectory()) return false;
            File probe = new File(d, ".wavegba_probe");
            probe.createNewFile();
            boolean ok = probe.exists();
            probe.delete();
            if (!ok && created) {
                // mkdirs() can succeed while the write probe fails (scoped
                // storage). Leaving the folder behind is actively misleading:
                // the user opens WaveGBA/ and finds it empty, when in fact
                // everything went to the private fallback.
                d.delete();
                String[] kids = d.list();
                if (kids != null && kids.length == 0) d.delete();
                Log.w(TAG, "公共目录不可写，已移除空壳 " + d);
            }
            return ok;
        } catch (Exception e) {
            Log.w(TAG, "无法写入 " + d, e);
            return false;
        }
    }

    /** True when saves live in the public folder the user can browse. */
    private boolean usingPublicDir() {
        return saveDir != null
                && saveDir.getAbsolutePath().startsWith(
                        Environment.getExternalStorageDirectory().getAbsolutePath());
    }

    /** Human readable location, so a fallback is never silent. */
    private String saveDirLabel() {
        if (saveDir == null) return "未就绪";
        return saveDir.getAbsolutePath();
    }

    /** Pick the save folder.
     *  A previously used folder wins, because the save dir changing between
     *  sessions is exactly what makes old saves "disappear": the core reads
     *  from whatever directory was passed to nativeInit(). */
    /** Pick where saves live.
     *
     *  Order matters: the public directory is tested FIRST, every time. An
     *  earlier version checked a remembered path first, and because the
     *  private fallback had been written there once, the app kept landing in
     *  Android/data/ forever even after the user granted all-files access.
     *  The fallback is also never persisted now -- it is a per-session
     *  escape hatch, not a decision to remember. */
    private File resolveSaveDir() {
        SharedPreferences sp = getSharedPreferences("wavegba", MODE_PRIVATE);

        File preferred = preferredSaveDir();
        if (ensureDir(preferred)) {
            sp.edit().putString(PREF_SAVE_DIR, preferred.getAbsolutePath()).apply();
            return preferred;
        }

        String saved = sp.getString(PREF_SAVE_DIR, null);
        if (saved != null) {
            File f = new File(saved);
            if (ensureDir(f)) return f;
        }

        File fb = fallbackSaveDir();
        ensureDir(fb);
        Log.w(TAG, "公共目录不可用，本次会话回退到 " + fb + "（不写入偏好）");
        return fb;
    }

    /** Every folder a save could plausibly live in, most likely first. */
    private File[] candidateDirs() {
        java.util.LinkedHashSet<File> set = new java.util.LinkedHashSet<>();
        if (saveDir != null) set.add(saveDir);
        set.add(preferredSaveDir());
        set.add(fallbackSaveDir());
        String saved = getSharedPreferences("wavegba", MODE_PRIVATE)
                .getString(PREF_SAVE_DIR, null);
        if (saved != null) set.add(new File(saved));
        return set.toArray(new File[0]);
    }

    /** Copy a save made in an older/different folder into the current one,
     *  because the core only ever touches the dir given to nativeInit(). */
    private boolean pullInto(File src, String name) {
        File dst = new File(saveDir, name);
        if (dst.exists() && dst.length() > 0) return true;
        try (java.io.FileInputStream in = new java.io.FileInputStream(src);
             java.io.FileOutputStream out = new java.io.FileOutputStream(dst)) {
            byte[] buf = new byte[1 << 16];
            int n;
            while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
            Log.i(TAG, "迁移存档 " + src + " -> " + dst);
            return true;
        } catch (Exception e) {
            Log.w(TAG, "迁移失败 " + src, e);
            return false;
        }
    }

    /** Every name this ROM's saves might have been written under.
     *
     *  The canonical name changed over releases (cart title -> CRC id), and
     *  the directory can differ too (public vs. app-private fallback), so a
     *  save is only findable by searching names x directories. */
    private java.util.LinkedHashSet<String> saveAliases() {
        java.util.LinkedHashSet<String> set = new java.util.LinkedHashSet<>();
        if (currentRomName != null) set.add(currentRomName);
        if (legacySaveName != null) set.add(legacySaveName);
        if (romHeader != null && romHeader.length >= 0xAC) {
            String t = new String(romHeader, 0xA0, 12,
                    java.nio.charset.StandardCharsets.US_ASCII).trim();
            if (!t.isEmpty()) {
                set.add(t.replaceAll("[^A-Za-z0-9_.-]", "_"));
                set.add(t);
            }
        }
        return set;
    }

    /** Bring .sav and all .stateN into saveDir under the canonical name.
     *
     *  When several candidates exist the newest wins: that is the one the
     *  player actually progressed on. */
    private void migrateSaves() {
        if (saveDir == null) return;
        // A migration, not a sync: once it has run there is nothing left to
        // move, so doing it again every launch only costs startup time. The
        // flag is per-install, which is right -- a fresh install has no
        // legacy files to find anyway.
        android.content.SharedPreferences msp =
                getSharedPreferences("wavegba", MODE_PRIVATE);
        if (msp.getBoolean("saves_migrated", false)) return;

        String base = currentRomName;
        java.util.Set<String> names = saveAliases();

        String[] ext = new String[SLOT_COUNT + 2];
        ext[0] = ".sav";
        for (int i = 0; i < SLOT_COUNT; i++) ext[i + 1] = ".state" + i;
        ext[SLOT_COUNT + 1] = ".state" + QUICK_SLOT;

        for (int e = 0; e < ext.length; e++) {
            // Fast path first. Scanning four directories under three possible
            // names for every one of eleven extensions is over a hundred stat
            // calls, and on the common launch the file is already sitting in
            // saveDir. Checking the destination before scanning turns the
            // usual case into one cheap test.
            File dst0 = new File(saveDir, base + ext[e]);
            if (dst0.exists() && dst0.length() > 0) continue;

            File best = null;
            long bestTime = -1;
            for (File d : candidateDirs()) {
                for (String n : names) {
                    File f = new File(d, n + ext[e]);
                    if (!f.exists() || f.length() <= 0) continue;
                    long t = f.lastModified();
                    if (t > bestTime) { bestTime = t; best = f; }
                }
            }
            if (best == null) continue;
            File dst = new File(saveDir, base + ext[e]);
            if (best.getAbsolutePath().equals(dst.getAbsolutePath())) continue;
            // Only overwrite when the candidate is genuinely newer.
            if (dst.exists() && dst.length() > 0 && dst.lastModified() >= bestTime) continue;
            pullInto(best, base + ext[e]);
        }
        msp.edit().putBoolean("saves_migrated", true).apply();
    }

    /** Standard GBA battery-save sizes. A .sav must be exactly one of these
     *  for other emulators (mGBA, MyBoy, ...) to recognise it. */
    private static final long[] SAVE_SIZES = {512L, 8192L, 32768L, 65536L, 131072L};
    private static final long SAVE_MAX = 131072L;

    /** Write the battery save, then trim it to a standard size.
     *
     *  Why trimming is needed: the core reports its SRAM size from
     *  adjust_save_ram(), but that runs once inside retro_init() right after
     *  the buffer is memset to 0xFF -- so it never sees any save data and
     *  never detects a type. The size therefore stays at the whole buffer,
     *  0x20000 + 0x2000 = 139264 bytes = 136 KiB, and every .sav is written
     *  at that non-standard size.
     *
     *  The proper fix belongs in C (run the detection after the battery is
     *  loaded), which needs the NDK; this build has none. Trimming here gets
     *  the same result on disk: the trailing 8 KiB is untouched 0xFF padding,
     *  so nothing is lost. */
    private void flushBattery() {
        try { NativeBridge.nativeSaveBattery(); } catch (Throwable ignored) { }
        normalizeBatterySave();
    }

    /** Shrink a .sav to the smallest standard size that still holds every
     *  non-0xFF byte. 0xFF is the erased state, so trailing 0xFF is padding. */
    private void normalizeBatterySave() {
        File f = savFile();
        if (f == null || !f.exists()) return;
        long len = f.length();
        if (len <= SAVE_MAX) return;          // already standard

        byte[] b = new byte[(int) len];
        try (java.io.FileInputStream in = new java.io.FileInputStream(f)) {
            int off = 0, n;
            while (off < b.length && (n = in.read(b, off, b.length - off)) > 0) off += n;
        } catch (Throwable t) {
            return;
        }

        int last = -1;
        for (int i = b.length - 1; i >= 0; i--) {
            if ((b[i] & 0xFF) != 0xFF) { last = i; break; }
        }
        long needed = last + 1L;
        // Real data reached past 128 KiB: trimming would lose it, so leave it.
        if (needed > SAVE_MAX) return;

        long target = SAVE_MAX;
        for (long sz : SAVE_SIZES) {
            if (sz >= needed) { target = sz; break; }
        }
        if (target >= len) return;

        try (java.io.FileOutputStream out = new java.io.FileOutputStream(f)) {
            out.write(b, 0, (int) target);
            out.getFD().sync();
        } catch (Throwable t) {
            Log.w(TAG, "存档裁剪失败", t);
            return;
        }
        Log.i(TAG, "电池存档裁剪 " + len + " -> " + target + " 字节");
    }

    /* ------------------------------------------------ 功能：槽位缩略图 ---- */

    /** Slot thumbnails live beside Save/, not inside it.
     *
     *  saveDir can move between the public and private location, and the
     *  state files get migrated when it does. Keeping thumbs in their own
     *  directory means they never have to be migrated -- they are addressed
     *  by ROM id either way. */
    private File slotsThumbDir() {
        File d = (saveDir != null)
                ? new File(saveDir.getParentFile(), "Slots")
                : new File(android.os.Environment.getExternalStorageDirectory(),
                           "WaveGBA/Slots");
        ensureDir(d);
        return d;
    }

    private File slotThumbFile(int slot) {
        return new File(slotsThumbDir(), currentRomName + ".state" + slot + ".png");
    }

    /** Snapshot the picture into the slot's thumbnail.
     *
     *  Done after the state write succeeds, so a slot never advertises a
     *  picture it does not actually hold. A failure here is not worth
     *  failing the save over, hence the silent catch. */
    private void saveSlotThumb(int slot) {
        if (screen == null || currentRomName == null) return;
        Bitmap bmp = null;
        try {
            bmp = screen.captureGameOnly();
            if (bmp == null) return;
            File out = slotThumbFile(slot);
            java.io.FileOutputStream fos = new java.io.FileOutputStream(out);
            boolean ok = bmp.compress(Bitmap.CompressFormat.PNG, 100, fos);
            fos.close();
            if (!ok) out.delete();
        } catch (Throwable t) {
            Log.w(TAG, "槽位缩略图保存失败", t);
        } finally {
            if (bmp != null) bmp.recycle();
        }
    }

    /** Where the battery save lives, and whether it is actually there. */
    private File savFile() {
        if (saveDir == null || currentRomName == null) return null;
        return new File(saveDir, currentRomName + ".sav");
    }

    private String savStatus() {
        File f = savFile();
        if (f == null) return "存档：目录未就绪";
        if (!f.exists()) return "存档：尚不存在（先在游戏内保存一次）";
        String when = new java.text.SimpleDateFormat("MM-dd HH:mm", java.util.Locale.US)
                .format(new java.util.Date(f.lastModified()));
        return "存档：" + f.getName() + "  " + (f.length() / 1024) + "KB  " + when;
    }

    /* -------------------------------------------------------- 自动保存 --- */

    private final Runnable autosave = new Runnable() {
        public void run() {
            try { flushBattery(); }
            catch (Throwable t) { Log.w(TAG, "自动保存失败", t); }
            if (saveHandler != null) saveHandler.postDelayed(this, AUTOSAVE_MS);
        }
    };

    private void startAutosave() {
        if (saveHandler == null) saveHandler = new android.os.Handler();
        saveHandler.removeCallbacks(autosave);
        saveHandler.postDelayed(autosave, AUTOSAVE_MS);
    }

    private void stopAutosave() {
        if (saveHandler != null) { saveHandler.removeCallbacks(autosave); }
    }

    private void requestStorageAccess() {
        try {
            if (Build.VERSION.SDK_INT >= 30) {
                Intent i = new Intent(
                        "android.settings.MANAGE_APP_ALL_FILES_ACCESS_PERMISSION",
                        Uri.parse("package:" + getPackageName()));
                startActivityForResult(i, REQ_STORAGE);
            } else {
                java.lang.reflect.Method m = android.app.Activity.class
                        .getMethod("requestPermissions", String[].class, int.class);
                m.invoke(this,
                        new String[]{android.Manifest.permission.WRITE_EXTERNAL_STORAGE},
                        REQ_STORAGE);
            }
        } catch (Exception e) {
            Log.w(TAG, "无法请求存储权限", e);
            startFlow();
        }
    }

    /** Continue after (maybe) getting storage permission. */
    private void startFlow() {
        saveDir = resolveSaveDir();
        if (library == null) library = new GameLibrary(saveDir);

        if (pendingRom != null) { loadRom(pendingRom); return; }
        if (pendingUriString != null) {
            try {
                android.net.Uri u = android.net.Uri.parse(pendingUriString);
                persistUri(this, u);          // refresh the grant if it lapsed
                loadRom(u);
                return;
            } catch (Throwable t) { Log.w(TAG, "URI 无效", t); }
        }
        pickRom();
    }

    /** singleTask means tapping another game reuses this activity, so the
     *  new intent arrives here instead of onCreate. Swap it in and (re)load. */
    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        try { setIntent(intent); } catch (Throwable t) { Log.w(TAG, "setIntent 失败", t); }

        pendingRom = (intent != null) ? intent.getData() : null;
        pendingUriString = (intent != null) ? intent.getStringExtra(EXTRA_ROM_URI) : null;

        if (pendingRom != null || pendingUriString != null) {
            // Flush first: switching ROMs re-inits the core, and anything
            // only sitting in SRAM would be lost.
            try { flushBattery(); } catch (Throwable ignored) { }
            stopAutosave();
            if (loop != null) loop.stopLoop();
            if (audio != null) audio.stop();
            startFlow();
        }
    }

    /* Not annotated @Override: the old android.jar lacks this callback. */
    public void onRequestPermissionsResult(int req, String[] perms, int[] grants) {
        if (req == REQ_STORAGE) startFlow();
    }

    /** 屏幕方向是否让画面竖着显示（决定用叠加布局还是上下分栏布局） */
    private boolean isVertical(int mode) {
        if (mode == ORIENT_PORTRAIT || mode == ORIENT_REV_PORT) return true;
        if (mode == ORIENT_AUTO) {
            Configuration c = getResources().getConfiguration();
            return c.orientation == Configuration.ORIENTATION_PORTRAIT;
        }
        return false;
    }

    /** 切换 Activity 方向 + 重建屏幕/按键的排布 */
    private void applyOrientation(int mode) {
        orientation = mode;
        try {
            switch (mode) {
                case ORIENT_LANDSCAPE:
                    setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE);
                    break;
                case ORIENT_REV_LAND:
                    setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_REVERSE_LANDSCAPE);
                    break;
                case ORIENT_PORTRAIT:
                    setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_SENSOR_PORTRAIT);
                    break;
                case ORIENT_REV_PORT:
                    setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_REVERSE_PORTRAIT);
                    break;
                default:
                    setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED);
                    break;
            }
        } catch (Throwable t) {
            Log.w(TAG, "设置方向失败", t);
        }
        rebuildLayout(isVertical(mode));
    }

    /** 横屏：按键半透明叠在画面上；竖屏：画面在上、按键在下。 */
    private void rebuildLayout(boolean vertical) {
        verticalLayout = vertical;
        ViewGroup root = (ViewGroup) findViewById(R.id.root);
        ViewGroup old = (ViewGroup) screen.getParent();
        if (old != null) old.removeAllViews();
        if (old != null) root.removeView(old);

        ViewGroup next;
        if (vertical) {
            LinearLayout ll = new LinearLayout(this);
            ll.setOrientation(LinearLayout.VERTICAL);
            ll.setLayoutParams(new FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.MATCH_PARENT));
            screen.setLayoutParams(new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, 0, 1.0f));
            pad.setLayoutParams(new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, 0, 1.0f));
            ll.addView(screen);
            ll.addView(pad);
            next = ll;
        } else {
            FrameLayout fl = new FrameLayout(this);
            fl.setLayoutParams(new FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.MATCH_PARENT));
            fl.addView(screen, new FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.MATCH_PARENT));
            fl.addView(pad, new FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.MATCH_PARENT));
            next = fl;
        }
        root.addView(next, 0);
        pad.setPortrait(vertical);
        applyPadLayout();
    }

    @Override
    public void onConfigurationChanged(Configuration nc) {
        super.onConfigurationChanged(nc);
        // 自动模式下跟着系统转，布局要跟着换
        if (orientation == ORIENT_AUTO) rebuildLayout(isVertical(ORIENT_AUTO));
    }

    /* ------------------------------------------------------- 即时存档槽位 */

    /** slot 的存档文件。命名必须与核心 state_path() 一致：
     *  "<save_dir>/<rom_name>.state<slot>" */
    private File slotFile(int slot) {
        String name = currentRomName + ".state" + slot;
        for (File d : candidateDirs()) {
            File f = new File(d, name);
            if (f.exists() && f.length() > 0) return f;
        }
        return new File(saveDir != null ? saveDir : preferredSaveDir(), name);
    }

    /** 槽位显示文本，例如 "槽位 3  ·  10-05 14:32" 或 "槽位 3  ·  空" */
    /** 当前已存的槽位数，用于标题提示 */
    private int usedSlots() {
        int n = 0;
        for (int i = 0; i < SLOT_COUNT; i++)
            if (slotFile(i).exists() && slotFile(i).length() > 0) n++;
        return n;
    }

    private void showSaveSlotMenu() { showSlotPicker(true); }

    private void showLoadSlotMenu() { showSlotPicker(false); }

    /** Slot picker with a live thumbnail per slot.
     *
     *  A plain AlertDialog.setItems() can only show text, and "槽位 3 · 10-06
     *  21:40 · 437 KB" tells you nothing about where in the game that save
     *  actually is. Showing the frame makes the choice obvious.
     *
     *  Rows are LinearLayouts with layout_weight=1 rather than a GridView:
     *  an AdapterView measures its children against a column width derived
     *  from its own measured size, which came out as nothing usable inside a
     *  dialog -- the same failure that emptied the game library grid. */
    private void showSlotPicker(final boolean saving) {
        if (loop != null) loop.setPaused(true);

        android.app.Dialog dlg = new android.app.Dialog(this, R.style.DialogTheme);
        dlg.setTitle((saving ? "存档到槽位" : "读取槽位")
                + "（已用 " + usedSlots() + "/" + SLOT_COUNT + "）");

        android.util.DisplayMetrics m = getResources().getDisplayMetrics();
        int pad = (int) (20 * m.density);
        int gap = (int) (12 * m.density);
        int minCol = (int) (104 * m.density);
        int usable = m.widthPixels - 2 * pad + gap;
        int cols = usable / (minCol + gap);
        if (cols < 2) cols = 2;
        if (cols > 4) cols = 4;
        int colW = usable / cols - gap;
        int thumbH = Math.round(colW * 2f / 3f);

        android.widget.ScrollView sv = new android.widget.ScrollView(this);
        android.widget.LinearLayout host = new android.widget.LinearLayout(this);
        host.setOrientation(android.widget.LinearLayout.VERTICAL);
        host.setPadding(pad, (int) (12 * m.density), pad, (int) (12 * m.density));
        sv.addView(host, new android.widget.LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT));

        for (int i = 0; i < SLOT_COUNT; i += cols) {
            android.widget.LinearLayout row = new android.widget.LinearLayout(this);
            row.setOrientation(android.widget.LinearLayout.HORIZONTAL);
            android.widget.LinearLayout.LayoutParams rp =
                    new android.widget.LinearLayout.LayoutParams(
                            ViewGroup.LayoutParams.MATCH_PARENT,
                            ViewGroup.LayoutParams.WRAP_CONTENT);
            if (i + cols < SLOT_COUNT) rp.bottomMargin = gap;
            host.addView(row, rp);

            for (int j = 0; j < cols; j++) {
                final int slot = i + j;
                android.widget.LinearLayout.LayoutParams cp =
                        new android.widget.LinearLayout.LayoutParams(
                                0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
                if (j > 0) cp.leftMargin = gap;
                if (slot >= SLOT_COUNT) {
                    View sp = new View(this);
                    row.addView(sp, cp);
                    continue;
                }
                row.addView(slotCard(slot, thumbH, saving, dlg), cp);
            }
        }

        android.widget.LinearLayout root = new android.widget.LinearLayout(this);
        root.setOrientation(android.widget.LinearLayout.VERTICAL);
        root.setBackgroundColor(0xFF17171C);
        root.addView(sv, new android.widget.LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                0, 1f));

        android.widget.Button cancel = new android.widget.Button(this);
        cancel.setText("取消");
        cancel.setBackgroundColor(0x00000000);
        cancel.setTextColor(0xFF9CA3AF);
        cancel.setOnClickListener(v -> dlg.dismiss());
        android.widget.LinearLayout.LayoutParams bp =
                new android.widget.LinearLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT,
                        ViewGroup.LayoutParams.WRAP_CONTENT);
        bp.topMargin = (int) (6 * m.density);
        root.addView(cancel, bp);

        dlg.setContentView(root);
        dlg.setOnDismissListener(dd -> { if (loop != null) loop.setPaused(false); });
        dlg.show();
    }

    /** One slot: thumbnail, label, and tap action. */
    private View slotCard(final int slot, int thumbH, final boolean saving,
                          final android.app.Dialog dlg) {
        android.widget.LinearLayout card = new android.widget.LinearLayout(this);
        card.setOrientation(android.widget.LinearLayout.VERTICAL);
        card.setBackgroundColor(slotFile(slot).exists() ? 0xFF1F1F26 : 0xFF17171C);
        int p = (int) (7 * getResources().getDisplayMetrics().density);
        card.setPadding(p, p, p, p);

        android.widget.ImageView iv = new android.widget.ImageView(this);
        android.widget.LinearLayout.LayoutParams ip =
                new android.widget.LinearLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT, thumbH);
        iv.setLayoutParams(ip);
        iv.setScaleType(android.widget.ImageView.ScaleType.CENTER_CROP);
        iv.setBackgroundColor(0xFF000000);

        Bitmap thumb = loadSlotThumb(slot);
        if (thumb != null) {
            iv.setImageBitmap(thumb);
        } else {
            // Empty slot: a dim placeholder so the grid keeps its shape and
            // the empty ones read as empty rather than as missing.
            iv.setImageDrawable(emptySlotDrawable());
        }
        card.addView(iv);

        TextView name = new TextView(this);
        name.setText("槽位 " + (slot + 1));
        name.setTextColor(0xFFF2F4F7);
        name.setTextSize(13);
        name.setPadding(0, p, 0, 0);
        card.addView(name);

        TextView meta = new TextView(this);
        File f = slotFile(slot);
        if (f.exists() && f.length() > 0) {
            meta.setText(new java.text.SimpleDateFormat("MM-dd HH:mm",
                    java.util.Locale.getDefault()).format(new java.util.Date(f.lastModified()))
                    + " · " + (f.length() / 1024) + "KB");
            meta.setTextColor(0xFF22D3EE);
        } else {
            meta.setText("空");
            meta.setTextColor(0xFF6B7280);
        }
        meta.setTextSize(11);
        card.addView(meta);

        card.setOnClickListener(v -> {
            dlg.dismiss();
            if (saving) doSaveSlot(slot); else doLoadSlot(slot);
        });
        return card;
    }

    /* ------------------------------------------------ 快速存 / 读档 ----- */

    /** The quick slot: index 9, i.e. .state9, one past the nine the picker
     *  shows, and the highest index the core accepts.
     *
     *  It first reused whichever slot was touched last, which meant a quick
     *  save silently overwrote a numbered save -- the one carefully kept at
     *  the boss, gone because quick save was hit in a panic. Then it was index
     *  10, which the core refuses outright, so every quick save failed with
     *  "存档失败". Nine plus one is the arrangement that actually works. */
    private static final int QUICK_SLOT = SLOT_COUNT;   // 9, i.e. .state9

    private int quickSlot() { return QUICK_SLOT; }

    private void doSaveSlot(int slot) {
        int rc;
        try { rc = NativeBridge.nativeSaveState(slot); }
        catch (Throwable t) { Log.e(TAG, "存档失败", t); rc = -1; }
        if (rc == 0) {
            saveSlotThumb(slot);
            // Battery save too: a state alone does not update the .sav the
            // game itself reads, so a reset would still lose the progress.
            flushBattery();
        }
        toast(rc == 0 ? (slot == QUICK_SLOT
                ? "已快速存档" : "已存到槽位 " + (slot + 1)) : "存档失败");
    }

    private void doLoadSlot(int slot) {
        File sf = slotFile(slot);
        if (!sf.exists() || sf.length() == 0) {
            toast("槽位 " + (slot + 1) + " 是空的");
            return;
        }
        if (!sf.getParentFile().equals(saveDir)) pullInto(sf, sf.getName());
        int rc;
        try { rc = NativeBridge.nativeLoadState(slot); }
        catch (Throwable t) { Log.e(TAG, "读档失败", t); rc = -1; }
        toast(rc == 0 ? (slot == QUICK_SLOT
                ? "已读取快速存档" : "已读取槽位 " + (slot + 1)) : "读档失败");
    }

    /** Move whatever sits in the quick slot into a free numbered slot.
     *
     *  The previous build had ten numbered slots, so anyone who used 槽位 10
     *  has a save in .state9 -- which is now the quick slot and would be
     *  overwritten by the first quick save. Runs once per install. */
    private void migrateQuickSlotAway() {
        if (saveDir == null || currentRomName == null) return;
        android.content.SharedPreferences sp =
                getSharedPreferences("wavegba", MODE_PRIVATE);
        if (sp.getBoolean("quick_migrated", false)) return;

        File quick = new File(saveDir, currentRomName + ".state" + QUICK_SLOT);
        if (!quick.exists() || quick.length() == 0) {
            sp.edit().putBoolean("quick_migrated", true).apply();
            return;
        }
        for (int i = 0; i < QUICK_SLOT; i++) {
            File dst = new File(saveDir, currentRomName + ".state" + i);
            if (dst.exists() && dst.length() > 0) continue;
            if (quick.renameTo(dst)) {
                File thumb = slotThumbFile(QUICK_SLOT);
                if (thumb != null && thumb.exists()) {
                    File t2 = slotThumbFile(i);
                    if (t2 != null) thumb.renameTo(t2);
                }
                toast("旧的槽位 10 已移到槽位 " + (i + 1));
                break;
            }
        }
        // Whether or not a free slot was found, only try once -- otherwise
        // every launch would attempt the same move.
        sp.edit().putBoolean("quick_migrated", true).apply();
    }

    private boolean quickSlotUsed() {
        File f = slotFile(QUICK_SLOT);
        return f.exists() && f.length() > 0;
    }

    /** Save to the quick slot in one action.
     *
     *  The normal route is menu -> 存档到槽位 -> pick a slot, three steps and
     *  a dialog. That is fine when you are choosing between saves and useless
     *  when something is about to kill you, so this exists as the one-step
     *  version. */
    private void quickSave() {
        doSaveSlot(quickSlot());
    }

    /** Load the quick slot. Asks first: this throws away whatever happened
     *  since the last save, and a mis-tap here is unrecoverable. */
    private void quickLoad() {
        int slot = quickSlot();
        File sf = slotFile(slot);
        if (!sf.exists() || sf.length() == 0) {
            toast("还没有快速存档");
            return;
        }
        if (loop != null) loop.setPaused(true);
        new android.app.AlertDialog.Builder(this, R.style.DialogTheme)
                .setTitle("读取快速存档？")
                .setMessage("将回到上一次快速存档的位置，"
                        + "那之后的进度会丢失。")
                .setPositiveButton("读取", (d, w) -> {
                    d.dismiss();
                    doLoadSlot(slot);
                    if (loop != null) loop.setPaused(false);
                })
                .setNegativeButton("取消", null)
                .setOnCancelListener(d -> { if (loop != null) loop.setPaused(false); })
                .show();
    }

    /** Decode a slot thumbnail, or null if there isn't one. */
    private Bitmap loadSlotThumb(int slot) {
        if (currentRomName == null) return null;
        File f = slotThumbFile(slot);
        if (!f.exists() || f.length() == 0) return null;
        try {
            return android.graphics.BitmapFactory.decodeFile(f.getAbsolutePath());
        } catch (Throwable t) {
            return null;
        }
    }

    private android.graphics.drawable.Drawable emptySlotDrawable() {
        return new android.graphics.drawable.ColorDrawable(0xFF0D0D0F);
    }

    private void showOrientationMenu() {
        if (loop != null) loop.setPaused(true);
        new android.app.AlertDialog.Builder(this, R.style.DialogTheme)
                .setTitle("屏幕方向")
                .setSingleChoiceItems(ORIENT_LABELS, orientation, (d, which) -> {
                    applyOrientation(which);
                    getSharedPreferences("wavegba", MODE_PRIVATE)
                            .edit().putInt("orientation", which).apply();
                    d.dismiss();
                    toast("屏幕方向：" + ORIENT_LABELS[which]);
                    if (loop != null) loop.setPaused(false);
                })
                .setOnCancelListener(d -> { if (loop != null) loop.setPaused(false); })
                .show();
    }

    /** Attach an overlay view to the root frame.
     *  Detaching first matters: adding a view that already has a parent
     *  throws IllegalStateException and takes the whole activity down. */
    private void attachOverlay(android.view.View v) {
        ViewGroup root = (ViewGroup) findViewById(R.id.root);
        if (v.getParent() != null) ((ViewGroup) v.getParent()).removeView(v);
        root.addView(v, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT));
    }


    /* ------------------------------------------------------- URI 权限 --- */

    /** Keep access to a content:// URI across restarts.
     *
     *  A URI granted by the document picker only stays readable until this
     *  activity dies, so re-opening a game from the library -- possibly days
     *  later, in a fresh process -- would fail and fall back to the picker.
     *  takePersistableUriPermission() is what makes the grant permanent.
     *  Called by name: the build android.jar predates it. */
    public static void persistUri(android.content.Context ctx, android.net.Uri uri) {
        if (uri == null || !"content".equals(uri.getScheme())) return;
        int flags = 0x00000001;   // Intent.FLAG_GRANT_READ_URI_PERMISSION
        try {
            java.lang.reflect.Method m = ctx.getClass()
                    .getMethod("takePersistableUriPermission",
                               android.net.Uri.class, int.class);
            m.invoke(ctx, uri, flags);
        } catch (Throwable t) {
            // Second form: some builds expose it on ContextCompat instead.
            try {
                java.lang.reflect.Method m = android.content.Context.class
                        .getMethod("takePersistableUriPermission",
                                   android.net.Uri.class, int.class);
                m.invoke(ctx, uri, flags);
            } catch (Throwable ignored) {
                android.util.Log.w("WaveGBA", "无法持久化 URI 权限", t);
            }
        }
    }

    /** Ask the picker for a grant we are allowed to persist.
     *  Literal values, not reflection: these have been fixed since API 19 and
     *  a failed field lookup would silently leave the grant non-persistent. */
    public static void addPersistableFlags(Intent i) {
        i.addFlags(0x00000001);   // FLAG_GRANT_READ_URI_PERMISSION
        i.addFlags(0x00000002);   // FLAG_GRANT_WRITE_URI_PERMISSION
        i.addFlags(0x00000040);   // FLAG_GRANT_PERSISTABLE_URI_PERMISSION
    }

    private void pickRom() {
        Intent i = new Intent("android.intent.action.OPEN_DOCUMENT");
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("*/*");
        addPersistableFlags(i);
        try { startActivityForResult(i, REQ_ROM); }
        catch (Exception e) { toast("没有可用的文件选择器"); }
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (req == REQ_STORAGE) { startFlow(); return; }
        if (req == REQ_IMPORT_SAVE && res == RESULT_OK && data != null
                && data.getData() != null) {
            applyImportedSave(data.getData());
            return;
        }
        if (req == REQ_ROM && res == RESULT_OK && data != null && data.getData() != null) {
            persistUri(this, data.getData());
            loadRom(data.getData());
        } else if (req == REQ_ROM && res != RESULT_OK) {
            finish();
        }
    }

    private void loadRom(Uri uri) {
        byte[] rom;
        try {
            InputStream in = getContentResolver().openInputStream(uri);
            if (in == null) throw new java.io.IOException("null stream");
            ByteArrayOutputStream bos = new ByteArrayOutputStream();
            byte[] chunk = new byte[1 << 16];
            int n;
            while ((n = in.read(chunk)) > 0) bos.write(chunk, 0, n);
            in.close();
            rom = bos.toByteArray();
        } catch (Exception e) {
            Log.e(TAG, "读取失败", e);
            toast("无法读取该文件，请重新选择一次");
            pickRom();
            return;
        }
        if (rom.length < 0x200) {
            toast("这不像是 GBA 游戏文件");
            pickRom();
            return;
        }

        // Identity comes from the ROM bytes, never from a name: two Chinese
        // titled carts used to collapse to the same id (titles were scrubbed
        // to underscores) and overwrote each other in the library.
        String id = romIdentity(rom);
        String legacy = romTitle(rom, uri);        // what older builds used
        legacySaveName = legacy;
        if (library != null) {
            String code = (rom.length >= 0xB0)
                    ? new String(rom, 0xAC, 4, java.nio.charset.StandardCharsets.US_ASCII)
                            .replaceAll("[^A-Za-z0-9]", "?") : "????";

            GameLibrary.Entry known = library.find(id);
            if (known != null) {
                // Already in the library: refresh only the location, never the
                // name. Deriving a title here would silently revert whatever
                // the player typed at import -- the uri is our own copy
                // (gaXXXXXXXX.gba), so any name we could guess is worse than
                // the one already stored.
                known.uri = uri.toString();
                known.code = code;
                library.save();
            } else {
                // First sighting: guess a name, but only ever from the real
                // file name -- never from the cart title, which is what made
                // entries read "POKEMON EMER" instead of the player's name.
                String display = GameLibrary.fileNameOf(this, uri);
                if (display == null || display.trim().isEmpty())
                    display = GameLibrary.cartTitle(rom);
                library.put(id, display, uri.toString(), code);
                library.save();
            }
        }
        currentRomName = id;
        if (library != null) {
            GameLibrary.Entry ent = library.find(id);
            if (ent != null) romDisplayName = GameLibrary.label(ent);
        }
        romHeader = (rom.length >= 0xC0) ? java.util.Arrays.copyOf(rom, 0xC0) : rom.clone();
        if (saveDir == null) saveDir = resolveSaveDir();
        ensureDir(saveDir);

        // Must precede nativeInit(): the core reads its options once during
        // load, so setting the mode afterwards would have no effect until the
        // next time a game is started.
        try { NativeBridge.nativeSetRtcMode(rtcMode); }
        catch (Throwable t) { Log.w(TAG, "设置 RTC 失败", t); }

        boolean ok;
        try {
            ok = NativeBridge.nativeInit(rom, saveDir.getAbsolutePath(), currentRomName, 0);
            if (ok) {
                migrateSaves();
                migrateQuickSlotAway();
                migrateLegacySave(currentRomName, legacy);
                NativeBridge.nativeLoadBattery();
            }
        } catch (Throwable t) {
            Log.e(TAG, "nativeInit 崩溃", t);
            ok = false;
            toast("核心加载失败：" + describe(t));
        }
        if (!ok) {
            toast("模拟器核心加载该游戏失败");
            return;
        }

        toast("已载入：" + currentRomName);
        // Start the fade before the loop pulls its first frame: the picture
        // would otherwise appear at full brightness and then dim, which is
        // worse than no transition at all.
        if (screen != null) screen.beginFadeIn();
        try {
            startEmulation();
        } catch (Throwable t) {
            Log.e(TAG, "启动模拟失败", t);
            toast("启动失败：" + describe(t));
        }
    }

    /** Human readable one-liner for a crash, safe to show in a toast. */
    private static String describe(Throwable t) {
        String m = t.getMessage();
        if (m == null || m.isEmpty()) m = t.getClass().getSimpleName();
        return m.length() > 120 ? m.substring(0, 120) + "..." : m;
    }

    /** The GBA header keeps the game title at 0xA0..0xAB (12 bytes).
     *  Using it as the save-file base means the same cart always maps to the
     *  same save, no matter which folder or app the ROM was opened from --
     *  a name derived from the URI changes with the path and silently
     *  "loses" every save. */
    private String romTitle(byte[] rom, Uri uri) {
        if (rom.length >= 0xAC) {
            StringBuilder sb = new StringBuilder();
            for (int i = 0xA0; i < 0xAC; i++) {
                int c = rom[i] & 0xFF;
                if (c >= 0x20 && c < 0x7F) sb.append((char) c);
            }
            String t = sb.toString().trim();
            if (!t.isEmpty()) return t.replaceAll("[^A-Za-z0-9_.-]", "_");
        }
        return nameOf(uri);
    }

    /** Stable identity for saves and library entries.
     *
     *  A CRC of the ROM bytes is the only thing that is both unique per game
     *  and stable across renames, moves and different file managers. Names
     *  fail on both counts: two carts can share a title, and the same cart
     *  opened from Download vs. a file manager yields different paths. */
    private static String romIdentity(byte[] rom) {
        java.util.zip.CRC32 crc = new java.util.zip.CRC32();
        crc.update(rom, 0, rom.length);
        return String.format(java.util.Locale.US, "g%08x", crc.getValue());
    }

    /** Carry saves over from the old title-based naming, so a ROM that used
     *  to save as "口袋妖怪" keeps its progress after this change. */
    private void migrateLegacySave(String id, String legacyName) {
        if (saveDir == null || legacyName == null) return;
        if (legacyName.equals(id)) return;
        String[] ext = {".sav", ".state0", ".state1", ".state2", ".state3", ".state4",
                        ".state5", ".state6", ".state7", ".state8", ".state9"};
        for (String e : ext) {
            File old = new File(saveDir, legacyName + e);
            File neu = new File(saveDir, id + e);
            if (!old.exists() || neu.exists()) continue;
            try {
                java.io.FileInputStream in = new java.io.FileInputStream(old);
                java.io.FileOutputStream out = new java.io.FileOutputStream(neu);
                byte[] buf = new byte[1 << 16];
                int n;
                while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
                in.close();
                out.close();
                Log.i(TAG, "存档改名迁移 " + old.getName() + " -> " + neu.getName());
            } catch (Throwable t) {
                Log.w(TAG, "存档迁移失败 " + old, t);
            }
        }
    }

    /** Display name taken from the ROM's file name, e.g.
     *  "1234 - Pokemon Emerald.gba" -> "1234 - Pokemon Emerald".
     *
     *  Falls back through the path segment because content:// URIs from some
     *  file managers hand back a numeric id as the last segment, which would
     *  make every game show up as "1234". */
    private String fileNameOf(Uri uri) {
        String name = null;
        try {
            if ("file".equals(uri.getScheme()) && uri.getPath() != null) {
                name = new File(uri.getPath()).getName();
            } else {
                // OpenableColumns.DISPLAY_NAME
                android.database.Cursor c =
                        getContentResolver().query(uri, null, null, null, null);
                if (c != null) {
                    int i = c.getColumnIndex("_display_name");
                    if (i >= 0 && c.moveToFirst()) name = c.getString(i);
                    c.close();
                }
            }
        } catch (Throwable t) {
            Log.w(TAG, "读取文件名失败", t);
        }
        if (name == null || name.trim().isEmpty()) name = nameOf(uri);

        int dot = name.lastIndexOf('.');
        if (dot > 0) name = name.substring(0, dot);
        name = name.trim();
        return name.isEmpty() ? "rom" : name;
    }

    private String nameOf(Uri uri) {
        String s = uri.getLastPathSegment();
        if (s == null) s = "rom";
        int dot = s.lastIndexOf('.');
        int slash = s.lastIndexOf('/');
        String base = slash >= 0 ? s.substring(slash + 1) : s;
        if (dot > 0 && dot > slash) base = base.substring(0, base.lastIndexOf('.'));
        return base.replaceAll("[^A-Za-z0-9_.-]", "_");
    }

    private void startEmulation() {
        if (loop != null) { loop.stopLoop(); stopAutosave(); }
        if (audio != null) audio.stop();

        audio = new AudioPlayer();
        SharedPreferences asp = getSharedPreferences("wavegba", MODE_PRIVATE);
        audio.setVolume(asp.getFloat("volume", 1.0f));
        audio.setMuted(asp.getBoolean("muted", false));
        audio.start();

        loop = new EmulatorThread(screen);
        loop.setInputSource(new EmulatorThread.InputSource() {
            public int onFrame() { return inputForFrame(); }
        });
        loop.start();
        restartTurbo();
        startAutosave();
        if (inputDisplayOn) showInputDisplay(true);
        Log.i(TAG, "已启动: " + NativeBridge.nativeVersion());
    }

    @Override
    /** Raw pad state arrives here; turbo keys are pulsed before the core
     *  ever sees them, so the emulation itself stays untouched. */
    public void onButtons(int mask) {
        rawMask = mask;
        updateInputDisplay(mask);
    }

    /** Called once per simulated frame. This is the single place that decides
     *  what the core sees: live input, a replayed macro, or a recording. */
    private int inputForFrame() {
        int raw;

        if (replaying && !macro.isEmpty()) {
            raw = maskAt(macroFrameIndex);
            macroFrameIndex++;
            if (macroFrameIndex >= macroTotalFrames()) {
                if (macroLoop) {
                    macroFrameIndex = 0;
                    macroCursor = 0;
                } else {
                    stopReplay();
                }
            }
            rawMask = raw;
            updateInputDisplay(raw);
        } else {
            raw = rawMask;
        }

        if (recording) {
            // Run-length: only store actual changes, not every frame.
            if (macro.isEmpty()) macro.add(new int[]{macroFrameIndex, raw});
            else {
                int[] last = macro.get(macro.size() - 1);
                if (last[1] != raw) macro.add(new int[]{macroFrameIndex, raw});
            }
            macroFrameIndex++;
        }

        return turboKeys == 0 ? raw : (raw & ~turboKeys) | (turboPhase ? (raw & turboKeys) : 0);
    }

    private int maskAt(int frame) {
        while (macroCursor + 1 < macro.size() && macro.get(macroCursor + 1)[0] <= frame)
            macroCursor++;
        return macro.get(macroCursor)[1];
    }

    private int macroTotalFrames() {
        if (macro.isEmpty()) return 0;
        return macro.get(macro.size() - 1)[0] + 1;
    }

    /* ---------------------------------------------------------------- 宏 */

    private File macrosDir() {
        File d = (saveDir != null)
                ? new File(saveDir.getParentFile(), "Macros")
                : new File(android.os.Environment.getExternalStorageDirectory(),
                           "WaveGBA/Macros");
        ensureDir(d);
        return d;
    }

    private void startRecording() {
        macro.clear();
        macroCursor = 0;
        macroFrameIndex = 0;
        recording = true;
        replaying = false;
        macroName = null;
        toast("开始录制宏");
    }

    private void stopRecording() {
        recording = false;
        int n = macroTotalFrames();
        toast(n > 0 ? ("录制结束：" + n + " 帧") : "录制结束：没有内容");
    }

    private void startReplay() {
        if (macro.isEmpty()) { toast("还没有录制或加载宏"); return; }
        replaying = true;
        macroFrameIndex = 0;
        macroCursor = 0;
        toast("回放开始");
    }

    private void stopReplay() {
        replaying = false;
        toast("回放结束");
    }

    private void saveMacro() {
        if (macro.isEmpty()) { toast("没有可保存的宏"); return; }
        String stamp = new java.text.SimpleDateFormat("yyyyMMdd-HHmmss",
                java.util.Locale.US).format(new java.util.Date());
        File out = new File(macrosDir(), currentRomName + "-" + stamp + ".macro");
        boolean ok = false;
        try (java.io.PrintWriter w = new java.io.PrintWriter(out, "UTF-8")) {
            w.println("WGMACRO1");
            w.println(currentRomName);
            w.println(macroTotalFrames());
            for (int[] e : macro) w.println(e[0] + " " + e[1]);
            ok = true;
        } catch (Throwable t) {
            Log.e(TAG, "保存宏失败", t);
        }
        toast(ok ? ("已保存：" + out.getName()) : "保存失败");
        if (ok) macroName = out.getName();
    }

    private void loadMacro() {
        File dir = macrosDir();
        File[] files = dir.listFiles((d, n) -> n.endsWith(".macro"));
        if (files == null || files.length == 0) { toast("没有找到宏文件"); return; }
        java.util.Arrays.sort(files, (a, b) -> a.getName().compareTo(b.getName()));
        String[] names = new String[files.length];
        for (int i = 0; i < files.length; i++) names[i] = files[i].getName();

        new android.app.AlertDialog.Builder(this, R.style.DialogTheme)
                .setTitle("加载宏")
                .setItems(names, (d, which) -> {
                    if (readMacro(files[which])) {
                        macroName = files[which].getName();
                        toast("已加载：" + macroName);
                    } else {
                        toast("读取失败");
                    }
                })
                .show();
    }

    private boolean readMacro(File f) {
        java.util.ArrayList<int[]> tmp = new java.util.ArrayList<>();
        try (java.io.BufferedReader r = new java.io.BufferedReader(
                new java.io.InputStreamReader(new java.io.FileInputStream(f), "UTF-8"))) {
            String head = r.readLine();
            if (head == null || !head.startsWith("WGMACRO1")) return false;
            r.readLine();                       // rom name, informational
            r.readLine();                       // total frames, recomputed below
            String line;
            while ((line = r.readLine()) != null) {
                line = line.trim();
                if (line.isEmpty()) continue;
                String[] p = line.split("\\s+");
                if (p.length < 2) continue;
                tmp.add(new int[]{Integer.parseInt(p[0]), Integer.parseInt(p[1])});
            }
        } catch (Throwable t) {
            Log.e(TAG, "读取宏失败", t);
            return false;
        }
        if (tmp.isEmpty()) return false;
        macro.clear();
        macro.addAll(tmp);
        macroCursor = 0;
        macroFrameIndex = 0;
        return true;
    }

    private void showMacroMenu() {
        if (loop != null) loop.setPaused(true);
        String[] items = {
                recording ? "■ 停止录制" : "● 开始录制",
                "▶ 回放" + (replaying ? "（正在回放，点此停止）" : ""),
                "循环回放：" + (macroLoop ? "开" : "关"),
                "保存宏到文件",
                "从文件加载宏…",
                "按键显示：" + (inputDisplayOn ? "开" : "关"),
                "清除当前宏"
        };
        new android.app.AlertDialog.Builder(this, R.style.DialogTheme)
                .setTitle("宏（按键录制/回放）")
                .setItems(items, (d, which) -> {
                    switch (which) {
                        case 0: if (recording) stopRecording(); else startRecording(); break;
                        case 1: if (replaying) stopReplay(); else startReplay(); break;
                        case 2:
                            macroLoop = !macroLoop;
                            toast("循环回放：" + (macroLoop ? "开" : "关"));
                            break;
                        case 3: saveMacro(); break;
                        case 4: loadMacro(); break;
                        case 5:
                            inputDisplayOn = !inputDisplayOn;
                            getSharedPreferences("wavegba", MODE_PRIVATE).edit()
                                    .putBoolean("input_display", inputDisplayOn).apply();
                            showInputDisplay(inputDisplayOn);
                            toast("按键显示：" + (inputDisplayOn ? "开" : "关"));
                            break;
                        case 6:
                            macro.clear();
                            macroCursor = 0;
                            macroFrameIndex = 0;
                            recording = replaying = false;
                            toast("已清除");
                            break;
                    }
                })
                .setOnCancelListener(d -> { if (loop != null) loop.setPaused(false); })
                .show();
    }

    /* ---------------------------------------------------------- 按键显示 */

    private static final int[] DISPLAY_BITS = {
            NativeBridge.BTN_A, NativeBridge.BTN_B, NativeBridge.BTN_L, NativeBridge.BTN_R,
            NativeBridge.BTN_START, NativeBridge.BTN_SELECT,
            NativeBridge.BTN_UP, NativeBridge.BTN_DOWN, NativeBridge.BTN_LEFT,
            NativeBridge.BTN_RIGHT
    };
    private static final String[] DISPLAY_NAMES = {
            "A", "B", "L", "R", "ST", "SEL", "↑", "↓", "←", "→"
    };

    private void showInputDisplay(boolean on) {
        runOnUiThread(() -> {
            try {
                if (!on) {
                    if (inputDisplay != null) {
                        ((ViewGroup) findViewById(R.id.root)).removeView(inputDisplay);
                        inputDisplay = null;
                    }
                    return;
                }
                if (inputDisplay != null) return;
                inputDisplay = new android.widget.TextView(this);
                inputDisplay.setTextColor(0xFF22D3EE);
                inputDisplay.setTextSize(13);
                inputDisplay.setTypeface(android.graphics.Typeface.MONOSPACE);
                inputDisplay.setShadowLayer(3f, 0f, 0f, 0xFF000000);
                android.widget.FrameLayout.LayoutParams lp =
                        new android.widget.FrameLayout.LayoutParams(
                                android.widget.FrameLayout.LayoutParams.WRAP_CONTENT,
                                android.widget.FrameLayout.LayoutParams.WRAP_CONTENT);
                lp.gravity = android.view.Gravity.BOTTOM | android.view.Gravity.CENTER_HORIZONTAL;
                lp.bottomMargin = (int) (28 * getResources().getDisplayMetrics().density);
                ((ViewGroup) findViewById(R.id.root)).addView(inputDisplay, lp);
            } catch (Throwable t) {
                Log.w(TAG, "按键显示失败", t);
            }
        });
    }

    /** Called from the emulation thread, so keep it cheap: only post to the
     *  UI thread when the mask actually changed. */
    private int lastDisplayMask = -1;

    private void updateInputDisplay(int mask) {
        if (!inputDisplayOn || inputDisplay == null || mask == lastDisplayMask) return;
        lastDisplayMask = mask;
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < DISPLAY_BITS.length; i++) {
            if ((mask & DISPLAY_BITS[i]) != 0) {
                if (sb.length() > 0) sb.append(' ');
                sb.append(DISPLAY_NAMES[i]);
            }
        }
        final String txt = sb.toString();
        runOnUiThread(() -> { if (inputDisplay != null) inputDisplay.setText(txt); });
    }

    /* ------------------------------------------------------------- 连发 */

    private static final int[] TURBO_HZ = {5, 10, 15, 20, 30};
    private static final String[] TURBO_HZ_LABELS = {"5 次/秒", "10 次/秒", "15 次/秒", "20 次/秒", "30 次/秒"};

    private final Runnable turboPulse = new Runnable() {
        public void run() {
            turboPhase = !turboPhase;
            onButtons(rawMask);
            long half = 500L / Math.max(1, turboHz);
            turboHandler.postDelayed(this, half);
        }
    };

    private void restartTurbo() {
        if (turboHandler == null) return;
        turboHandler.removeCallbacks(turboPulse);
        if (turboKeys != 0) {
            turboPhase = true;
            turboHandler.post(turboPulse);
        } else {
            turboPhase = false;
            onButtons(rawMask);
        }
    }

    private void showTurboMenu() {
        if (loop != null) loop.setPaused(true);
        boolean[] checked = new boolean[KEY_NAMES.length];
        for (int i = 0; i < KEY_NAMES.length; i++) {
            int bit;
            switch (i) {
                case 0: bit = NativeBridge.BTN_A; break;
                case 1: bit = NativeBridge.BTN_B; break;
                case 2: bit = NativeBridge.BTN_L; break;
                case 3: bit = NativeBridge.BTN_R; break;
                case 4: bit = NativeBridge.BTN_START; break;
                case 5: bit = NativeBridge.BTN_SELECT; break;
                case 6: bit = NativeBridge.BTN_UP; break;
                case 7: bit = NativeBridge.BTN_DOWN; break;
                case 8: bit = NativeBridge.BTN_LEFT; break;
                default: bit = NativeBridge.BTN_RIGHT; break;
            }
            checked[i] = (turboKeys & bit) != 0;
        }
        final int[] bits = new int[KEY_NAMES.length];
        for (int i = 0; i < KEY_NAMES.length; i++) {
            switch (i) {
                case 0: bits[i] = NativeBridge.BTN_A; break;
                case 1: bits[i] = NativeBridge.BTN_B; break;
                case 2: bits[i] = NativeBridge.BTN_L; break;
                case 3: bits[i] = NativeBridge.BTN_R; break;
                case 4: bits[i] = NativeBridge.BTN_START; break;
                case 5: bits[i] = NativeBridge.BTN_SELECT; break;
                case 6: bits[i] = NativeBridge.BTN_UP; break;
                case 7: bits[i] = NativeBridge.BTN_DOWN; break;
                case 8: bits[i] = NativeBridge.BTN_LEFT; break;
                default: bits[i] = NativeBridge.BTN_RIGHT; break;
            }
        }
        new android.app.AlertDialog.Builder(this, R.style.DialogTheme)
                .setTitle("连发键（按住自动连打）")
                .setMultiChoiceItems(KEY_NAMES, checked, (d, which, isChecked) -> {
                    if (isChecked) turboKeys |= bits[which];
                    else turboKeys &= ~bits[which];
                })
                .setNeutralButton("速度 " + turboHz + "/秒", (d, w) -> {
                    getSharedPreferences("wavegba", MODE_PRIVATE).edit()
                            .putInt("turbo_keys", turboKeys).apply();
                    showTurboHzMenu();
                })
                .setPositiveButton("确定", (d, w) -> {
                    getSharedPreferences("wavegba", MODE_PRIVATE).edit()
                            .putInt("turbo_keys", turboKeys).apply();
                    pad.setTurboKeys(turboKeys);
                    restartTurbo();
                    toast("连发已更新");
                    if (loop != null) loop.setPaused(false);
                })
                .setOnCancelListener(d -> { if (loop != null) loop.setPaused(false); })
                .show();
    }

    private void showTurboHzMenu() {
        int cur = 2;
        for (int i = 0; i < TURBO_HZ.length; i++) if (TURBO_HZ[i] == turboHz) cur = i;
        new android.app.AlertDialog.Builder(this, R.style.DialogTheme)
                .setTitle("连发速度")
                .setSingleChoiceItems(TURBO_HZ_LABELS, cur, (d, which) -> {
                    turboHz = TURBO_HZ[which];
                    getSharedPreferences("wavegba", MODE_PRIVATE).edit()
                            .putInt("turbo_hz", turboHz).apply();
                    restartTurbo();
                    d.dismiss();
                    toast("连发速度：" + TURBO_HZ_LABELS[which]);
                    if (loop != null) loop.setPaused(false);
                })
                .setOnCancelListener(d -> { if (loop != null) loop.setPaused(false); })
                .show();
    }

    /* ------------------------------------------------------- 游戏信息 */

    /** GBA cart header: title 0xA0, code 0xAC, maker 0xB0, version 0xBC. */
    private String romInfo() {
        byte[] h = romHeader;
        if (h == null || h.length < 0xC0) return "没有载入游戏";
        StringBuilder sb = new StringBuilder();
        sb.append("标题：").append(currentRomName).append("\n");

        String code = new String(h, 0xAC, 4, java.nio.charset.StandardCharsets.US_ASCII)
                .replaceAll("[^A-Za-z0-9]", "?");
        sb.append("游戏编号：").append(code).append("\n");

        String mk = new String(h, 0xB0, 2, java.nio.charset.StandardCharsets.US_ASCII);
        sb.append("厂商：").append(makerName(mk)).append("  ").append(mk).append("\n");
        sb.append("版本：").append(String.format(java.util.Locale.US, "1.%d", h[0xBC] & 0xFF))
                .append("\n");

        // Region is encoded in the 4th character of the game code.
        String region = "未知";
        if (code.length() >= 4) {
            char c = code.charAt(3);
            if (c == 'E') region = "美版 / NTSC";
            else if (c == 'J') region = "日版";
            else if (c == 'P') region = "欧版 / PAL";
            else if (c == 'F') region = "法版";
            else if (c == 'D') region = "德版";
            else if (c == 'I') region = "意版";
            else if (c == 'S') region = "西版";
        }
        sb.append("地区：").append(region);
        return sb.toString();
    }

    private static String makerName(String code) {
        if (code.equals("01")) return "任天堂";
        if (code.equals("08")) return "Capcom";
        if (code.equals("13")) return "Electronic Arts";
        if (code.equals("18")) return "Hudson Soft";
        if (code.equals("24")) return "Koei";
        if (code.equals("28")) return "Kemco";
        if (code.equals("31")) return "Bandai";
        if (code.equals("32")) return "Acclaim";
        if (code.equals("41")) return "Ubisoft";
        if (code.equals("45")) return "Sammy";
        if (code.equals("51")) return "Konami";
        if (code.equals("64")) return "LucasArts";
        if (code.equals("69")) return "THQ";
        if (code.equals("79")) return "Disney";
        if (code.equals("99")) return "Take-Two";
        if (code.equals("A4")) return "Bandai Namco";
        return "其他";
    }

    private void showRomInfo() {
        new android.app.AlertDialog.Builder(this, R.style.DialogTheme)
                .setTitle("游戏信息")
                .setMessage(romInfo())
                .setPositiveButton("知道了", null)
                .show();
    }

    /* ----------------------------------------------------- 菜单结构 ----- */

    /** A menu row: a section heading (toggles that section) or an action. */
    private static final class MenuRow {
        final boolean header;
        final String text;
        final int action;
        final int section;          // header only: which section it toggles
        MenuRow(String heading, int sec, boolean collapsed, int items) {
            header = true;
            section = sec;
            action = -1;
            // The chevron is the affordance, and the count is what makes the
            // collapsed state worth having -- with it you can still tell the
            // section is not empty.
            text = (collapsed ? "\u25B6 " : "\u25BC ") + heading
                    + (collapsed ? "  (" + items + ")" : "");
        }
        MenuRow(String t, int a) { header = false; text = t; action = a; section = -1; }
    }

    /** Menu actions, named rather than positional.
     *
     *  The old switch keyed off the row index, so every inserted item shifted
     *  the meaning of every case below it -- one off-by-one and a row silently
     *  ran the wrong handler. Dispatching on a named action makes reordering
     *  the menu safe. */
    private static final int A_RESUME    = 0;
    private static final int A_SPEED     = 1;
    private static final int A_RESET     = 2;
    private static final int A_SAVE_SLOT = 3;
    private static final int A_LOAD_SLOT = 4;
    private static final int A_EXPORT    = 5;
    private static final int A_IMPORT    = 6;
    private static final int A_DISPLAY   = 7;
    private static final int A_SHOT      = 8;
    private static final int A_RECORD    = 9;
    private static final int A_ORIENT    = 10;
    private static final int A_LAYOUT    = 11;
    private static final int A_TURBO     = 12;
    private static final int A_VOLUME    = 13;
    private static final int A_MACRO     = 14;
    private static final int A_INFO      = 15;
    private static final int A_RTC       = 16;
    private static final int A_SWITCH    = 17;
    private static final int A_ABOUT     = 18;
    private static final int A_QUICK_SAVE = 19;
    private static final int A_QUICK_LOAD = 20;
    private static final int A_THEME = 21;

    /** Section headings, click-disabled rows with their own styling. */
    private final class MenuAdapter extends android.widget.BaseAdapter {
        private final java.util.List<MenuRow> rows;
        MenuAdapter(java.util.List<MenuRow> r) { rows = r; }
        public int getCount() { return rows.size(); }
        public Object getItem(int p) { return rows.get(p); }
        public long getItemId(int p) { return p; }
        /** Headings must not be clickable; ListView skips disabled rows. */
        /** Headings are clickable: they collapse and expand their section. */
        public boolean isEnabled(int p) { return true; }
        public boolean areAllItemsEnabled() { return true; }
        public int getItemViewType(int p) { return rows.get(p).header ? 0 : 1; }
        public int getViewTypeCount() { return 2; }
        public android.view.View getView(int p, android.view.View cv,
                                         android.view.ViewGroup parent) {
            MenuRow r = rows.get(p);
            float d = getResources().getDisplayMetrics().density;
            android.widget.TextView tv =
                    (cv instanceof android.widget.TextView)
                            ? (android.widget.TextView) cv
                            : new android.widget.TextView(MainActivity.this);
            tv.setText(r.text);
            if (r.header) {
                tv.setTextColor(0xFF7BC8E8);
                tv.setTextSize(12);
                tv.setPadding((int) (14 * d), (int) (12 * d),
                              (int) (14 * d), (int) (8 * d));
            } else {
                tv.setTextColor(0xFFEEEEF2);
                tv.setTextSize(15);
                tv.setPadding((int) (22 * d), (int) (10 * d),
                              (int) (14 * d), (int) (10 * d));
            }
            return tv;
        }
    }

    /* --------------------------------------------------- 分类展开/收起 -- */

    private static final int SEC_RUN = 0, SEC_SAVE = 1, SEC_DISP = 2,
            SEC_CTRL = 3, SEC_MISC = 4;
    private static final int SECTION_COUNT = 5;

    /** Collapsed flags, persisted as a bitmask.
     *
     *  Default is expanded for every section: a menu that starts partly
     *  hidden just looks like missing functionality. */
    private final boolean[] sectionCollapsed = new boolean[SECTION_COUNT];

    private void loadMenuCollapsed() {
        int bits = getSharedPreferences("wavegba", MODE_PRIVATE)
                .getInt("menu_collapsed", 0);
        for (int i = 0; i < SECTION_COUNT; i++) sectionCollapsed[i] = (bits & (1 << i)) != 0;
    }

    private void saveMenuCollapsed() {
        int bits = 0;
        for (int i = 0; i < SECTION_COUNT; i++) if (sectionCollapsed[i]) bits |= 1 << i;
        getSharedPreferences("wavegba", MODE_PRIVATE)
                .edit().putInt("menu_collapsed", bits).apply();
    }

    /** Build the flat row list, skipping the items of collapsed sections. */
    private java.util.List<MenuRow> buildMenuRows() {
        java.util.List<MenuRow> rows = new java.util.ArrayList<MenuRow>();

        // Recording hides the stop button if 画面 is collapsed, and there is
        // no other way to stop it -- so that section stays open while
        // recording is in progress.
        boolean recording = isRecording();
        boolean[] hide = sectionCollapsed.clone();
        if (recording) hide[SEC_DISP] = false;

        int[] counts = {3, 6, 5, 3, 5};

        rows.add(new MenuRow("运行", SEC_RUN, hide[SEC_RUN], counts[SEC_RUN]));
        if (!hide[SEC_RUN]) {
            rows.add(new MenuRow("继续游戏", A_RESUME));
            rows.add(new MenuRow("倍速：" + speedText(), A_SPEED));
            rows.add(new MenuRow("重置游戏", A_RESET));
        }

        rows.add(new MenuRow("存档", SEC_SAVE, hide[SEC_SAVE], counts[SEC_SAVE]));
        if (!hide[SEC_SAVE]) {
            rows.add(new MenuRow("快速存档（独立槽位）", A_QUICK_SAVE));
            rows.add(new MenuRow("快速读档"
                    + (quickSlotUsed() ? "" : "（空）"), A_QUICK_LOAD));
            rows.add(new MenuRow("存档到槽位…", A_SAVE_SLOT));
            rows.add(new MenuRow("读取槽位…", A_LOAD_SLOT));
            rows.add(new MenuRow("导出存档", A_EXPORT));
            rows.add(new MenuRow("导入存档…", A_IMPORT));
        }

        rows.add(new MenuRow("画面", SEC_DISP, hide[SEC_DISP], counts[SEC_DISP]));
        if (!hide[SEC_DISP]) {
            rows.add(new MenuRow("画面设置…", A_DISPLAY));
            rows.add(new MenuRow("主题：" + Theme.NAMES[Theme.preset()], A_THEME));
            rows.add(new MenuRow("截图", A_SHOT));
            rows.add(new MenuRow(recording
                    ? "■ 停止录制（" + recordElapsed()
                            + (recordHasAudio ? " · 有声" : " · 无声") + "）"
                    : "● 录制视频", A_RECORD));
            rows.add(new MenuRow("屏幕方向：" + ORIENT_LABELS[orientation], A_ORIENT));
        }

        rows.add(new MenuRow("操作", SEC_CTRL, hide[SEC_CTRL], counts[SEC_CTRL]));
        if (!hide[SEC_CTRL]) {
            rows.add(new MenuRow("按键布局…", A_LAYOUT));
            rows.add(new MenuRow("连发键：" + (turboKeys == 0 ? "关" : turboHz + "/秒"),
                    A_TURBO));
            rows.add(new MenuRow("音量：" + volumeText()
                    + (audio != null && audio.isMuted() ? "（静音）" : ""), A_VOLUME));
        }

        rows.add(new MenuRow("其他", SEC_MISC, hide[SEC_MISC], counts[SEC_MISC]));
        if (!hide[SEC_MISC]) {
            rows.add(new MenuRow("宏（按键录制）…", A_MACRO));
            rows.add(new MenuRow("游戏信息", A_INFO));
            rows.add(new MenuRow("实时时钟（RTC）：" + rtcModeName(), A_RTC));
            rows.add(new MenuRow("切换游戏", A_SWITCH));
            rows.add(new MenuRow("关于", A_ABOUT));
        }
        return rows;
    }

    /** 右上角菜单 */
    public void onMenu(android.view.View v) {
        if (loop != null) loop.setPaused(true);

        final java.util.List<MenuRow> rows = new java.util.ArrayList<MenuRow>();
        rows.addAll(buildMenuRows());
        final MenuAdapter adapter = new MenuAdapter(rows);

        // A hand-built ListView rather than Builder.setAdapter(): the builder
        // installs its own OnItemClickListener, and that listener calls
        // dismiss() on EVERY row before ours ever runs. Toggling a section
        // therefore closed the menu -- which made collapsing useless, since
        // you had to reopen the menu to see the result. With our own view we
        // decide which rows dismiss and which do not.
        android.widget.ListView list = new android.widget.ListView(this);
        list.setAdapter(adapter);
        list.setDivider(null);
        list.setBackgroundColor(0xFF17171C);
        list.setPadding(0, (int) (6 * getResources().getDisplayMetrics().density),
                0, (int) (6 * getResources().getDisplayMetrics().density));

        final android.app.AlertDialog dlg =
                new android.app.AlertDialog.Builder(this, R.style.DialogTheme)
                .setTitle("WaveGBA  ·  菜单")
                .setView(list)
                .setOnCancelListener(d -> { if (loop != null) loop.setPaused(false); })
                .create();

        list.setOnItemClickListener(
                new android.widget.AdapterView.OnItemClickListener() {
            public void onItemClick(android.widget.AdapterView<?> parent,
                                    android.view.View v, int which, long id) {
                if (which < 0 || which >= rows.size()) return;
                MenuRow row = rows.get(which);
                if (row.header) {
                    // Navigation, not an action: rebuild in place, keep the
                    // dialog open, keep the loop paused.
                    sectionCollapsed[row.section] = !sectionCollapsed[row.section];
                    saveMenuCollapsed();
                    rows.clear();
                    rows.addAll(buildMenuRows());
                    adapter.notifyDataSetChanged();
                    return;
                }
                dlg.dismiss();

                // Anything that opens a sub-dialog takes over pausing;
                // everything else must hand the loop back to the player.
                // Without this, "关闭画面平滑" left the emulation paused
                // and the picture simply froze -- the dialog's
                // OnCancelListener does NOT fire when an item is picked,
                // so nothing ever resumed it.
                boolean handsOff = false;
                switch (row.action) {
                    case A_RESUME: break;
                    case A_SPEED:  handsOff = true; showSpeedMenu(); break;
                    case A_RESET:
                            NativeBridge.nativeReset();
                            toast("已重置");
                    break;
                    case A_QUICK_SAVE:
                            quickSave();
                    break;
                    case A_QUICK_LOAD:
                            handsOff = true;
                            quickLoad();
                    break;
                    case A_SAVE_SLOT: handsOff = true; showSaveSlotMenu(); break;
                    case A_LOAD_SLOT: handsOff = true; showLoadSlotMenu(); break;
                    case A_EXPORT:    handsOff = true; exportSaves(); break;
                    case A_IMPORT:    handsOff = true; importSaves(); break;
                    case A_DISPLAY:   handsOff = true; showDisplayMenu(); break;
                    case A_THEME:     handsOff = true; showThemeMenu(); break;
                    case A_SHOT:      takeScreenshot(); break;
                    case A_RECORD:
                            if (isRecording()) { stopVideo(); }
                            else { handsOff = true; showRecordMenu(); }
                    break;
                    case A_ORIENT: handsOff = true; showOrientationMenu(); break;
                    case A_LAYOUT: handsOff = true; showLayoutMenu(); break;
                    case A_TURBO:  handsOff = true; showTurboMenu(); break;
                    case A_VOLUME: handsOff = true; showVolumeMenu(); break;
                    case A_MACRO:  handsOff = true; showMacroMenu(); break;
                    case A_INFO:   handsOff = true; showRomInfo(); break;
                    case A_RTC:    handsOff = true; showRtcMenu(); break;
                    case A_SWITCH:
                            handsOff = true;
                            flushBattery();
                            pickRom();
                    break;
                    case A_ABOUT: handsOff = true; showAbout(); break;
                    }
                    if (!handsOff && loop != null) loop.setPaused(false);
            }
        });
        dlg.show();
    }

    /* ------------------------------------------------------------ 主题 -- */

    /** Preset list; picking 自定义 opens the hue picker. */
    private void showThemeMenu() {
        final android.content.SharedPreferences sp =
                getSharedPreferences("wavegba", MODE_PRIVATE);
        float d = getResources().getDisplayMetrics().density;

        android.widget.LinearLayout box = new android.widget.LinearLayout(this);
        box.setOrientation(android.widget.LinearLayout.VERTICAL);
        int pad = (int) (16 * d);
        box.setPadding(pad, pad, pad, pad);

        final int[] presets = {Theme.P_DEEP, Theme.P_GBA, Theme.P_OLED,
                Theme.P_CONTRAST, Theme.P_CUSTOM};

        for (int i = 0; i < presets.length; i++) {
            android.widget.LinearLayout line =
                    new android.widget.LinearLayout(this);
            line.setOrientation(android.widget.LinearLayout.HORIZONTAL);
            line.setGravity(android.view.Gravity.CENTER_VERTICAL);
            android.widget.LinearLayout.LayoutParams ll =
                    new android.widget.LinearLayout.LayoutParams(
                            android.widget.LinearLayout.LayoutParams.MATCH_PARENT,
                            android.widget.LinearLayout.LayoutParams.WRAP_CONTENT);
            ll.setMargins(0, 0, 0, (int) (10 * d));
            line.setLayoutParams(ll);

            android.view.View chip = new android.view.View(this);
            int cs = (int) (30 * d);
            android.widget.LinearLayout.LayoutParams cl =
                    new android.widget.LinearLayout.LayoutParams(cs, cs);
            cl.setMargins(0, 0, (int) (12 * d), 0);
            chip.setLayoutParams(cl);
            // Each chip shows that preset's own palette; choosing on the
            // actual colours beats choosing on the name.
            chip.setBackgroundDrawable(
                    swatchDrawable(presetSurface(presets[i]),
                            presetAccent(presets[i])));

            android.widget.TextView t = new android.widget.TextView(this);
            t.setText(Theme.NAMES[i]);
            t.setTextSize(15);
            t.setTextColor(Theme.textPrimary());

            line.addView(chip);
            line.addView(t);
            box.addView(line);

            final int idx = i;
            line.setOnClickListener(new android.view.View.OnClickListener() {
                public void onClick(android.view.View v) {
                    if (presets[idx] == Theme.P_CUSTOM) {
                        showAccentPicker(sp);
                        return;
                    }
                    Theme.setPreset(presets[idx]);
                    Theme.save(sp);
                    applyTheme();
                    toast("主题：" + Theme.NAMES[Theme.preset()]);
                }
            });
        }

        android.widget.TextView hint = new android.widget.TextView(this);
        hint.setText("选「自定义」可调主色");
        hint.setTextSize(12);
        hint.setTextColor(Theme.textSecondary());
        hint.setPadding(0, (int) (6 * d), 0, 0);
        box.addView(hint);

        new android.app.AlertDialog.Builder(this, R.style.DialogTheme)
                .setTitle("主题")
                .setView(box)
                .setNegativeButton("关闭",
                        new android.content.DialogInterface.OnClickListener() {
                    public void onClick(android.content.DialogInterface dlg, int w) {
                        if (loop != null) loop.setPaused(false);
                    }
                })
                .setOnCancelListener(dlg2 -> { if (loop != null) loop.setPaused(false); })
                .show();
    }

    private static int presetAccent(int p) {
        switch (p) {
            case Theme.P_GBA: return 0xFF8B5CF6;
            case Theme.P_OLED: return 0xFF34D399;
            case Theme.P_CONTRAST: return 0xFFFBBF24;
            default: return 0xFF22D3EE;
        }
    }

    private static int presetSurface(int p) {
        switch (p) {
            case Theme.P_GBA: return 0xFF3A3A44;
            case Theme.P_OLED: return 0xFF0A0A0A;
            case Theme.P_CONTRAST: return 0xFF141414;
            default: return 0xFF17171C;
        }
    }

    private android.graphics.drawable.Drawable swatchDrawable(int surface, int accent) {
        float d = getResources().getDisplayMetrics().density;
        android.graphics.drawable.GradientDrawable g =
                new android.graphics.drawable.GradientDrawable();
        g.setShape(android.graphics.drawable.GradientDrawable.OVAL);
        g.setColor(surface);
        g.setStroke(Math.max(2, (int) (3 * d)), accent);
        return g;
    }

    /** Twelve hue swatches plus a slider for fine adjustment. */
    private void showAccentPicker(final android.content.SharedPreferences sp) {
        float d = getResources().getDisplayMetrics().density;
        android.widget.LinearLayout box = new android.widget.LinearLayout(this);
        box.setOrientation(android.widget.LinearLayout.VERTICAL);
        // MATCH_PARENT so every child is measured against the same width;
        // with WRAP_CONTENT the bar and the swatch row get different widths
        // and end up misaligned.
        box.setLayoutParams(new android.view.ViewGroup.LayoutParams(
                android.view.ViewGroup.LayoutParams.MATCH_PARENT,
                android.view.ViewGroup.LayoutParams.WRAP_CONTENT));
        int pad = (int) (16 * d);
        box.setPadding(pad, pad, pad, pad);

        final android.view.View preview = new android.view.View(this);
        box.addView(preview, new android.widget.LinearLayout.LayoutParams(
                android.widget.LinearLayout.LayoutParams.MATCH_PARENT,
                (int) (44 * d)));
        preview.setBackgroundDrawable(
                swatchDrawable(Theme.surface(), Theme.accent()));


        // A colour wheel: angle picks hue, distance from the centre picks
        // saturation. Replaces the earlier rainbow slider, which could only
        // express hue -- saturation had to be a fixed constant, so the track
        // was drawn at one saturation and produced another.
        final ColorWheelView wheel = new ColorWheelView(this);
        android.widget.LinearLayout.LayoutParams bl =
                new android.widget.LinearLayout.LayoutParams(
                        android.widget.LinearLayout.LayoutParams.MATCH_PARENT,
                        android.widget.LinearLayout.LayoutParams.WRAP_CONTENT);
        bl.setMargins(0, (int) (14 * d), 0, 0);
        box.addView(wheel, bl);

        final android.widget.TextView val = new android.widget.TextView(this);
        val.setTextSize(12);
        val.setTextColor(Theme.textSecondary());
        val.setPadding(0, (int) (8 * d), 0, 0);
        box.addView(val);

        final Runnable refreshPreview = new Runnable() {
            public void run() {
                int c = Theme.accent();
                preview.setBackgroundDrawable(
                        swatchDrawable(Theme.surface(), c));
                wheel.setColor(c);
                val.setText("主色 " + String.format("#%06X", c & 0x00FFFFFF)
                        + "   色相 " + Math.round(Theme.hueOf(c)) + "°"
                        + "   饱和度 " + Math.round(satOf(c) * 100) + "%");
            }
        };
        refreshPreview.run();


        wheel.setOnColorChanged(new ColorWheelView.OnColorChanged() {
            public void onColorChanged(float hue, float sat, boolean committed) {
                Theme.setAccentHueSat(hue, sat);
                refreshPreview.run();
                if (committed) { Theme.save(sp); applyTheme(); }
            }
        });

        new android.app.AlertDialog.Builder(this, R.style.DialogTheme)
                .setTitle("自定义主色")
                .setView(box)
                .setNegativeButton("完成",
                        new android.content.DialogInterface.OnClickListener() {
                    public void onClick(android.content.DialogInterface dlg, int w) {
                        if (loop != null) loop.setPaused(false);
                    }
                })
                .setOnCancelListener(dlg2 -> { if (loop != null) loop.setPaused(false); })
                .show();
    }

    /** Saturation of a colour, 0..1. Shown next to the hue readout so a
     *  drag that lands on a washed-out colour is visible as such. */
    private static float satOf(int color) {
        float[] hsv = new float[3];
        android.graphics.Color.colorToHSV(color, hsv);
        return hsv[1];
    }

    /** A circular colour chip that stays square whatever width it is given.
     *
     *  Used with weight=1 inside a horizontal row, so the measured width is
     *  whatever share of the row it was allocated; forcing the height to match
     *  keeps the chip a circle instead of an ellipse as that share changes. */
    /** Rainbow track, thumb and a row of preset chips, all in one view.
     *
     *  Everything is positioned from this view's own measured width, so the
     *  chips cannot end up wider than the track they sit under -- which is
     *  what happened when they were a sibling LinearLayout resolving
     *  MATCH_PARENT against a dialog that had not been measured yet. */
    /** Circular HSV picker: angle = hue, radius = saturation.
     *
     *  Replaces the rainbow slider, which carried hue only -- saturation was
     *  a hardcoded constant, so the track was painted at one saturation while
     *  the colour it produced had another. A wheel exposes both axes and gets
     *  rid of that mismatch.
     *
     *  The disc is rendered once into a bitmap rather than with a
     *  SweepGradient plus an overlaid RadialGradient: composing those two
     *  needs a clipPath, and clipPath is unsupported under hardware
     *  acceleration before API 18. Per-pixel HSV is exact and needs no
     *  shader support at all. */
    private static final class ColorWheelView extends android.view.View {

        interface OnColorChanged {
            void onColorChanged(float hue, float sat, boolean committed);
        }

        /** Upper bound on the cached bitmap.
         *
         *  Building the disc is O(n^2) with a sqrt, an atan2 and an HSV
         *  conversion per pixel, all on the drawing thread. At 420px that is
         *  176k pixels and a visible hitch the first time the picker opens.
         *  240px costs a quarter as much, and since the disc is a smooth
         *  gradient, bilinear upscaling to the on-screen size lands within
         *  0.2% of the full-resolution colour -- measured, not assumed. */
        private static final int MAX_PX = 240;

        private float hue = 0f, sat = 0.78f;
        private OnColorChanged listener = null;
        private android.graphics.Bitmap disc = null;
        private int discSize = -1;

        private final android.graphics.Paint bmp =
                new android.graphics.Paint(android.graphics.Paint.FILTER_BITMAP_FLAG);
        private final android.graphics.Paint ring =
                new android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG);
        private final android.graphics.Paint ringOuter =
                new android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG);
        private final android.graphics.Paint edge =
                new android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG);

        ColorWheelView(android.content.Context c) { super(c); }

        void setOnColorChanged(OnColorChanged l) { listener = l; }

        /** Position the marker from an existing colour. */
        void setColor(int color) {
            float[] hsv = new float[3];
            android.graphics.Color.colorToHSV(color, hsv);
            hue = hsv[0];
            sat = hsv[1];
            invalidate();
        }

        private float dp(float v) {
            return v * getResources().getDisplayMetrics().density;
        }

        @Override
        protected void onMeasure(int wSpec, int hSpec) {
            int w = android.view.View.MeasureSpec.getSize(wSpec);
            if (android.view.View.MeasureSpec.getMode(wSpec)
                    == android.view.View.MeasureSpec.UNSPECIFIED) {
                w = (int) dp(240);
            }
            // Square: the disc must not become an ellipse.
            setMeasuredDimension(w, w);
        }

        /** Build (or reuse) the disc bitmap for the current size. */
        private void ensureDisc(int size) {
            if (disc != null && discSize == size) return;
            if (size <= 0) return;
            android.graphics.Bitmap b = android.graphics.Bitmap.createBitmap(
                    size, size, android.graphics.Bitmap.Config.ARGB_8888);
            float c = (size - 1) / 2f;
            float[] hsv = new float[]{0f, 0f, 1f};
            int[] row = new int[size];
            for (int y = 0; y < size; y++) {
                float dy = y - c;
                // Only the inscribed circle is ever visible, so skip the
                // corners instead of walking them and writing transparent.
                // That is ~21% of the bitmap's area, and on the rows near the
                // top and bottom it is most of the row.
                float half = dy * dy;
                if (half >= c * c) {
                    java.util.Arrays.fill(row, 0);
                    b.setPixels(row, 0, size, 0, y, size, 1);
                    continue;
                }
                int x0 = (int) Math.ceil(c - Math.sqrt(c * c - half));
                int x1 = (int) Math.floor(c + Math.sqrt(c * c - half));
                if (x0 < 0) x0 = 0;
                if (x1 > size - 1) x1 = size - 1;
                java.util.Arrays.fill(row, 0, x0, 0);
                for (int x = x0; x <= x1; x++) {
                    float dx = x - c;
                    float r = (float) Math.sqrt(dx * dx + half) / c;
                    if (r > 1f) { row[x] = 0; continue; }
                    hsv[0] = (float) (Math.atan2(dy, dx) * 180f / Math.PI);
                    if (hsv[0] < 0) hsv[0] += 360f;
                    hsv[1] = r;
                    row[x] = android.graphics.Color.HSVToColor(hsv);
                }
                java.util.Arrays.fill(row, x1 + 1, size, 0);
                b.setPixels(row, 0, size, 0, y, size, 1);
            }
            if (disc != null) disc.recycle();
            disc = b;
            discSize = size;
        }

        @Override
        protected void onDraw(android.graphics.Canvas cv) {
            int size = Math.min(getWidth(), getHeight());
            if (size <= 0) return;
            // Cap the bitmap; draw scaled up if the view is larger.
            int px = Math.min(size, MAX_PX);
            ensureDisc(px);
            if (disc == null) return;

            float cx = getWidth() / 2f, cy = getHeight() / 2f;
            float R = size / 2f;

            cv.save();
            android.graphics.Path clip = new android.graphics.Path();
            clip.addCircle(cx, cy, R, android.graphics.Path.Direction.CW);
            // Clipping to a circle is fine: the region API accepts paths on
            // all versions, unlike clipPath under hardware acceleration.
            cv.clipPath(clip);
            cv.drawBitmap(disc, null,
                    new android.graphics.RectF(cx - R, cy - R, cx + R, cy + R), bmp);
            cv.restore();

            edge.setStyle(android.graphics.Paint.Style.STROKE);
            edge.setStrokeWidth(dp(2));
            edge.setColor(0x33000000);
            cv.drawCircle(cx, cy, R - dp(1), edge);

            // Marker: dark halo, white ring, then the live colour, so it stays
            // readable over both the pale centre and the saturated rim.
            float ang = (float) (hue * Math.PI / 180f);
            float rad = sat * (R - dp(6));
            float mx = cx + (float) Math.cos(ang) * rad;
            float my = cy + (float) Math.sin(ang) * rad;
            float mr = dp(9);
            ringOuter.setColor(0x66000000);
            cv.drawCircle(mx + dp(0.5f), my + dp(1f), mr, ringOuter);
            ring.setStyle(android.graphics.Paint.Style.FILL);
            ring.setColor(0xFFFFFFFF);
            cv.drawCircle(mx, my, mr, ring);
            ring.setColor(android.graphics.Color.HSVToColor(
                    new float[]{hue, sat, 1f}));
            cv.drawCircle(mx, my, mr - dp(2.5f), ring);
        }

        private void fromPoint(float x, float y) {
            float cx = getWidth() / 2f, cy = getHeight() / 2f;
            float R = Math.min(getWidth(), getHeight()) / 2f;
            if (R <= 0) return;
            float dx = x - cx, dy = y - cy;
            float r = (float) Math.sqrt(dx * dx + dy * dy) / R;
            if (r > 1f) r = 1f;              // clamp to the disc
            float a = (float) (Math.atan2(dy, dx) * 180f / Math.PI);
            if (a < 0) a += 360f;
            hue = a;
            sat = r;
            invalidate();
        }

        @Override
        public boolean onTouchEvent(android.view.MotionEvent e) {
            switch (e.getActionMasked()) {
                case android.view.MotionEvent.ACTION_DOWN:
                    getParent().requestDisallowInterceptTouchEvent(true);
                    fromPoint(e.getX(), e.getY());
                    if (listener != null) listener.onColorChanged(hue, sat, false);
                    return true;
                case android.view.MotionEvent.ACTION_MOVE:
                    fromPoint(e.getX(), e.getY());
                    if (listener != null) listener.onColorChanged(hue, sat, false);
                    return true;
                case android.view.MotionEvent.ACTION_UP:
                case android.view.MotionEvent.ACTION_CANCEL:
                    fromPoint(e.getX(), e.getY());
                    // Committed only on release: saving on every move would
                    // hammer SharedPreferences during a drag.
                    if (listener != null) listener.onColorChanged(hue, sat, true);
                    return true;
            }
            return false;
        }
    }

    /** A rainbow track with a draggable thumb: pick an accent by hue.
     *
     *  Drawn rather than a styled SeekBar because API 14 has no way to give
     *  the stock widget a gradient track, and a grey groove tells you nothing
     *  about what dragging it produces. The thumb is a ring so the track stays
     *  visible underneath it at both ends, where it would otherwise be
     *  clipped by the view's edge. */
    private static final class HueBar extends android.view.View {

        interface OnHueChanged {
            void onHueChanged(float hue, boolean committed);
        }

        private float hue = 0f;
        private OnHueChanged listener = null;

        private final android.graphics.Paint trackPaint =
                new android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG);
        private final android.graphics.Paint thumbFill =
                new android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG);
        private final android.graphics.Paint thumbRing =
                new android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG);
        private final android.graphics.Paint thumbShadow =
                new android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG);
        private final android.graphics.RectF rect = new android.graphics.RectF();

        HueBar(android.content.Context c) { super(c); }

        void setOnHueChanged(OnHueChanged l) { listener = l; }

        void setHue(float h) {
            hue = h % 360f;
            if (hue < 0) hue += 360f;
            invalidate();
        }

        private float radius() { return getHeight() / 2f - 2f * dp(1); }

        private float dp(float v) {
            return v * getResources().getDisplayMetrics().density;
        }

        /** Track span available to the thumb's centre. */
        private float trackLeft() { return radius(); }
        private float trackRight() { return getWidth() - radius(); }

        private float hueToX(float h) {
            return trackLeft() + (h / 360f) * (trackRight() - trackLeft());
        }

        private float xToHue(float x) {
            float span = trackRight() - trackLeft();
            if (span <= 0) return 0f;
            float t = (x - trackLeft()) / span;
            return Math.max(0f, Math.min(1f, t)) * 360f;
        }

        @Override
        protected void onDraw(android.graphics.Canvas c) {
            float r = radius();
            float h = getHeight();
            rect.set(0, 0, getWidth(), h);

            // Rainbow track, built from short gradients: a single multi-stop
            // shader would interpolate in sRGB and desaturate between stops,
            // which is exactly the washed-out band this is meant to avoid.
            int steps = 48;
            float w = getWidth() / (float) steps;
            for (int i = 0; i < steps; i++) {
                float h0 = i * 360f / steps, h1 = (i + 1) * 360f / steps;
                int c0 = android.graphics.Color.HSVToColor(new float[]{h0, 0.85f, 1f});
                int c1 = android.graphics.Color.HSVToColor(new float[]{h1, 0.85f, 1f});
                trackPaint.setShader(new android.graphics.LinearGradient(
                        i * w, 0, (i + 1) * w, 0, c0, c1,
                        android.graphics.Shader.TileMode.CLAMP));
                c.drawRect(i * w, 0, (i + 1) * w, h, trackPaint);
            }
            trackPaint.setShader(null);

            // Rounded frame, clipped so the rainbow takes the corner radius
            // instead of showing square corners outside it.
            float rad = h / 2f;
            c.save();
            c.clipRect(rect);
            android.graphics.Paint frame =
                    new android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG);
            frame.setStyle(android.graphics.Paint.Style.STROKE);
            frame.setStrokeWidth(dp(2));
            frame.setColor(0x33000000);
            c.drawRoundRect(new android.graphics.RectF(dp(1), dp(1),
                    getWidth() - dp(1), h - dp(1)), rad, rad, frame);
            c.restore();

            // Thumb: dark halo, then a white ring, then the live colour. The
            // halo is what keeps the ring readable when the track beneath it
            // happens to be whiteish (the yellow band).
            float cx = hueToX(hue), cy = h / 2f;
            thumbShadow.setColor(0x66000000);
            c.drawCircle(cx + dp(0.5f), cy + dp(1f), r, thumbShadow);
            thumbRing.setStyle(android.graphics.Paint.Style.FILL);
            thumbRing.setColor(0xFFFFFFFF);
            c.drawCircle(cx, cy, r, thumbRing);
            thumbFill.setColor(android.graphics.Color.HSVToColor(
                    new float[]{hue, 0.85f, 1f}));
            c.drawCircle(cx, cy, r - dp(2.5f), thumbFill);
        }

        @Override
        public boolean onTouchEvent(android.view.MotionEvent e) {
            switch (e.getActionMasked()) {
                case android.view.MotionEvent.ACTION_DOWN:
                    getParent().requestDisallowInterceptTouchEvent(true);
                    setHue(xToHue(e.getX()));
                    if (listener != null) listener.onHueChanged(hue, false);
                    return true;
                case android.view.MotionEvent.ACTION_MOVE:
                    setHue(xToHue(e.getX()));
                    if (listener != null) listener.onHueChanged(hue, false);
                    return true;
                case android.view.MotionEvent.ACTION_UP:
                case android.view.MotionEvent.ACTION_CANCEL:
                    setHue(xToHue(e.getX()));
                    // Committed on release: writing preferences on every move
                    // event would hammer SharedPreferences during a drag.
                    if (listener != null) listener.onHueChanged(hue, true);
                    return true;
            }
            return false;
        }

        @Override
        protected void onMeasure(int wSpec, int hSpec) {
            // Take the full width the parent offers instead of capping at
            // 240dp. resolveSize() clamps to the requested size whenever the
            // spec is AT_MOST, which is what a MATCH_PARENT view inside a
            // WRAP_CONTENT dialog gets -- so the bar measured 240dp while the
            // MATCH_PARENT swatch row beside it got the whole panel, and the
            // swatches visibly overran the track.
            //
            // The 240dp only applies when nothing constrains us at all.
            int w = android.view.View.MeasureSpec.getSize(wSpec);
            if (android.view.View.MeasureSpec.getMode(wSpec)
                    == android.view.View.MeasureSpec.UNSPECIFIED) {
                w = (int) dp(240);
            }
            setMeasuredDimension(w,
                    android.view.View.resolveSize((int) dp(30), hSpec));
        }
    }

    /** Repaint the live UI after a theme change. */
    private void applyTheme() {
        if (pad != null) pad.applyTheme();
        if (screen != null) screen.applyTheme();
        getWindow().getDecorView().setBackgroundColor(Theme.bg());
    }

    /** All the picture knobs in one place, so the top-level menu does not
     *  carry five separate rows for them. */
    private void showDisplayMenu() {
        if (loop != null) loop.setPaused(true);
        String[] labels = {
                "画面滤镜：" + FILTER_LABELS[screen.getFilter()],
                "亮度：" + brightnessText(),
                (screen.isSmoothing() ? "关闭" : "开启") + "画面平滑",
                "画面缩放：" + scaleText(),
                "画面边框：" + bezelText()
        };
        new android.app.AlertDialog.Builder(this, R.style.DialogTheme)
                .setTitle("画面")
                .setItems(labels, (d, which) -> {
                    switch (which) {
                        case 0: showFilterMenu(); break;
                        case 1: showBrightnessMenu(); break;
                        case 2:
                            screen.setSmoothing(!screen.isSmoothing());
                            getSharedPreferences("wavegba", MODE_PRIVATE)
                                    .edit()
                                    .putBoolean("smoothing", screen.isSmoothing())
                                    .apply();
                            // Redraw now: with the loop paused the next frame
                            // would not arrive until it resumed, so the change
                            // would look like it had not taken effect.
                            screen.invalidate();
                            toast(screen.isSmoothing() ? "画面平滑：开" : "画面平滑：关");
                            if (loop != null) loop.setPaused(false);
                            break;
                        case 3: showScaleMenu(); break;
                        case 4: showBezelMenu(); break;
                    }
                })
                .setOnCancelListener(d -> { if (loop != null) loop.setPaused(false); })
                .show();
    }

    private void showSpeedMenu() {
        int cur = 1;
        double s = loop != null ? loop.getSpeed() : 1.0;
        for (int i = 0; i < SPEEDS.length; i++) if (Math.abs(SPEEDS[i] - s) < 0.01) cur = i;

        new android.app.AlertDialog.Builder(this, R.style.DialogTheme)
                .setTitle("选择倍速")
                .setSingleChoiceItems(SPEED_LABELS, cur, (d, which) -> {
                    applySpeed(SPEEDS[which]);
                    d.dismiss();
                    if (loop != null) loop.setPaused(false);
                })
                .setOnCancelListener(d -> { if (loop != null) loop.setPaused(false); })
                .show();
    }

    /* ---------------------------------------------------- 截图与画面滤镜 */

    /** Where screenshots go: <external>/WaveGBA/Screenshots. */
    private File shotsDir() {
        File d = (saveDir != null)
                ? new File(saveDir.getParentFile(), "Screenshots")
                : new File(android.os.Environment.getExternalStorageDirectory(),
                           "WaveGBA/Screenshots");
        ensureDir(d);
        return d;
    }

    private File videosDir() {
        File d = (saveDir != null)
                ? new File(saveDir.getParentFile(), "Videos")
                : new File(android.os.Environment.getExternalStorageDirectory(),
                           "WaveGBA/Videos");
        ensureDir(d);
        return d;
    }

    /** Start/stop recording the screen to an MJPEG AVI.
     *
     *  State test is isRecording(), which covers both the MP4 and the AVI
     *  writer. Checking `recorder` alone looked correct but silently excluded
     *  the MP4 path, so the menu never offered "stop" and pressing it again
     *  started a second encoder over the first one -- leaking the original
     *  and leaving an unterminated file on disk. */
    /** Ask whether this recording should carry sound.
     *
     *  Not a permanent setting: a clip meant for sharing wants audio, a long
     *  one meant for reference does not -- and audio roughly doubles the file.
     *  The last choice is remembered as the default for the next one. */
    private void showRecordMenu() {
        if (loop != null) loop.setPaused(true);
        boolean withAudio = getSharedPreferences("wavegba", MODE_PRIVATE)
                .getBoolean("record_audio", true);
        String[] labels = {
                "录制（含声音）",
                "录制（无声，文件更小）"
        };
        new android.app.AlertDialog.Builder(this, R.style.DialogTheme)
                .setTitle("屏幕录制")
                .setSingleChoiceItems(labels, withAudio ? 0 : 1, (d, which) -> {
                    boolean wa = which == 0;
                    getSharedPreferences("wavegba", MODE_PRIVATE)
                            .edit().putBoolean("record_audio", wa).apply();
                    d.dismiss();
                    startRecording(wa);
                    if (loop != null) loop.setPaused(false);
                })
                .setOnCancelListener(d -> { if (loop != null) loop.setPaused(false); })
                .show();
    }

    private void toggleRecording() {
        if (isRecording()) {
            stopVideo();
            return;
        }
        startRecording(getSharedPreferences("wavegba", MODE_PRIVATE)
                .getBoolean("record_audio", true));
    }

    private void startRecording(final boolean withAudio) {
        Bitmap probe = screen.capture();
        if (probe == null) { toast("画面还没准备好"); return; }
        int w = probe.getWidth(), h = probe.getHeight();
        probe.recycle();

        String stamp = new java.text.SimpleDateFormat("yyyyMMdd-HHmmss",
                java.util.Locale.US).format(new java.util.Date());

        // Prefer a real MP4 (H.264 via MediaCodec + MediaMuxer). It is reached
        // by reflection because this build's android.jar predates both. If the
        // device refuses, fall back to the MJPEG/AVI writer so recording still
        // works rather than failing outright.
        recordHasAudio = false;
        File out = new File(videosDir(), safeName(currentRomName) + "-" + stamp + ".mp4");
        try {
            mp4 = new Mp4Recorder(out, w, h, RECORD_FPS, withAudio,
                    NativeBridge.SAMPLE_RATE, 2);
            recordHasAudio = mp4.hasAudio();
            if (withAudio && !recordHasAudio) {
                // The encoder refused AAC. Say so now rather than letting the
                // user discover it when they play the file back.
                toast("该设备不支持 AAC，本次录制无声音");
            }
        } catch (Throwable t) {
            Log.w(TAG, "MP4 不可用，回退 AVI", t);
            mp4 = null;
            out = new File(videosDir(), safeName(currentRomName) + "-" + stamp + ".avi");
            try {
                recorder = new VideoRecorder(out, w, h, RECORD_FPS);
                if (withAudio) toast("AVI 回退模式不支持录音，本次无声音");
            } catch (Throwable t2) {
                Log.e(TAG, "录屏初始化失败", t2);
                toast("无法开始录制");
                return;
            }
        }

        // Feed the core's PCM straight into the muxer. Registered only while
        // recording, and cleared on stop, so nothing is copied when idle.
        if (recordHasAudio && audio != null) {
            audio.setPcmSink(new AudioPlayer.PcmSink() {
                public void onPcm(short[] pcm, int frames) {
                    if (mp4 != null) mp4.addAudio(pcm, frames);
                }
            });
        }
        // The emulation runs at ~60fps; recording at 30 keeps the file half
        // the size and the encoding cost off the hot path.
        recordSkip = 1;
        recordTick = 0;
        if (loop != null) {
            loop.setFrameSink(new EmulatorThread.FrameSink() {
                public void onFrameDrawn() { recordTick(); }
            });
        }
        recordStartMs = System.currentTimeMillis();
        toast("开始录制 " + w + "x" + h + " " + RECORD_FPS + "fps "
                + (mp4 != null ? "MP4" : "AVI"));
    }

    /** True while either writer is open. */
    private boolean isRecording() { return recorder != null || mp4 != null; }

    /** Whether audio is actually going into the file being written. */
    private boolean recordHasAudio = false;

    /** Elapsed time as m:ss, shown on the menu item so a long recording is
     *  visibly still running rather than looking like a stale entry. */
    private String recordElapsed() {
        long ms = System.currentTimeMillis() - recordStartMs;
        long sec = Math.max(0, ms / 1000);
        return (sec / 60) + ":" + String.format("%02d", sec % 60);
    }

    private void stopVideo() {
        if (!isRecording()) return;
        File f;
        if (mp4 != null) {
            f = mp4.file();
            try { mp4.close(); } catch (Throwable t) { Log.e(TAG, "MP4 收尾失败", t); }
            mp4 = null;
        } else {
            f = recorder.file();
            try { recorder.close(); } catch (Throwable t) { Log.e(TAG, "AVI 收尾失败", t); }
            recorder = null;
        }
        if (loop != null) loop.setFrameSink(null);
        if (audio != null) audio.setPcmSink(null);
        toast("已录制：" + f.getName() + "  " + (f.length() / 1024) + "KB"
                + (recordHasAudio ? "（含声音）" : ""));
        try {
            sendBroadcast(new android.content.Intent(
                    "android.intent.action.MEDIA_SCANNER_SCAN_FILE",
                    android.net.Uri.fromFile(f)));
        } catch (Throwable t2) {
            Log.w(TAG, "媒体扫描失败", t2);
        }
    }

    /** Bitmap -> JPEG. The AVI holds Motion-JPEG, so each frame is an
     *  independent JPEG; no inter-frame prediction, which keeps the writer
     *  trivial and the file seekable. */
    private static byte[] encodeJpeg(android.graphics.Bitmap bmp) {
        java.io.ByteArrayOutputStream os = new java.io.ByteArrayOutputStream();
        bmp.compress(android.graphics.Bitmap.CompressFormat.JPEG, 80, os);
        return os.toByteArray();
    }

    /** Encode one frame. Runs on the emulation thread, so it must never throw
     *  and must stay cheap -- a failure here would kill the game loop. */
    private void recordTick() {
        if (recorder == null && mp4 == null) return;
        if (recordTick++ % (recordSkip + 1) != 0) return;
        Bitmap bmp = screen.capture();
        if (bmp == null) return;
        try {
            if (mp4 != null) mp4.addFrame(bmp);
            else recorder.writeFrame(encodeJpeg(bmp));
        } catch (Throwable t) {
            Log.e(TAG, "写帧失败", t);
        }
        bmp.recycle();
    }

    private static String safeName(String s) {
        if (s == null) return "rom";
        String t = s.trim().replaceAll("[^A-Za-z0-9_.-]", "_");
        return t.isEmpty() ? "rom" : t;
    }

    /* ---------------------------------------------------- 功能：存档导出 */

    /** Bundle this game's battery save plus all ten state slots into a zip
     *  and hand it to the system share sheet.
     *
     *  Files are named by ROM id, not by display name, so an imported bundle
     *  lands on the right game even if the player renamed it. */
    private void exportSaves() {
        if (saveDir == null || currentRomName == null) { toast("还没有载入游戏"); return; }

        // +2: the .sav plus ten slots plus the quick slot.
        String[] names = new String[SLOT_COUNT + 2];
        names[0] = currentRomName + ".sav";
        for (int i = 0; i < SLOT_COUNT; i++) names[i + 1] = currentRomName + ".state" + i;
        names[SLOT_COUNT + 1] = currentRomName + ".state" + QUICK_SLOT;

        java.util.ArrayList<File> found = new java.util.ArrayList<>();
        for (String n : names) {
            File f = new File(saveDir, n);
            if (f.exists() && f.length() > 0) found.add(f);
        }
        if (found.isEmpty()) { toast("还没有可导出的存档"); return; }

        // Flush first, otherwise the .sav is only in memory.
        try { flushBattery(); } catch (Throwable ignored) { }

        String stamp = new java.text.SimpleDateFormat("yyyyMMdd-HHmmss",
                java.util.Locale.US).format(new java.util.Date());
        File out = new File(videosDir().getParentFile(),
                safeName(currentRomName) + "-存档-" + stamp + ".zip");

        try {
            java.io.FileOutputStream fos = new java.io.FileOutputStream(out);
            java.util.zip.ZipOutputStream zos =
                    new java.util.zip.ZipOutputStream(fos);
            byte[] buf = new byte[1 << 16];
            for (File f : found) {
                zos.putNextEntry(new java.util.zip.ZipEntry(f.getName()));
                java.io.FileInputStream in = new java.io.FileInputStream(f);
                int n;
                while ((n = in.read(buf)) > 0) zos.write(buf, 0, n);
                in.close();
                zos.closeEntry();
            }
            // Remember which game this belongs to: the file name alone is not
            // enough once the player has renamed the entry.
            zos.putNextEntry(new java.util.zip.ZipEntry("rom.id"));
            byte[] id = (currentRomName + "\n" + romDisplayName).getBytes("UTF-8");
            zos.write(id, 0, id.length);
            zos.closeEntry();
            zos.close();
        } catch (Throwable t) {
            Log.e(TAG, "导出存档失败", t);
            toast("导出失败");
            return;
        }

        try {
            android.content.Intent i = new android.content.Intent(
                    android.content.Intent.ACTION_SEND);
            i.setType("application/zip");
            i.putExtra(android.content.Intent.EXTRA_STREAM,
                    android.net.Uri.fromFile(out));
            i.putExtra(android.content.Intent.EXTRA_SUBJECT,
                    romDisplayName + " 存档");
            startActivity(android.content.Intent.createChooser(i, "导出存档到"));
        } catch (Throwable t) {
            Log.w(TAG, "无法打开分享", t);
            toast("已导出到 " + out.getName());
        }
    }

    private static final int REQ_IMPORT_SAVE = 1007;

    private void importSaves() {
        if (saveDir == null) { toast("存档目录未就绪"); return; }
        try {
            android.content.Intent i = new android.content.Intent(
                    android.content.Intent.ACTION_GET_CONTENT);
            i.setType("application/zip");
            i.addCategory(android.content.Intent.CATEGORY_OPENABLE);
            startActivityForResult(i, REQ_IMPORT_SAVE);
        } catch (Throwable t) {
            Log.w(TAG, "无法打开文件选择器", t);
            toast("无法打开文件选择器");
        }
    }

    /** Unpack a bundle exported from either this device or another one. */
    private void applyImportedSave(android.net.Uri uri) {
        int copied = 0;
        java.io.InputStream in = null;
        java.util.zip.ZipInputStream zis = null;
        try {
            in = getContentResolver().openInputStream(uri);
            if (in == null) { toast("无法读取该文件"); return; }
            zis = new java.util.zip.ZipInputStream(in);
            byte[] buf = new byte[1 << 16];
            java.util.zip.ZipEntry e;
            while ((e = zis.getNextEntry()) != null) {
                String n = e.getName();
                if (n == null || n.contains("/") || n.contains("..")) continue;
                if (!n.endsWith(".sav") && !n.endsWith(".state0")
                        && !n.endsWith(".state1") && !n.endsWith(".state2")
                        && !n.endsWith(".state3") && !n.endsWith(".state4")
                        && !n.endsWith(".state5") && !n.endsWith(".state6")
                        && !n.endsWith(".state7") && !n.endsWith(".state8")
                        && !n.endsWith(".state9")) continue;
                File dst = new File(saveDir, n);
                java.io.FileOutputStream out = new java.io.FileOutputStream(dst);
                int k;
                while ((k = zis.read(buf)) > 0) out.write(buf, 0, k);
                out.close();
                copied++;
            }
        } catch (Throwable t) {
            Log.e(TAG, "导入存档失败", t);
            toast("导入失败");
            return;
        } finally {
            try { if (zis != null) zis.close(); } catch (Throwable ignored) { }
        }

        if (copied == 0) { toast("这个压缩包里没有 GBA 存档"); return; }

        // A .sav that arrived needs to be re-read by the core.
        try { NativeBridge.nativeLoadBattery(); } catch (Throwable ignored) { }
        toast("已导入 " + copied + " 个存档，重启游戏后生效");
    }

    /** Grab the current frame and write it as a PNG. */
    private void takeScreenshot() {
        Bitmap bmp = screen.capture();
        if (bmp == null) { toast("画面还没准备好"); return; }

        String stamp = new java.text.SimpleDateFormat("yyyyMMdd-HHmmss",
                java.util.Locale.US).format(new java.util.Date());
        File out = new File(shotsDir(), currentRomName + "-" + stamp + ".png");

        boolean ok = false;
        try (java.io.FileOutputStream fos = new java.io.FileOutputStream(out)) {
            bmp.compress(Bitmap.CompressFormat.PNG, 100, fos);
            fos.flush();
            ok = out.exists() && out.length() > 0;
        } catch (Throwable t) {
            Log.e(TAG, "截图失败", t);
        }
        bmp.recycle();

        if (!ok) { toast("截图失败：无法写入存储"); return; }

        // Let the gallery pick it up right away instead of after a reboot.
        try {
            sendBroadcast(new Intent(Intent.ACTION_MEDIA_SCANNER_SCAN_FILE,
                    android.net.Uri.fromFile(out)));
        } catch (Throwable t) {
            Log.w(TAG, "媒体扫描失败", t);
        }
        toast("已截图：" + out.getName());
    }

    /* --------------------------------------------- 功能：按键布局编辑器 --- */

    /** Layouts are stored per orientation: a portrait arrangement is useless
     *  in landscape, so each keeps its own copy. */
    private String padLayoutPref() {
        return "pad_layout_" + (pad != null && pad.isPortrait() ? "p" : "l");
    }

    private void savePadLayout(String json) {
        getSharedPreferences("wavegba", MODE_PRIVATE).edit()
                .putString(padLayoutPref(), json).apply();
    }

    private void applyPadLayout() {
        if (pad == null) return;
        String saved = getSharedPreferences("wavegba", MODE_PRIVATE)
                .getString(padLayoutPref(), null);
        if (saved != null) pad.setCustomLayout(saved);
        float sc = getSharedPreferences("wavegba", MODE_PRIVATE)
                .getFloat("pad_scale", 1.0f);
        float al = getSharedPreferences("wavegba", MODE_PRIVATE)
                .getFloat("pad_alpha", 1.0f);
        if (sc != 1.0f) pad.setUserScale(sc);
        if (al != 1.0f) pad.setUserAlpha(al);
    }

    /* ---------------------------------------------------- 功能：画面缩放 -- */

    private static final String[] SCALE_LABELS = {
            "适应屏幕（保持 3:2，两侧或上下留黑边）",
            "整数缩放（像素完美，黑边更大）",
            "拉伸铺满（填满整屏，画面会被拉变形）"
    };

    private String scaleText() {
        switch (screen.getScaleMode()) {
            case EmulatorView.SCALE_INTEGER: {
                int k = screen.getLastIntegerScale();
                return "整数缩放" + (k > 0 ? " " + k + "x" : "");
            }
            case EmulatorView.SCALE_STRETCH:
                return "拉伸铺满";
            default:
                return "适应屏幕";
        }
    }

    private void showScaleMenu() {
        if (loop != null) loop.setPaused(true);
        int cur = screen.getScaleMode();
        new android.app.AlertDialog.Builder(this, R.style.DialogTheme)
                .setTitle("画面缩放")
                .setSingleChoiceItems(SCALE_LABELS, cur, (d, which) -> {
                    screen.setScaleMode(which);
                    getSharedPreferences("wavegba", MODE_PRIVATE)
                            .edit().putInt("scale_mode", which).apply();
                    screen.invalidate();
                    d.dismiss();
                    if (which == EmulatorView.SCALE_INTEGER && screen.isSmoothing()) {
                        // Smoothing interpolates between pixels, which undoes
                        // exactly what integer scaling is for. Tell the player
                        // rather than silently overriding their setting.
                        toast("整数缩放已开启；建议同时关闭画面平滑");
                    } else {
                        toast(SCALE_SHORT[which]);
                    }
                    if (loop != null) loop.setPaused(false);
                })
                .setOnCancelListener(d -> { if (loop != null) loop.setPaused(false); })
                .show();
    }


    private static final String[] SCALE_SHORT = {"适应屏幕", "整数缩放", "拉伸铺满"};

    /* ------------------------------------------------------ 画面边框 --- */

    private static final String[] BEZEL_LABELS = {
            "关闭（纯黑边）",
            "GBA 机身（掌机外壳）",
            "渐变（柔和暗角）"
    };

    private String bezelText() {
        switch (screen.getBezel()) {
            case EmulatorView.BEZEL_GBA:      return "GBA 机身";
            case EmulatorView.BEZEL_GRADIENT: return "渐变";
            default:                          return "关闭";
        }
    }

    private void showBezelMenu() {
        if (loop != null) loop.setPaused(true);
        int cur = screen.getBezel();
        new android.app.AlertDialog.Builder(this, R.style.DialogTheme)
                .setTitle("画面边框")
                .setSingleChoiceItems(BEZEL_LABELS, cur, (d, which) -> {
                    screen.setBezel(which);
                    getSharedPreferences("wavegba", MODE_PRIVATE)
                            .edit().putInt("bezel", which).apply();
                    screen.invalidate();
                    d.dismiss();
                    // Worth saying out loud: stretch leaves no surround at
                    // all, so picking a bezel there looks like it did nothing.
                    if (which != EmulatorView.BEZEL_NONE
                            && screen.getScaleMode() == EmulatorView.SCALE_STRETCH) {
                        toast("边框已设置，但拉伸铺满没有留边，看不到边框");
                    } else {
                        toast("画面边框：" + BEZEL_SHORT[which]);
                    }
                    if (loop != null) loop.setPaused(false);
                })
                .setOnCancelListener(d -> { if (loop != null) loop.setPaused(false); })
                .show();
    }

    private static final String[] BEZEL_SHORT = {"关闭", "GBA 机身", "渐变"};

    /* ------------------------------------------------- 功能：实时时钟 RTC -- */

    /** 0 = auto, 1 = always on, 2 = off. Persisted per device. */
    private int rtcMode = 1;

    private static final String[] RTC_NAMES = {"自动", "始终开启", "关闭"};

    private String rtcModeName() {
        return RTC_NAMES[rtcMode < 0 || rtcMode > 2 ? 1 : rtcMode];
    }

    /** Games with an RTC chip (Pokémon R/S/E, Bokujou Monogatari, ...) read
     *  the wall clock for date-based events. The core only supplies it when
     *  its "vbanext_rtc" option allows, and "auto" means "only for ROMs in
     *  the core's own table" -- which covers very few games, so most games
     *  that need a clock never got one. */
    private void showRtcMenu() {
        if (loop != null) loop.setPaused(true);
        final int[] modes = {0, 1, 2};
        String[] labels = new String[3];
        for (int i = 0; i < 3; i++) {
            labels[i] = RTC_NAMES[i]
                    + (i == 0 ? "（按游戏自动判断）"
                     : i == 1 ? "（推荐，无 RTC 的游戏不受影响）"
                              : "（关闭时钟）");
        }
        new android.app.AlertDialog.Builder(this, R.style.DialogTheme)
                .setTitle("实时时钟（RTC）")
                .setSingleChoiceItems(labels, rtcMode, (d, which) -> {
                    rtcMode = modes[which];
                    getSharedPreferences("wavegba", MODE_PRIVATE)
                            .edit().putInt("rtc_mode", rtcMode).apply();
                    try { NativeBridge.nativeSetRtcMode(rtcMode); }
                    catch (Throwable t) { Log.w(TAG, "设置 RTC 失败", t); }
                    toast("实时时钟：" + rtcModeName());
                    d.dismiss();
                    if (loop != null) loop.setPaused(false);
                })
                .setOnCancelListener(d -> { if (loop != null) loop.setPaused(false); })
                .show();
    }

    private void showLayoutMenu() {
        if (loop != null) loop.setPaused(true);
        boolean editing = pad != null && pad.isEditMode();
        String[] items = {
                editing ? "✓ 退出编辑（保存）" : "进入编辑（拖动按键）",
                "按键大小：" + Math.round((pad != null ? pad.getUserScale() : 1f) * 100) + "%",
                "按键透明度：" + Math.round((pad != null ? pad.getUserAlpha() : 1f) * 100) + "%",
                "恢复默认布局"
        };
        new android.app.AlertDialog.Builder(this, R.style.DialogTheme)
                .setTitle("按键布局")
                .setItems(items, (d, which) -> {
                    switch (which) {
                        case 0:
                            boolean nowEditing = !editing;
                            pad.setEditMode(nowEditing);
                            if (!nowEditing && pad != null) {
                                savePadLayout(pad.exportLayout());
                                toast("布局已保存");
                            } else {
                                toast("拖动按键调整位置，再点一次保存");
                            }
                            break;
                        case 1: showPadScaleMenu(); return;
                        case 2: showPadAlphaMenu(); return;
                        case 3:
                            pad.resetLayout();
                            getSharedPreferences("wavegba", MODE_PRIVATE).edit()
                                    .remove(padLayoutPref())
                                    .putFloat("pad_scale", 1.0f)
                                    .putFloat("pad_alpha", 1.0f).apply();
                            toast("已恢复默认布局");
                            break;
                    }
                    if (loop != null) loop.setPaused(false);
                })
                .setOnCancelListener(d -> { if (loop != null) loop.setPaused(false); })
                .show();
    }

    private void showPadScaleMenu() {
        String[] labels = {"60%", "75%", "90%", "100%", "115%", "130%", "150%", "180%"};
        float[] values = {0.60f, 0.75f, 0.90f, 1.0f, 1.15f, 1.30f, 1.50f, 1.80f};
        int cur = 3;
        float s0 = pad.getUserScale();
        for (int i = 0; i < values.length; i++) {
            if (Math.abs(values[i] - s0) < 0.01f) { cur = i; break; }
        }
        new android.app.AlertDialog.Builder(this, R.style.DialogTheme)
                .setTitle("按键大小")
                .setSingleChoiceItems(labels, cur, (d, which) -> {
                    pad.setUserScale(values[which]);
                    getSharedPreferences("wavegba", MODE_PRIVATE).edit()
                            .putFloat("pad_scale", values[which]).apply();
                    if (pad.isEditMode()) savePadLayout(pad.exportLayout());
                    toast("按键大小：" + labels[which]);
                    d.dismiss();
                    if (loop != null) loop.setPaused(false);
                })
                .setOnCancelListener(d -> { if (loop != null) loop.setPaused(false); })
                .show();
    }

    private void showPadAlphaMenu() {
        String[] labels = {"25%", "40%", "55%", "70%", "85%", "100%"};
        float[] values = {0.25f, 0.40f, 0.55f, 0.70f, 0.85f, 1.0f};
        int cur = 5;
        float a0 = pad.getUserAlpha();
        for (int i = 0; i < values.length; i++) {
            if (Math.abs(values[i] - a0) < 0.01f) { cur = i; break; }
        }
        new android.app.AlertDialog.Builder(this, R.style.DialogTheme)
                .setTitle("按键透明度")
                .setSingleChoiceItems(labels, cur, (d, which) -> {
                    pad.setUserAlpha(values[which]);
                    getSharedPreferences("wavegba", MODE_PRIVATE).edit()
                            .putFloat("pad_alpha", values[which]).apply();
                    toast("透明度：" + labels[which]);
                    d.dismiss();
                    if (loop != null) loop.setPaused(false);
                })
                .setOnCancelListener(d -> { if (loop != null) loop.setPaused(false); })
                .show();
    }

    private void showFilterMenu() {
        if (loop != null) loop.setPaused(true);
        new android.app.AlertDialog.Builder(this, R.style.DialogTheme)
                .setTitle("画面滤镜")
                .setSingleChoiceItems(FILTER_LABELS, screen.getFilter(), (d, which) -> {
                    screen.setFilter(which);
                    getSharedPreferences("wavegba", MODE_PRIVATE)
                            .edit().putInt("filter", which).apply();
                    screen.invalidate();
                    d.dismiss();
                    toast("滤镜：" + FILTER_LABELS[which]);
                    if (loop != null) loop.setPaused(false);
                })
                .setOnCancelListener(d -> { if (loop != null) loop.setPaused(false); })
                .show();
    }

    private String brightnessText() {
        float b = screen.getBrightness();
        return Math.round(b * 100) + "%";
    }

    private void showBrightnessMenu() {
        if (loop != null) loop.setPaused(true);
        int cur = 2;
        float b = screen.getBrightness();
        for (int i = 0; i < BRIGHTNESS.length; i++)
            if (Math.abs(BRIGHTNESS[i] - b) < 0.01f) cur = i;

        new android.app.AlertDialog.Builder(this, R.style.DialogTheme)
                .setTitle("画面亮度")
                .setSingleChoiceItems(BRIGHTNESS_LABELS, cur, (d, which) -> {
                    screen.setBrightness(BRIGHTNESS[which]);
                    getSharedPreferences("wavegba", MODE_PRIVATE)
                            .edit().putFloat("brightness", BRIGHTNESS[which]).apply();
                    screen.invalidate();
                    d.dismiss();
                    toast("亮度：" + BRIGHTNESS_LABELS[which]);
                    if (loop != null) loop.setPaused(false);
                })
                .setOnCancelListener(d -> { if (loop != null) loop.setPaused(false); })
                .show();
    }

    /* ------------------------------------------------------------- 快进键 */

    /** Speed the fast-forward button toggles to. */
    private static final double FF_SPEED = 4.0;

    /** Tap toggles between the running speed and FF_SPEED, so the button and
     *  the speed menu always agree on what is active. */
    private void applyFastForward(boolean on) {
        if (on) {
            double cur = loop != null ? loop.getSpeed() : 1.0;
            if (cur >= FF_SPEED) {
                // Already at or past fast-forward speed. Dropping to FF_SPEED
                // would make the button slow the game down, which is the
                // opposite of what pressing it means.
                applySpeed(cur, false);
                toast("已在 " + fmtSpeed(cur) + "（不降速）");
            } else {
                savedSpeed = cur;
                applySpeed(FF_SPEED, false);
                toast("快进 " + FF_SPEED + "x（再点一次恢复）");
            }
        } else {
            if (savedSpeed >= FF_SPEED) savedSpeed = 1.0;
            applySpeed(savedSpeed, false);
            toast("已恢复 " + savedSpeed + "x");
        }
    }

    /* --------------------------------------------------------------- 音量 */

    private static final float[] VOLUMES = {0f, 0.25f, 0.5f, 0.75f, 1.0f};
    private static final String[] VOLUME_LABELS = {"静音", "25%", "50%", "75%", "100%"};

    private String volumeText() {
        if (audio == null) return "100%";
        return Math.round(audio.getVolume() * 100) + "%";
    }

    private void showVolumeMenu() {
        if (audio == null) { toast("音频还没启动"); return; }
        float cur = audio.isMuted() ? 0f : audio.getVolume();
        int sel = 4;
        for (int i = 0; i < VOLUMES.length; i++)
            if (Math.abs(VOLUMES[i] - cur) < 0.01f) sel = i;

        if (loop != null) loop.setPaused(true);
        new android.app.AlertDialog.Builder(this, R.style.DialogTheme)
                .setTitle("音量")
                .setSingleChoiceItems(VOLUME_LABELS, sel, (d, which) -> {
                    float v = VOLUMES[which];
                    audio.setVolume(v);
                    audio.setMuted(v == 0f);
                    d.dismiss();
                    toast("音量：" + VOLUME_LABELS[which]);
                    if (loop != null) loop.setPaused(false);
                })
                .setOnCancelListener(d -> { if (loop != null) loop.setPaused(false); })
                .show();
    }

    private void applySpeed(double s) { applySpeed(s, true); }

    private void applySpeed(double s, boolean notify) {
        if (loop != null) loop.setSpeed(s);
        if (audio != null) {
            audio.setSpeed(s);
            // Over the threshold the core cannot deliver a continuous stream,
            // so mute rather than emit fragments. Mute is cleared when the
            // speed comes back down, but only if the player had not muted it
            // themselves with the volume control.
            audio.setMuted(s > AUDIO_MAX_SPEED
                    || getSharedPreferences("wavegba", MODE_PRIVATE)
                            .getBoolean("muted", false));
        }
        if (ffButton != null) ffButton.setActive(s >= FF_SPEED);
        if (!notify) return;
        // No "（已静音）" suffix any more: speed no longer touches audio, so
        // saying otherwise would just be wrong.
        toast("倍速 " + s + "x");
    }

    private static String fmtSpeed(double s) {
        return (Math.abs(s - (long) s) < 0.05)
                ? String.format(java.util.Locale.US, "%.0fx", s)
                : String.format(java.util.Locale.US, "%.1fx", s);
    }

    private String speedText() {
        if (loop == null) return "1.0x";
        double s = loop.getSpeed();
        String base = fmtSpeed(s);

        // Report what is actually being achieved whenever it falls short.
        // Asking for 16x and silently getting 5x would read as the setting
        // being broken, and the shortfall is the CPU, not a bug -- so say so.
        double got = loop.simulatedFps() / EmulatorThread.BASE_FPS;
        String tail = s > AUDIO_MAX_SPEED ? " · 无声" : "";
        if (got <= 0.05) return base + tail;           // not running yet
        if (s > 1.0 && got < s * 0.85) {
            return base + "（实际 " + fmtSpeed(got) + "）" + tail;
        }
        return base + tail;
    }

    private void showAbout() {
        String msg = "WaveGBA  版本 " + APP_VERSION + "\n"
                + "作者：Edag\n\n"
                + "核心：vba-next（优化版）\n"
                + "存档目录：" + (saveDir != null ? saveDir.getAbsolutePath() : "?") + "\n"
                + "游戏：" + romDisplayName + "\n"
                + "存档名：" + currentRomName + "\n"
                + savStatus() + "\n"
                + "目录：" + saveDirLabel()
                + (usingPublicDir() ? "" : "\n（注意：当前为应用私有目录，卸载会丢失）")
                + "\n\n"
                + CHANGELOG
                + "\n运行状态\n"
                + "渲染帧率：" + String.format(java.util.Locale.US, "%.1f", loop != null ? loop.fps() : 0)
                + " fps\n"
                + "等效模拟速度："
                + String.format(java.util.Locale.US, "%.1f", loop != null ? loop.simulatedFps() : 0)
                + " fps";
        new android.app.AlertDialog.Builder(this, R.style.DialogTheme)
                .setTitle("关于")
                .setMessage(msg)
                .setPositiveButton("确定", (d, w) -> { if (loop != null) loop.setPaused(false); })
                .setOnCancelListener(d -> { if (loop != null) loop.setPaused(false); })
                .show();
    }

    /** Snackbar-style notice: a dark rounded capsule docked near the bottom,
     *  with a violet->cyan edge bar. Replaces the stock Toast so transient
     *  messages match the rest of the UI instead of flashing a grey box. */
    private void toast(String msg) {
        runOnUiThread(() -> {
            try {
                android.widget.TextView tv = new android.widget.TextView(this);
                tv.setText(msg);
                tv.setTextColor(0xFFF2F4F7);
                tv.setTextSize(14);
                tv.setTypeface(android.graphics.Typeface.create("sans-serif-medium",
                        android.graphics.Typeface.NORMAL));
                int pad = (int) (16 * getResources().getDisplayMetrics().density);
                int bar = (int) (12 * getResources().getDisplayMetrics().density);
                tv.setPadding(pad + bar, pad, pad, pad);
                tv.setBackgroundResource(com.wavegba.R.drawable.toast_bg);

                Toast t = new Toast(getApplicationContext());
                t.setGravity(android.view.Gravity.BOTTOM | android.view.Gravity.CENTER_HORIZONTAL,
                        0, (int) (96 * getResources().getDisplayMetrics().density));
                t.setDuration(Toast.LENGTH_SHORT);
                t.setView(tv);
                t.show();
            } catch (Throwable e) {
                Log.w(TAG, "自定义提示失败，回退系统 Toast", e);
                Toast.makeText(this, msg, Toast.LENGTH_SHORT).show();
            }
        });
    }

    /** Stamp the library entry and refresh its cover from the last frame. */
    private void commitToLibrary() {
        if (library == null || currentRomName == null) return;
        try {
            library.touch(currentRomName, System.currentTimeMillis());
            Bitmap shot = (screen != null) ? screen.capture() : null;
            if (shot != null) {
                library.saveCover(currentRomName, shot);
                shot.recycle();
            }
        } catch (Throwable t) {
            Log.w(TAG, "更新游戏库失败", t);
        }
    }

    /** onStop fires even when the activity is merely covered, and is the last
     *  reliable callback before the process can be killed. */
    @Override
    protected void onStop() {
        // Finalise any recording: an AVI whose index was never written is
        // unplayable, and the process may be killed before onDestroy.
        if (recorder != null || mp4 != null) stopVideo();
        try { flushBattery(); } catch (Throwable ignored) { }
        stopAutosave();
        super.onStop();
    }

    @Override
    protected void onPause() {
        if (turboHandler != null) turboHandler.removeCallbacks(turboPulse);
        commitToLibrary();
        super.onPause();
        if (loop != null) loop.setPaused(true);
        if (audio != null) {
            getSharedPreferences("wavegba", MODE_PRIVATE).edit()
                    .putFloat("volume", audio.getVolume())
                    .putBoolean("muted", audio.isMuted())
                    .apply();
            audio.setMuted(true);
        }
        flushBattery();
    }

    @Override
    protected void onResume() {
        super.onResume();
        // Restore what onPause saved rather than clearing the flag outright:
        // un-muting unconditionally here meant a player who had set the volume
        // to zero got their audio back every time they returned to the app.
        if (audio != null) {
            audio.setMuted(getSharedPreferences("wavegba", MODE_PRIVATE)
                    .getBoolean("muted", false));
        }
        if (loop != null) loop.setPaused(false);
    }

    @Override
    protected void onDestroy() {
        if (loop != null) loop.stopLoop();
        if (audio != null) audio.stop();
        flushBattery();
        NativeBridge.nativeDestroy();
        super.onDestroy();
    }
}
