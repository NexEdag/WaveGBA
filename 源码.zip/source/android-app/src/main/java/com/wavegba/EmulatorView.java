package com.wavegba;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.ColorMatrix;
import android.graphics.ColorMatrixColorFilter;
import android.graphics.Paint;
import android.graphics.Rect;
import android.util.AttributeSet;
import android.view.View;

/** Scales the 240x160 RGB565 framebuffer up to whatever space it is given,
 *  optionally overlaying an LCD-style filter and applying a brightness trim.
 *
 *  All rendering funnels through renderTo(), so onDraw() and capture() are
 *  guaranteed to produce the same pixels -- a screenshot always matches what
 *  the user was looking at, filter and brightness included. */
public class EmulatorView extends View {

    /** What fills the space around the picture. Only visible when the scale
     *  mode leaves any -- SCALE_STRETCH fills the screen, so it shows none. */
    public static final int BEZEL_NONE    = 0;   /* plain black bars */
    public static final int BEZEL_GBA     = 1;   /* handheld shell */
    public static final int BEZEL_GRADIENT = 2;  /* soft vignette */

    /** How the 3:2 picture is fitted to the viewport. */
    public static final int SCALE_FIT      = 0;   /* letterbox, keep 3:2 */
    public static final int SCALE_INTEGER  = 1;   /* whole-number multiple */
    public static final int SCALE_STRETCH  = 2;   /* fill, ignore 3:2 */

    /** Filter presets offered in the menu. */
    public static final int FILTER_NONE   = 0;
    public static final int FILTER_LCD    = 1;
    public static final int FILTER_SCAN   = 2;

    private final Bitmap framebuffer =
            Bitmap.createBitmap(NativeBridge.SCREEN_W, NativeBridge.SCREEN_H, Bitmap.Config.RGB_565);
    private final Paint paint = new Paint(Paint.FILTER_BITMAP_FLAG);
    private final Paint gridPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint bezelPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint bezelText = new Paint(Paint.ANTI_ALIAS_FLAG);
    /* Cached so the per-frame gradient is not reallocated every draw. */
    private android.graphics.LinearGradient bezelBodyShader;
    private int bezelBodyW, bezelBodyH;
    private final android.graphics.RectF bzShell = new android.graphics.RectF();
    private final android.graphics.RectF bzRecess = new android.graphics.RectF();
    private final android.graphics.RectF bzTmp = new android.graphics.RectF();
    private final Rect src = new Rect(0, 0, NativeBridge.SCREEN_W, NativeBridge.SCREEN_H);
    private final Rect dst = new Rect();

    private boolean smoothing = true;
    private int scaleMode = SCALE_FIT;
    private int bezel = BEZEL_NONE;
    private int filter = FILTER_NONE;
    private float brightness = 1.0f;
    /* Whole-number multiple actually used by the last render, so the menu can
     * show it. 0 unless integer scaling is on or nothing is laid out yet. */
    private int lastIntegerScale = 0;
    private final ColorMatrix cm = new ColorMatrix();

    public EmulatorView(Context c) { super(c); }
    public EmulatorView(Context c, AttributeSet a) { super(c, a); }
    public EmulatorView(Context c, AttributeSet a, int s) { super(c, a, s); }

    public void setSmoothing(boolean on) {
        smoothing = on;
        paint.setFilterBitmap(on);
        paint.setAntiAlias(on);
    }

    public boolean isSmoothing() { return smoothing; }

    /** 0 = fit to the viewport keeping 3:2 (letterboxed), 1 = whole-number
     *  multiple, 2 = stretch to fill, ignoring the aspect ratio. */
    public void setScaleMode(int mode) {
        if (mode < SCALE_FIT) mode = SCALE_FIT;
        if (mode > SCALE_STRETCH) mode = SCALE_STRETCH;
        scaleMode = mode;
        if (mode != SCALE_INTEGER) lastIntegerScale = 0;
    }

    public int getScaleMode() { return scaleMode; }

    /** 0 = black bars, 1 = GBA shell, 2 = gradient. */
    public void setBezel(int mode) {
        if (mode < BEZEL_NONE) mode = BEZEL_NONE;
        if (mode > BEZEL_GRADIENT) mode = BEZEL_GRADIENT;
        bezel = mode;
    }

    public int getBezel() { return bezel; }

    /** Snap the picture to a whole-number multiple of 240x160.
     *
     *  Free scaling picks whatever fills the screen, which leaves GBA pixels
     *  straddling device pixels and softens every edge. At an integer
     *  multiple each source pixel covers an exact square block, so the
     *  picture stays crisp. The trade-off is larger black bars: 6.75x rounds
     *  down to 6x. */
    public void setIntegerScaling(boolean on) {
        setScaleMode(on ? SCALE_INTEGER : SCALE_FIT);
    }

    public boolean isIntegerScaling() { return scaleMode == SCALE_INTEGER; }

    /** The whole-number multiple in use, or 0 unless integer scaling is on
     *  and a frame has been laid out. */
    public int getLastIntegerScale() { return lastIntegerScale; }

    public int getFilter() { return filter; }

    public void setFilter(int f) { filter = f; }

    /** 0.5 (dark) .. 1.5 (bright). 1.0 is untouched. */
    public float getBrightness() { return brightness; }

    public void setBrightness(float b) {
        brightness = Math.max(0.5f, Math.min(1.5f, b));
        // A scale-only matrix is cheaper than a LightingColorFilter and keeps
        // the black level at black.
        cm.set(new float[]{
                brightness, 0, 0, 0, 0,
                0, brightness, 0, 0, 0,
                0, 0, brightness, 0, 0,
                0, 0, 0, 1, 0});
        paint.setColorFilter(new ColorMatrixColorFilter(cm));
    }

    /** Called from the emulation thread. */
    public void pullFrame() {
        NativeBridge.nativeRender(framebuffer);
        if (isFadingIn()) setAlphaCompat(fadeProgress());
        postInvalidate();
    }

    /** Fade the picture in over the first frames after a game starts.
     *
     *  Without this the emulator window snaps straight from the library to a
     *  fully lit frame, which reads as a jump cut. The fade is driven from
     *  real elapsed time rather than a frame count, so it lasts the same
     *  duration whatever the device is managing.
     *
     *  Alpha is applied to the picture only -- the letterbox keeps the theme
     *  background at full strength, so the screen does not appear to fade up
     *  from white. */
    private static final long FADE_MS = 260L;
    private long fadeStartMs = 0L;

    /** Call once the core has loaded, before the first frame is pulled. */
    public void beginFadeIn() {
        fadeStartMs = android.os.SystemClock.uptimeMillis();
        setAlphaCompat(0f);
    }

    /** 0..1 progress of the intro fade; 1 once it is finished. */
    private float fadeProgress() {
        if (fadeStartMs == 0L) return 1f;
        float t = (android.os.SystemClock.uptimeMillis() - fadeStartMs)
                / (float) FADE_MS;
        if (t >= 1f) { fadeStartMs = 0L; return 1f; }
        return t;
    }

    private void setAlphaCompat(float a) {
        // View.setAlpha() needs API 11 and hardware acceleration; minSdk is
        // 23 so the method itself is fine, but it is skipped entirely once
        // the fade has settled so drawing stays on the fast path.
        setAlpha(a);
    }

    /** True while the intro fade is still running, i.e. while continuous
     *  redraws are needed to animate it. */
    public boolean isFadingIn() { return fadeStartMs != 0L; }

    /** Repaint with the current theme's background. The picture itself is
     *  untouched -- only the letterbox area around it takes the theme colour. */
    public void applyTheme() {
        setBackgroundColor(Theme.bg());
        invalidate();
    }

    @Override
    protected void onDraw(Canvas canvas) {
        renderTo(canvas, getWidth(), getHeight());
    }

    /** Draw the frame, letterboxed to the GBA's 3:2 aspect, with the active
     *  filter and brightness applied. Shared by onDraw() and capture(). */
    private void renderTo(Canvas canvas, int vw, int vh) {
        if (vw <= 0 || vh <= 0) return;

        int w, h, left, top;
        float scale;                       // only used by the filter overlay

        if (scaleMode == SCALE_STRETCH) {
            // Stretch to the viewport: scale each axis independently, so the
            // picture fills the screen with no bars at all. The GBA is 3:2
            // and phones are not, so this visibly distorts the image -- that
            // is the entire point of the option.
            w = vw; h = vh; left = 0; top = 0;
            dst.set(0, 0, vw, vh);
            scale = Math.min(vw / (float) NativeBridge.SCREEN_W,
                             vh / (float) NativeBridge.SCREEN_H);
            lastIntegerScale = 0;
        } else {
            float raw = Math.min(vw / (float) NativeBridge.SCREEN_W,
                                 vh / (float) NativeBridge.SCREEN_H);
            if (scaleMode == SCALE_INTEGER) {
                // Floor, never ceil: exceeding the viewport would crop rows
                // and columns off the picture, which is far worse than a
                // thinner image. A screen smaller than 240x160 clamps to 1x.
                int k = (int) raw;
                if (k < 1) k = 1;
                scale = k;
                lastIntegerScale = k;
            } else {
                scale = raw;
                lastIntegerScale = 0;
            }
            w = Math.round(NativeBridge.SCREEN_W * scale);
            h = Math.round(NativeBridge.SCREEN_H * scale);
            left = (vw - w) / 2;
            top  = (vh - h) / 2;
            dst.set(left, top, left + w, top + h);
        }

        // Bezel first: it covers the whole viewport, and the picture is drawn
        // on top of it. Drawing it afterwards would paint over the game.
        drawBezel(canvas, vw, vh, dst);

        canvas.drawBitmap(framebuffer, src, dst, paint);
        drawFilter(canvas, dst, scale);
    }

    /** Fill the area around the picture.
     *
     *  Nothing here may touch `dst`: the shell has to leave the picture
     *  itself alone. Everything is clipped to the outside of the picture by
     *  drawing the surround first and letting the bitmap overwrite the middle.
     */
    private void drawBezel(Canvas c, int vw, int vh, Rect area) {
        if (bezel == BEZEL_NONE) return;

        if (bezel == BEZEL_GRADIENT) {
            // Radial vignette: bright behind the picture, falling off to the
            // edges, so the bars read as part of the image rather than as
            // two dead strips.
            float cx = vw / 2f, cy = vh / 2f;
            float r = Math.max(vw, vh) * 0.75f;
            android.graphics.RadialGradient g = new android.graphics.RadialGradient(
                    cx, cy, r, 0xFF1A1A22, 0xFF050507,
                    android.graphics.Shader.TileMode.CLAMP);
            bezelPaint.setShader(g);
            bezelPaint.setStyle(Paint.Style.FILL);
            c.drawRect(0, 0, vw, vh, bezelPaint);
            bezelPaint.setShader(null);
            return;
        }

        // BEZEL_GBA: the whole viewport becomes the handheld, with the picture
        // sunk into a recess in the middle.
        //
        // Sizing the shell off the picture (as the first attempt did) left the
        // rest of the screen black, so it read as a frame around the game
        // rather than as a machine holding it. Filling the viewport is what
        // makes the phone screen read as the console.
        float radius = Math.min(vw, vh) * 0.05f;
        if (bezelBodyShader == null || bezelBodyW != vw || bezelBodyH != vh) {
            // Rebuilt only when the size changes: this runs every frame.
            bezelBodyShader = new android.graphics.LinearGradient(
                    0, 0, 0, vh, 0xFF6A6580, 0xFF282630,
                    android.graphics.Shader.TileMode.CLAMP);
            bezelBodyW = vw;
            bezelBodyH = vh;
        }
        bzShell.set(0, 0, vw, vh);
        bezelPaint.setShader(bezelBodyShader);
        bezelPaint.setStyle(Paint.Style.FILL);
        c.drawRoundRect(bzShell, radius, radius, bezelPaint);
        bezelPaint.setShader(null);

        // Highlight along the top edge: reads as moulded plastic catching
        // light. Without it the shell looks like a flat colour field.
        bezelPaint.setStyle(Paint.Style.STROKE);
        bezelPaint.setStrokeWidth(Math.max(1.5f, 2f * d()));
        bezelPaint.setColor(0x30FFFFFF);
        c.drawLine(radius, 1.5f, vw - radius, 1.5f, bezelPaint);

        // Screen recess: a near-black rounded well around the picture. The
        // game bitmap is drawn on top afterwards, so what stays visible is
        // the lip of the well -- which is what sells "sunk into the case".
        int gp = Math.max(6, Math.round(Math.min(vw, vh) * 0.016f));
        bzRecess.set(area.left - gp, area.top - gp, area.right + gp, area.bottom + gp);
        float rr = gp * 1.6f;
        bezelPaint.setStyle(Paint.Style.FILL);
        bezelPaint.setColor(0xFF06060A);
        c.drawRoundRect(bzRecess, rr, rr, bezelPaint);

        // Shadow on the top/left lips, highlight on the bottom/right: the
        // standard trick that makes a flat rectangle read as a recess.
        bezelPaint.setStyle(Paint.Style.STROKE);
        bezelPaint.setStrokeWidth(Math.max(2f, gp * 0.4f));
        bezelPaint.setColor(0xB0000000);
        c.drawRoundRect(bzRecess, rr, rr, bezelPaint);
        bzTmp.set(bzRecess.left + 1, bzRecess.top + 1,
                  bzRecess.right - 1, bzRecess.bottom - 1);
        bezelPaint.setStrokeWidth(Math.max(1f, gp * 0.18f));
        bezelPaint.setColor(0x22FFFFFF);
        c.drawRoundRect(bzTmp, rr, rr, bezelPaint);
        bezelPaint.setStyle(Paint.Style.FILL);

        drawShellDetails(c, vw, vh, area);
    }

    private float d() {
        float v = getResources().getDisplayMetrics().density;
        return v > 0 ? v : 1f;
    }

    /** Buttons, logo, speaker and power light, laid out in whatever space the
     *  recess leaves. Everything is drawn outside the recess, so nothing can
     *  end up on top of the picture. */
    private void drawShellDetails(Canvas c, int vw, int vh, Rect area) {
        float d = d();
        int above = Math.max(0, (int) bzRecess.top);
        int below = Math.max(0, vh - (int) bzRecess.bottom);
        int left  = Math.max(0, (int) bzRecess.left);
        int right = Math.max(0, vw - (int) bzRecess.right);

        // Landscape leaves room beside the screen; portrait leaves it above
        // and below. The console is laid out to match whatever there is.
        boolean wide = (left + right) > (above + below);

        float logoSz = clamp(vw * 0.017f, 8 * d, 17 * d);

        if (wide) {
            if (above >= 26 * d) drawLogo(c, vw / 2f, above * 0.55f, logoSz);

            if (left > 44 * d) {
                float sz = clamp(Math.min(left * 0.62f, vh * 0.26f), 26 * d, 74 * d);
                drawDpad(c, left / 2f, vh / 2f, sz);
                drawPowerLight(c, left / 2f, vh / 2f - sz * 0.95f, sz, d);
            }
            if (right > 60 * d) {
                float sz = clamp(Math.min(right * 0.42f, vh * 0.26f), 26 * d, 74 * d);
                drawAB(c, vw - right * 0.42f, vh / 2f, sz, d);
                drawSpeaker(c, vw - right * 0.30f, vh - Math.max(0, below) * 0.30f - 6 * d,
                        sz, d);
            }
        } else if (below > 78 * d) {
            // Portrait: screen on top, then the logo, then the controls --
            // the same order as the real shell.
            float cy = bzRecess.bottom + below * 0.60f;
            float sz = clamp(Math.min(vw * 0.26f, below * 0.46f), 28 * d, 78 * d);
            drawLogo(c, vw / 2f, bzRecess.bottom + below * 0.17f, logoSz);
            drawDpad(c, vw * 0.27f, cy, sz);
            drawPowerLight(c, vw * 0.27f, cy - sz * 0.95f, sz, d);
            drawAB(c, vw * 0.73f, cy, sz, d);
            drawSpeaker(c, vw * 0.5f, vh - below * 0.12f, sz, d);
        } else if (above >= 26 * d) {
            // Not enough room for controls; at least brand the shell.
            drawLogo(c, vw / 2f, above * 0.55f, logoSz);
        }
    }

    private static float clamp(float v, float lo, float hi) {
        return v < lo ? lo : (v > hi ? hi : v);
    }

    /** "GAME BOY ADVANCE" in tiny tracked-out caps.
     *
     *  On a real shell this is printed just below the screen, so that is
     *  where it goes whenever there is room down there. */
    private void drawLogo(Canvas c, float cx, float cy, float size) {
        bezelText.setTextSize(size);
        bezelText.setColor(0x9A96AC);
        bezelText.setFakeBoldText(true);
        // Letter spacing: drawText has no tracking before API 21, so space
        // the glyphs by hand.
        String s = "GAME BOY ADVANCE";
        float track = size * 0.16f;
        float[] w = new float[s.length()];
        float total = 0;
        for (int i = 0; i < s.length(); i++) {
            w[i] = bezelText.measureText(String.valueOf(s.charAt(i)));
            total += w[i] + track;
        }
        total -= track;
        float x = cx - total / 2f;
        bezelText.setTextAlign(Paint.Align.LEFT);
        for (int i = 0; i < s.length(); i++) {
            c.drawText(String.valueOf(s.charAt(i)), x, cy, bezelText);
            x += w[i] + track;
        }
    }

    /** Cross pad: two overlapping bars plus a centre hub, drawn dark with a
     *  soft top highlight so it reads as moulded rubber. */
    private void drawDpad(Canvas c, float cx, float cy, float size) {
        float arm = size * 0.34f;          // half-width of each bar
        float len = size * 0.5f;           // half-length

        bezelPaint.setStyle(Paint.Style.FILL);
        bezelPaint.setColor(0xFF17151D);
        bzTmp.set(cx - arm, cy - len, cx + arm, cy + len);
        c.drawRoundRect(bzTmp, arm * 0.35f, arm * 0.35f, bezelPaint);
        bzTmp.set(cx - len, cy - arm, cx + len, cy + arm);
        c.drawRoundRect(bzTmp, arm * 0.35f, arm * 0.35f, bezelPaint);

        // Rim highlight on the top-left of each arm.
        bezelPaint.setStyle(Paint.Style.STROKE);
        bezelPaint.setStrokeWidth(Math.max(1f, size * 0.03f));
        bezelPaint.setColor(0x20FFFFFF);
        bzTmp.set(cx - arm, cy - len, cx + arm, cy + len);
        c.drawRoundRect(bzTmp, arm * 0.35f, arm * 0.35f, bezelPaint);
        bzTmp.set(cx - len, cy - arm, cx + len, cy + arm);
        c.drawRoundRect(bzTmp, arm * 0.35f, arm * 0.35f, bezelPaint);

        // Hub: a shallow dimple in the middle.
        bezelPaint.setStyle(Paint.Style.FILL);
        bezelPaint.setColor(0xFF0E0D12);
        c.drawCircle(cx, cy, arm * 0.62f, bezelPaint);
        bezelPaint.setStyle(Paint.Style.STROKE);
        bezelPaint.setColor(0x18FFFFFF);
        c.drawCircle(cx, cy, arm * 0.62f, bezelPaint);
        bezelPaint.setStyle(Paint.Style.FILL);
    }

    /** A and B: two round buttons offset diagonally, labelled underneath the
     *  way the real shell labels them. */
    private void drawAB(Canvas c, float cx, float cy, float size, float d) {
        float r = size * 0.30f;
        float off = size * 0.36f;
        drawRoundButton(c, cx + off * 0.55f, cy - off * 0.55f, r, "A", d);   // upper right
        drawRoundButton(c, cx - off * 0.55f, cy + off * 0.55f, r, "B", d);   // lower left
    }

    private void drawRoundButton(Canvas c, float cx, float cy, float r,
                                 String label, float d) {
        bezelPaint.setStyle(Paint.Style.FILL);
        bezelPaint.setColor(0xFF1B1922);
        c.drawCircle(cx, cy, r, bezelPaint);
        bezelPaint.setStyle(Paint.Style.STROKE);
        bezelPaint.setStrokeWidth(Math.max(1f, r * 0.09f));
        bezelPaint.setColor(0x24FFFFFF);
        c.drawCircle(cx, cy, r * 0.94f, bezelPaint);
        bezelPaint.setStyle(Paint.Style.FILL);

        bezelText.setTextSize(clamp(r * 0.62f, 8 * d, 15 * d));
        bezelText.setColor(0x8F8B9E);
        bezelText.setFakeBoldText(true);
        bezelText.setTextAlign(Paint.Align.CENTER);
        c.drawText(label, cx, cy + r * 1.85f, bezelText);
    }

    /** Six holes on a diagonal, as on the lower-right of the shell. */
    private void drawSpeaker(Canvas c, float cx, float cy, float size, float d) {
        float r = clamp(size * 0.045f, 1.6f * d, 3.2f * d);
        float step = r * 3.0f;
        bezelPaint.setStyle(Paint.Style.FILL);
        bezelPaint.setColor(0x99000000);
        for (int i = 0; i < 6; i++) {
            float x = cx + (i - 2.5f) * step;
            float y = cy + (i - 2.5f) * step * 0.45f;
            c.drawCircle(x, y, r, bezelPaint);
        }
    }

    /** Red power LED with a soft glow. */
    private void drawPowerLight(Canvas c, float cx, float cy, float size, float d) {
        float r = clamp(size * 0.055f, 2f * d, 4f * d);
        bezelPaint.setStyle(Paint.Style.FILL);
        bezelPaint.setColor(0x33FF5566);
        c.drawCircle(cx, cy, r * 2.6f, bezelPaint);
        bezelPaint.setColor(0xFFFF4D5E);
        c.drawCircle(cx, cy, r, bezelPaint);
    }

    /** LCD grid or scanlines, drawn only over the active picture area. */
    private void drawFilter(Canvas c, Rect area, float scale) {
        if (filter == FILTER_NONE) return;

        int w = area.width(), h = area.height();

        if (filter == FILTER_SCAN) {
            // One dark line every 2 device pixels; skip entirely when the
            // picture is too small for it to read as anything but mush.
            if (scale < 1.5f) return;
            gridPaint.setColor(0x40000000);
            gridPaint.setStrokeWidth(Math.max(1f, scale * 0.5f));
            for (int y = area.top; y < area.bottom; y += 2) {
                c.drawLine(area.left, y, area.right, y, gridPaint);
            }
            return;
        }

        // FILTER_LCD: a faint cell grid aligned to GBA pixels, which is what
        // gives the "real handheld LCD" look.
        float cell = Math.max(2f, scale);
        if (cell < 3f) return;                 // too dense to be worth drawing
        gridPaint.setColor(0x2A000000);
        gridPaint.setStrokeWidth(1f);
        float[] xs = new float[(int) (w / cell) + 2];
        float[] ys = new float[(int) (h / cell) + 2];
        int nx = 0, ny = 0;
        for (float x = area.left; x <= area.right && nx < xs.length; x += cell) xs[nx++] = x;
        for (float y = area.top; y <= area.bottom && ny < ys.length; y += cell) ys[ny++] = y;
        for (int i = 0; i < nx; i++)
            c.drawLine(xs[i], area.top, xs[i], area.bottom, gridPaint);
        for (int i = 0; i < ny; i++)
            c.drawLine(area.left, ys[i], area.right, ys[i], gridPaint);
    }

    /** The game picture alone, at its native 240x160, with brightness applied
     *  but no letterbox bars and no filter overlay.
     *
     *  Used for save-slot thumbnails: at 240x160 a scanline grid would be
     *  half a pixel wide and read as noise, and the bars would waste a third
     *  of a small image. Skipping both keeps the thumbnail legible.
     *
     *  Unlike capture() this does not depend on the view having been laid
     *  out, so it works even before the first frame is presented. */
    public Bitmap captureGameOnly() {
        Bitmap out = Bitmap.createBitmap(NativeBridge.SCREEN_W,
                                         NativeBridge.SCREEN_H,
                                         Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(out);
        c.drawBitmap(framebuffer, src, src, paint);
        return out;
    }

    /** Render the current frame, with filter and brightness, into a new
     *  bitmap at the on-screen size. Returns null if the view has no size yet. */
    public Bitmap capture() {
        int vw = getWidth(), vh = getHeight();
        if (vw <= 0 || vh <= 0) return null;
        Bitmap out = Bitmap.createBitmap(vw, vh, Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(out);
        c.drawColor(0xFF000000);              // letterbox bars
        renderTo(c, vw, vh);
        return out;
    }
}
