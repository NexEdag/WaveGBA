package com.wavegba;

import android.graphics.Bitmap;

/** Thin wrapper over the JNI layer in cpp/native-lib.cpp. */
public final class NativeBridge {

    static {
        try {
            System.loadLibrary("wavegba");
        } catch (Throwable t) {
            android.util.Log.e("WaveGBA", "loadLibrary 失败", t);
        }
    }

    /** GBA button bit masks - must match GBA_BTN_* in libretro_frontend.h. */
    public static final int BTN_A      = 1 << 8;
    public static final int BTN_B      = 1 << 0;
    public static final int BTN_SELECT = 1 << 2;
    public static final int BTN_START  = 1 << 3;
    public static final int BTN_RIGHT  = 1 << 7;
    public static final int BTN_LEFT   = 1 << 6;
    public static final int BTN_UP     = 1 << 4;
    public static final int BTN_DOWN   = 1 << 5;
    /* L and R were 1<<9 and 1<<10, which are the libretro ids for X and L.
     * The core queries the mask by *joypad id* (input_state_cb returns
     * (mask >> id) & 1), so those two bits asked for the wrong buttons:
     *   bit  9 -> JOYPAD_X, which is only a turbo bind (off by default),
     *             so the L key did nothing at all
     *   bit 11 (JOYPAD_R) was never sent by anything, so R never fired
     * The correct ids are JOYPAD_L = 10 and JOYPAD_R = 11. */
    public static final int BTN_L      = 1 << 10;
    public static final int BTN_R      = 1 << 11;

    public static final int SCREEN_W = 240;
    public static final int SCREEN_H = 160;
    public static final int SAMPLE_RATE = 32000;

    private NativeBridge() {}

    public static native boolean nativeInit(byte[] rom, String saveDir, String romName, int frameskip);
    public static native void    nativeDestroy();
    public static native boolean nativeRunFrame(int buttons);
    public static native boolean nativeRender(Bitmap bitmap);
    public static native int     nativeAudioDrain(short[] dst);
    public static native int     nativeSaveState(int slot);
    public static native int     nativeLoadState(int slot);
    public static native int     nativeSaveBattery();
    public static native int     nativeLoadBattery();
    public static native void    nativeReset();
    public static native int     nativeFrameDelayUs();
    public static native String  nativeVersion();

    /** Real-time clock mode for cartridges that have one.
     *  0 = auto (core's per-ROM table), 1 = always on, 2 = off.
     *  Default is on: a game without an RTC never reads the RTC ports, so
     *  leaving it enabled costs nothing, while leaving it off silently
     *  breaks every game that does have one. Takes effect on the next frame. */
    public static native void    nativeSetRtcMode(int mode);

    public static native int     nativeGetRtcMode();
}
