package com.wavegba;

import android.content.SharedPreferences;

/** Colour scheme: a few presets plus a freely chosen accent.
 *
 *  Kept as plain ints in a singleton rather than resources because every
 *  consumer (pad, library, menus) is built in code -- there is no layout
 *  inflater in the loop to re-resolve @color references at runtime, so
 *  changing a resource would not repaint anything that is already on screen.
 *
 *  An accent alone is not enough to make a theme: the same cyan on a near
 *  black and on a light grey panel reads as two different apps. Each preset
 *  therefore carries the surface colours it was picked against. */
public final class Theme {

    public static final int P_DEEP = 0;      // 深空黑（默认）
    public static final int P_GBA = 1;       // GBA 经典灰
    public static final int P_OLED = 2;      // OLED 纯黑
    public static final int P_CONTRAST = 3;  // 高对比
    public static final int P_CUSTOM = 4;    // 自定义主色

    public static final String[] NAMES = {
            "深空黑", "GBA 经典灰", "OLED 纯黑", "高对比", "自定义"
    };

    /** The accent each preset ships with, so 自定义 starts somewhere sane
     *  instead of at black. */
    private static final int[] PRESET_ACCENT = {
            0xFF22D3EE,   // cyan
            0xFF8B5CF6,   // violet, reads well on warm grey
            0xFF34D399,   // green: OLED panels render it with least smear
            0xFFFBBF24,   // amber, maximum contrast on black
            0xFF22D3EE,
    };
    private static final int[] PRESET_BG = {
            0xFF0D0D0F, 0xFF2B2B33, 0xFF000000, 0xFF000000, 0xFF0D0D0F,
    };
    private static final int[] PRESET_SURFACE = {
            0xFF17171C, 0xFF3A3A44, 0xFF0A0A0A, 0xFF141414, 0xFF17171C,
    };
    private static final int[] PRESET_SURFACE_HI = {
            0xFF212129, 0xFF46464F, 0xFF161616, 0xFF242424, 0xFF212129,
    };
    /** Presets whose surfaces are light enough to need dark text. */
    private static final boolean[] PRESET_LIGHT_TEXT_BG = {
            false, true, false, false, false,
    };

    private static int preset = P_DEEP;
    private static int customAccent = PRESET_ACCENT[P_DEEP];
    private static int customBg = PRESET_BG[P_DEEP];
    private static int customSurface = PRESET_SURFACE[P_DEEP];

    private Theme() {}

    public static void load(SharedPreferences sp) {
        preset = sp.getInt("theme_preset", P_DEEP);
        if (preset < 0 || preset > P_CUSTOM) preset = P_DEEP;
        customAccent = sp.getInt("theme_accent", PRESET_ACCENT[P_DEEP]);
        customBg = sp.getInt("theme_bg", PRESET_BG[P_DEEP]);
        customSurface = sp.getInt("theme_surface", PRESET_SURFACE[P_DEEP]);
    }

    public static void save(SharedPreferences sp) {
        sp.edit().putInt("theme_preset", preset)
                .putInt("theme_accent", customAccent)
                .putInt("theme_bg", customBg)
                .putInt("theme_surface", customSurface)
                .apply();
    }

    public static int preset() { return preset; }

    public static void setPreset(int p) {
        preset = (p < 0 || p > P_CUSTOM) ? P_DEEP : p;
        if (preset != P_CUSTOM) {
            // Leaving a preset to customise starts from that preset, not from
            // whatever was customised last time -- otherwise switching to
            // 自定义 shows the colour of a preset you never picked.
            customAccent = PRESET_ACCENT[preset];
            customBg = PRESET_BG[preset];
            customSurface = PRESET_SURFACE[preset];
        }
    }

    public static int accent() {
        return preset == P_CUSTOM ? customAccent : PRESET_ACCENT[preset];
    }

    public static int bg() {
        return preset == P_CUSTOM ? customBg : PRESET_BG[preset];
    }

    public static int surface() {
        return preset == P_CUSTOM ? customSurface : PRESET_SURFACE[preset];
    }

    public static int surfaceHi() {
        return preset == P_CUSTOM ? shade(customSurface, 1.18f)
                : PRESET_SURFACE_HI[preset];
    }

    public static boolean lightSurfaces() {
        return preset == P_CUSTOM ? luma(customSurface) > 0.42f
                : PRESET_LIGHT_TEXT_BG[preset];
    }

    /** Text colour for anything sitting directly on a surface. */
    public static int textPrimary() {
        return lightSurfaces() ? 0xFF1A1A20 : 0xFFF2F4F7;
    }

    public static int textSecondary() {
        return lightSurfaces() ? 0xFF5B5B66 : 0xFF9AA3AF;
    }

    public static int divider() {
        return lightSurfaces() ? 0x335B5B66 : 0x332A2A33;
    }

    public static void setAccent(int a) {
        customAccent = a;
        preset = P_CUSTOM;
    }

    /** Set the accent straight from a wheel position, so the stored colour is
     *  exactly the one that was touched. */
    public static void setAccentHueSat(float hue, float sat) {
        setAccent(accentForHueSat(hue, sat));
    }

    /** Custom presets carry their own base; used by the picker's preview. */
    public static void setCustomBase(int bg, int surface) {
        customBg = bg;
        customSurface = surface;
    }

    public static void setBg(int b) { customBg = b; preset = P_CUSTOM; }
    public static void setSurface(int s) { customSurface = s; preset = P_CUSTOM; }

    /* ------------------------------------------------------------ utils -- */

    /** Multiply a colour's brightness, keeping alpha. */
    public static int shade(int color, float f) {
        int a = color & 0xFF000000;
        int r = clamp((int) (((color >> 16) & 0xFF) * f));
        int g = clamp((int) (((color >> 8) & 0xFF) * f));
        int b = clamp((int) ((color & 0xFF) * f));
        return a | (r << 16) | (g << 8) | b;
    }

    private static int clamp(int v) { return v < 0 ? 0 : (v > 255 ? 255 : v); }

    /** Perceived brightness, 0..1. */
    public static float luma(int color) {
        int r = (color >> 16) & 0xFF, g = (color >> 8) & 0xFF, b = color & 0xFF;
        return (0.299f * r + 0.587f * g + 0.114f * b) / 255f;
    }

    /** Accent at reduced alpha, for fills and glows. */
    public static int accentAlpha(int alpha) {
        int a = clamp(alpha) << 24;
        return a | (accent() & 0x00FFFFFF);
    }

    /** A colour's hue on the HSV wheel, 0..360. Used by the picker. */
    public static float hueOf(int color) {
        float[] hsv = new float[3];
        android.graphics.Color.colorToHSV(color, hsv);
        return hsv[0];
    }

    /** Saturation used by the picker's wheel and by every accent it produces.
     *
     *  One constant rather than a value repeated at each call site: the wheel
     *  paints its disc with this, so if generation used a different number the
     *  colour you touched would not be the colour you got. */
    public static final float ACCENT_SAT = 0.78f;

    /** Value (brightness) held at 1: GBA-era art is fully saturated, and a
     *  dimmed accent loses contrast against a dark panel. */
    public static final float ACCENT_VAL = 1.0f;

    /** Saturated accent of the given hue -- the picker's wheel output. */
    public static int accentForHue(float hue) {
        return accentForHueSat(hue, ACCENT_SAT);
    }

    /** Accent for a hue/saturation pair picked off the wheel. */
    public static int accentForHueSat(float hue, float sat) {
        return android.graphics.Color.HSVToColor(
                new float[]{hue, clamp01(sat), ACCENT_VAL});
    }

    private static float clamp01(float v) {
        return v < 0f ? 0f : (v > 1f ? 1f : v);
    }

    /** Swatch of evenly spaced hues for the grid picker. */
    public static int[] swatches(int n) {
        int[] out = new int[n];
        for (int i = 0; i < n; i++) out[i] = accentForHue(i * 360f / n);
        return out;
    }
}
