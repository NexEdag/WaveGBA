package com.wavegba;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RadialGradient;
import android.graphics.Shader;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.util.AttributeSet;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;

import java.util.ArrayList;

/** Touch pad drawn on top of the screen.
 *
 *  Styled as outlined discs rather than solid blobs: a translucent dark
 *  glass fill with a hairline rim, and a teal tint when a key is held.
 *  The accent hue is the green end of the app icon's gradient. */
public class VirtualPad extends View {

    public interface Listener {
        void onButtons(int mask);
    }

    /** Keys that are not GBA buttons.
     *
     *  They live in the same list so the layout editor can move them like any
     *  other key, but they are outside the 10-bit button mask and are reported
     *  through a separate callback -- feeding them into onButtons() would make
     *  the emulator see a phantom key press. */
    public static final int FN_QUICK_SAVE = 1 << 20;
    public static final int FN_QUICK_LOAD = 1 << 21;

    /** Identifies the d-pad as a whole.
     *
     *  It is not a GBA button and never reaches the emulator: a press is
     *  resolved into BTN_UP/DOWN/LEFT/RIGHT before it is stored. The bit
     *  exists only so the layout editor can move the d-pad as one object. */
    public static final int DPAD = 1 << 22;

    /** The four direction bits, i.e. what the d-pad can actually produce.
     *
     *  Needed because the d-pad is drawn from the merged button mask, which
     *  also carries A/B/START/SELECT/L/R. Testing that mask for non-zero
     *  lights the cross whenever ANY key is held -- press A and the d-pad
     *  glows, which reads as if the direction were stuck. */
    public static final int DPAD_DIRS = NativeBridge.BTN_UP | NativeBridge.BTN_DOWN
            | NativeBridge.BTN_LEFT | NativeBridge.BTN_RIGHT;

    public static boolean isFunctionKey(int bit) {
        return bit == FN_QUICK_SAVE || bit == FN_QUICK_LOAD || bit == DPAD;
    }

    /** Half-width of a d-pad arm, as a fraction of the arm's reach.
     *
     *  0.28, down from 0.46. At 0.46 the arms came out wider than the A
     *  button's own diameter, which is what "又宽又胖" was: the cross looked
     *  heavier than the round keys beside it. On real hardware the d-pad's
     *  arms are noticeably narrower than the face buttons, and matching that
     *  is what makes it read as part of the same pad.
     *
     *  The reach it is a fraction of is unchanged, so this thins the arms
     *  without shrinking how far they extend. */
    private static final float DPAD_ARM_RATIO = 0.28f;

    /** Reach as a fraction of the face-button radius.
     *
     *  2.15, down from 2.45: the cross spanned 4.9r edge to edge, i.e. over
     *  a third of a phone screen in portrait. Real GBA d-pads are about 2.25x
     *  a face button across, not 2.45x per arm. */
    private static final float DPAD_REACH_RATIO = 2.15f;

    /** Centre dead zone, as a fraction of the arm reach.
     *
     *  It only has to stop the direction flickering between neighbours when
     *  a finger rests on the exact centre. At 0.22 it swallowed a fifth of
     *  the pad, which read as the key not responding at all. */
    private static final float DPAD_DEAD = 0.12f;

    /** How far past the drawn arm a touch still counts (in dp).
     *
     *  18, up from 7 as the arms got thinner. The drawn cross is now purely
     *  an aiming aid; this is what catches the finger. At 18dp the effective
     *  target is as wide as it was when the arms were drawn fat, so the pad
     *  is slimmer to look at without being any harder to hit.
     *
     *  It only widens the arms, never the corners between them, so a thinner
     *  cross does not start swallowing taps meant for neighbouring keys. */
    private static final float DPAD_TOL_DP = 18f;

    /** Once the d-pad is held, the finger may drift this far outside its
     *  bounding box (as a fraction of the reach) and the direction still
     *  follows. Rolling a thumb outward is how directions are changed, and
     *  dropping the input the moment the pad is left makes that unusable. */
    private static final float DPAD_SLACK = 0.45f;

    public interface FunctionListener {
        /** Called on the DOWN edge of a function key, once per press. */
        void onFunctionKey(int bit);
    }

    private FunctionListener fnListener;

    public void setFunctionListener(FunctionListener l) { fnListener = l; }

    /* Accent (teal) and its pressed-state wash. */
    /** Accent comes from the active theme; these are only the initial values,
     *  replaced whenever the theme changes. */
    private static int ACCENT      = 0xFF22D3EE;
    private static int ACCENT_FILL = 0x38 << 24 | (0x22 << 16) | (0xD3 << 8) | 0xEE;
    private static final int PRIMARY      = 0xFFA855F7;

    /** A held key swells slightly and its glow brightens. */
    private static final float PRESSED_SCALE = 1.08f;

    private final ArrayList<Key> keys = new ArrayList<>();
    private final int[] pointers = new int[10];
    /** Which key each pointer went down on.
     *
     *  Tracking this separately is what makes sliding work: `pointers` holds
     *  the resulting mask, which is 0 while the finger sits in the d-pad's
     *  dead zone. Keying the move handling off that mask meant once a press
     *  registered as "nothing", moving onto an arm was ignored forever --
     *  the pad appeared dead until the finger was lifted and re-pressed. */
    private final int[] pointerBits = new int[10];
    private Listener listener;

    private final Paint fill    = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint fillOn  = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint rim     = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint rimOn   = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint text    = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint textOn  = new Paint(Paint.ANTI_ALIAS_FLAG);
    /* Function-key paints, kept apart from the GBA button ones. */
    private final Paint fnFill   = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint fnFillOn = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint fnRim    = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint fnRimOn  = new Paint(Paint.ANTI_ALIAS_FLAG);

    /* Held-key glow.
     *
     *  This used to allocate a RadialGradient per key per frame -- ten keys
     *  at 60fps is 600 shader objects a second, all of them with identical
     *  geometry and one of two colours. Shaders are not cheap to build and
     *  certainly not worth rebuilding for a value that never changes.
     *
     *  Instead one unit gradient (centre 0,0 radius 1) is built once and
     *  reused for every key: the canvas is translated to the key centre and
     *  scaled by its glow radius, then a unit circle is drawn. The gradient
     *  follows the transform, so the result is the same picture. */
    private final Paint glow = new Paint(Paint.ANTI_ALIAS_FLAG);
    private RadialGradient glowUnit = null;
    private int glowUnitColor = 0;

    private boolean portrait = false;
    /** Bits flagged for autofire; each gets a small dot as a visual cue. */
    private int turboKeys = 0;
    private final Paint dot = new Paint(Paint.ANTI_ALIAS_FLAG);

    public VirtualPad(Context c) { super(c); init(); }
    public VirtualPad(Context c, AttributeSet a) { super(c, a); init(); }
    public VirtualPad(Context c, AttributeSet a, int s) { super(c, a, s); init(); }

    /** The shared glow paint, its unit gradient rebuilt only if the colour
     *  actually changed. */
    private Paint glowFor(int argb) {
        if (glowUnit == null || glowUnitColor != argb) {
            glowUnit = new RadialGradient(0f, 0f, 1f,
                    argb, Color.TRANSPARENT, Shader.TileMode.CLAMP);
            glowUnitColor = argb;
            glow.setShader(glowUnit);
        }
        return glow;
    }

    /** Draw a soft radial wash of the given radius at (cx, cy), using the
     *  shared gradient rather than a fresh one. */
    private void drawGlow(Canvas c, int argb, float cx, float cy, float r) {
        if (r <= 0f) return;
        Paint p = glowFor(argb);
        int save = c.save();
        c.translate(cx, cy);
        c.scale(r, r);
        c.drawCircle(0f, 0f, 1f, p);
        c.restoreToCount(save);
    }

    private void init() {
        glow.setStyle(Paint.Style.FILL);
        dot.setStyle(Paint.Style.FILL);
        dot.setARGB(200, 34, 211, 238);
        fill.setStyle(Paint.Style.FILL);
        fill.setARGB(52, 14, 18, 26);          // dark glass, idle

        fillOn.setStyle(Paint.Style.FILL);
        fillOn.setColor(ACCENT_FILL);          // teal wash, held

        rim.setStyle(Paint.Style.STROKE);
        rim.setARGB(78, 255, 255, 255);        // hairline rim

        rimOn.setStyle(Paint.Style.STROKE);
        rimOn.setColor(ACCENT);                // rim lights up when held
        rimOn.setAlpha(210);

        Typeface light = Typeface.create("sans-serif-light", Typeface.NORMAL);
        text.setARGB(196, 232, 240, 240);
        text.setTypeface(light);
        text.setTextAlign(Paint.Align.CENTER);

        textOn.setARGB(255, 255, 255, 255);
        textOn.setTypeface(light);
        textOn.setTextAlign(Paint.Align.CENTER);
    }

    public void setListener(Listener l) { listener = l; }

    public void setTurboKeys(int mask) { turboKeys = mask; invalidate(); }

    /** Layout in normalised coords (0..1) so it adapts to any screen.
     *  Portrait uses a taller, more compact arrangement: the pad occupies a
     *  wide-but-short strip under the screen, so the buttons are spread over
     *  its full height instead of hugging the bottom like in landscape. */
    @Override
    protected void onSizeChanged(int w, int h, int ow, int oh) {
        layoutKeys(w, h);
    }

    public boolean isPortrait() { return portrait; }

    public void setPortrait(boolean p) {
        if (portrait == p) return;
        portrait = p;
        layoutKeys(getWidth(), getHeight());
        invalidate();
    }

    /* ------------------------------------------------- 功能：按键布局编辑 */

    private boolean editMode = false;
    private float userScale = 1.0f;       // global size multiplier
    private float userAlpha = 1.0f;       // global opacity
    private int draggingBit = 0;          // key currently being dragged
    private float dragDx = 0f, dragDy = 0f;

    /** Custom positions, normalised so they survive a screen-size change:
     *  nx,ny are fractions of width/height and nr of the shorter side. */
    private static final class Pos {
        final int bit;
        final float nx, ny, nr;
        Pos(int bit, float nx, float ny, float nr) {
            this.bit = bit; this.nx = nx; this.ny = ny; this.nr = nr;
        }
    }

    private java.util.ArrayList<Pos> custom = null;
    /** Separate from `listener` (which reports button presses) so the editor
     *  and the game input never get confused. */
    private LayoutListener layoutSink = null;

    public interface LayoutListener {
        /** Called when the user finishes moving a key, so the host can save. */
        void onLayoutChanged(String json);
    }

    public void setLayoutListener(LayoutListener l) { layoutSink = l; }

    public void setEditMode(boolean on) {
        editMode = on;
        draggingBit = 0;
        invalidate();
    }

    public boolean isEditMode() { return editMode; }

    public float getUserScale() { return userScale; }

    /** Scale every key about its own centre, keeping the arrangement intact. */
    public void setUserScale(float s) {
        userScale = Math.max(0.60f, Math.min(1.80f, s));
        layoutKeys(getWidth(), getHeight());
        invalidate();
    }

    public float getUserAlpha() { return userAlpha; }

    public void setUserAlpha(float a) {
        userAlpha = Math.max(0.25f, Math.min(1.0f, a));
        invalidate();
    }

    /** Bumped whenever the default layout changes.
     *
     *  A saved custom layout is normalised coordinates, so it survives a
     *  change to the defaults and would quietly keep the old arrangement --
     *  the player would never see the improved one. Storing the version
     *  alongside lets a stale layout be dropped instead. */
    public static final int LAYOUT_VERSION = 3;

    private static final String TAG = "WaveGBA.pad";

    /** Apply a layout exported by exportLayout(), or null for the default.
     *
     *  A JSON written by an older build carries no version (or a different
     *  one), and applying it would restore the old default arrangement over
     *  the current one. Such a layout is dropped so the new defaults win --
     *  the player can still rearrange and save again. */
    public void importLayout(String json) {
        if (json == null || json.length() == 0) return;
        try {
            org.json.JSONObject root = new org.json.JSONObject(json);
            if (root.optInt("v", 0) != LAYOUT_VERSION) {
                Log.w(TAG, "按键布局版本不符，改用新的默认布局");
                return;
            }
            custom = parseObj(root);
            userScale = (float) root.optDouble("scale", 1.0f);
            userAlpha = (float) root.optDouble("alpha", 1.0f);
            layoutKeys(getWidth(), getHeight());
            invalidate();
        } catch (Throwable t) {
            Log.w(TAG, "按键布局解析失败", t);
        }
    }

    /** Kept separate so applyCustom() can be reached without re-checking the
     *  version during editing. */
    public void setCustomLayout(String json) {
        custom = parse(json);
        layoutKeys(getWidth(), getHeight());
        invalidate();
    }

    public void resetLayout() {
        custom = null;
        userScale = 1.0f;
        layoutKeys(getWidth(), getHeight());
        invalidate();
    }

    /** Serialise positions (+ scale/alpha) so they can be stored. */
    public String exportLayout() {
        try {
            org.json.JSONArray a = new org.json.JSONArray();
            int w = getWidth(), h = getHeight();
            if (w > 0 && h > 0) {
                float m = Math.min(w, h);
                for (Key k : keys) {
                    org.json.JSONObject o = new org.json.JSONObject();
                    o.put("bit", k.bit);
                    o.put("x", k.px / w);
                    o.put("y", k.py / h);
                    o.put("r", k.r / m);
                    a.put(o);
                }
            }
            org.json.JSONObject root = new org.json.JSONObject();
            root.put("v", LAYOUT_VERSION);
            root.put("keys", a);
            root.put("scale", userScale);
            root.put("alpha", userAlpha);
            return root.toString();
        } catch (Throwable t) {
            return null;
        }
    }

    /** Parse from an already-decoded object; used when the caller has had to
     *  read the version field first. */
    private static java.util.ArrayList<Pos> parseObj(org.json.JSONObject root) {
        java.util.ArrayList<Pos> out = new java.util.ArrayList<Pos>();
        if (root == null) return out;
        org.json.JSONArray a = root.optJSONArray("keys");
        if (a == null) return out;
        for (int i = 0; i < a.length(); i++) {
            org.json.JSONObject o = a.optJSONObject(i);
            if (o == null) continue;
            out.add(new Pos(o.optInt("bit"), (float) o.optDouble("x"),
                    (float) o.optDouble("y"), (float) o.optDouble("r")));
        }
        return out;
    }

    private static java.util.ArrayList<Pos> parse(String json) {
        if (json == null || json.isEmpty()) return null;
        try {
            org.json.JSONObject root = new org.json.JSONObject(json);
            java.util.ArrayList<Pos> out = new java.util.ArrayList<>();
            org.json.JSONArray a = root.getJSONArray("keys");
            for (int i = 0; i < a.length(); i++) {
                org.json.JSONObject o = a.getJSONObject(i);
                out.add(new Pos(o.getInt("bit"), (float) o.getDouble("x"),
                        (float) o.getDouble("y"), (float) o.getDouble("r")));
            }
            return out;
        } catch (Throwable t) {
            return null;
        }
    }

    private void applyCustom(int w, int h) {
        if (custom == null || custom.isEmpty() || w <= 0 || h <= 0) return;
        float m = Math.min(w, h);
        for (Pos p : custom) {
            for (Key k : keys) {
                if (k.bit == p.bit) {
                    k.px = p.nx * w;
                    k.py = p.ny * h;
                    k.r = p.nr * m;
                    break;
                }
            }
        }
    }

    private void layoutKeys(int w, int h) {
        keys.clear();
        if (w <= 0 || h <= 0) return;

        if (portrait) {
            /* Portrait: the pad is a wide strip under the screen.
             *
             * Overlap rule: two discs of radius r1,r2 need centre distance
             * >= r1+r2. The d-pad is a "+", so its diagonal neighbours are
             * arm*sqrt(2) apart -- arm = 1.45r gives 2.05r >= 2r.
             *
             * Thumb reach: the natural arc of a thumb held at the bottom
             * corner passes through roughly (0.25w, 0.78h) on the left and
             * (0.75w, 0.78h) on the right, so both clusters sit lower than
             * before (0.60h) -- closer to where the thumb actually rests. */
            float r = Math.min(w, h) * 0.082f;
            text.setTextSize(r * 0.62f);
            textOn.setTextSize(r * 0.62f);

            // One cross, sized to occupy the same box the four discs did.
            float dcx = w * 0.235f, dcy = h * 0.755f;
            addDpad(dcx, dcy, r * DPAD_REACH_RATIO);

            // A / B diagonal: offset 0.78r keeps them 2.2r apart.
            float off = r * 0.78f;
            float acx = w * 0.770f, acy = h * 0.730f;
            add(NativeBridge.BTN_B, acx - off, acy + off, r);
            add(NativeBridge.BTN_A, acx + off, acy - off, r);

            // L / R move to the outer edges beside the face buttons: the top
            // corners were a stretch, and reaching up there meant letting go
            // of the d-pad entirely.
            float lr = r * 0.70f;
            add(NativeBridge.BTN_L, w * 0.100f, h * 0.905f, lr);
            add(NativeBridge.BTN_R, w * 0.930f, h * 0.905f, lr);

            // Start / Select centred between the two clusters, where either
            // thumb can get to them without crossing the screen.
            float sr = r * 0.58f;
            add(NativeBridge.BTN_SELECT, w * 0.455f, h * 0.635f, sr);
            add(NativeBridge.BTN_START,  w * 0.575f, h * 0.600f, sr);

            // Quick save / load: small, tucked at the very top corners where
            // they are out of the thumb's working arc. Accidentally hitting
            // save is harmless; accidentally hitting load is not, so load
            // sits a little further from the edge than save.
            float fr = r * 0.50f;
            add(FN_QUICK_SAVE, w * 0.075f, h * 0.075f, fr);
            add(FN_QUICK_LOAD, w * 0.255f, h * 0.075f, fr);
        } else {
            float r = Math.min(w, h) * 0.075f;
            text.setTextSize(r * 0.62f);
            textOn.setTextSize(r * 0.62f);

            float dcx = w * 0.155f, dcy = h * 0.640f;
            addDpad(dcx, dcy, r * DPAD_REACH_RATIO);

            float off = r * 0.80f;
            float acx = w * 0.855f, acy = h * 0.620f;
            add(NativeBridge.BTN_B, acx - off, acy + off, r);
            add(NativeBridge.BTN_A, acx + off, acy - off, r);

            // L / R below the face buttons rather than above: in landscape the
            // top corners are the hardest part of the screen to reach.
            float lr = r * 0.78f;
            add(NativeBridge.BTN_L, w * 0.700f, h * 0.880f, lr);
            add(NativeBridge.BTN_R, w * 0.965f, h * 0.880f, lr);

            float sr = r * 0.60f;
            add(NativeBridge.BTN_SELECT, w * 0.430f, h * 0.905f, sr);
            add(NativeBridge.BTN_START,  w * 0.560f, h * 0.905f, sr);

            // Quick save / load at the top-left, away from both thumbs.
            float fr = r * 0.52f;
            add(FN_QUICK_SAVE, w * 0.030f, h * 0.075f, fr);
            add(FN_QUICK_LOAD, w * 0.105f, h * 0.075f, fr);
        }

        if (userScale != 1.0f) {
            for (Key k : keys) k.r *= userScale;
        }
        applyCustom(w, h);

        for (Key k : keys) {
            k.box = new RectF(k.px - k.r, k.py - k.r, k.px + k.r, k.py + k.r);
        }
    }

    /** Place a key at a pixel centre. Callers must keep centres at least
     *  (r1 + r2) apart, otherwise the discs overlap and taps become ambiguous. */
    /** Pull the accent from the current theme and repaint on the next frame. */
    public void applyTheme() {
        ACCENT = Theme.accent();
        ACCENT_FILL = (0x38 << 24) | (Theme.accent() & 0x00FFFFFF);
        dot.setARGB(200, (ACCENT >> 16) & 0xFF, (ACCENT >> 8) & 0xFF, ACCENT & 0xFF);
        fillOn.setColor(ACCENT_FILL);
        rimOn.setColor(ACCENT);
        glow.setColor(ACCENT);
        invalidate();
    }

    private void add(int bit, float px, float py, float r) {
        keys.add(new Key(bit, px, py, r, false));
    }

    /** One cross instead of four separate discs.
     *
     *  Four discs left a gap in the middle that read as four unrelated
     *  buttons, and rolling a thumb across them to change direction meant
     *  leaving one and hunting for the next. A single cross is what the
     *  hardware actually has. */
    private void addDpad(float px, float py, float reach) {
        keys.add(new Key(DPAD, px, py, reach, true));
    }

    /** Arm half-width for a d-pad of the given reach. */
    private static float armHalf(float reach) { return reach * DPAD_ARM_RATIO; }

    /** Resolve a touch on the d-pad into a button mask.
     *
     *  Diagonals are recognised when neither axis clearly dominates (ratio
     *  between 1:2 and 2:1), because several GBA games use them and a strict
     *  four-way pad makes those moves impossible. */
    static int dpadMask(Key k, float x, float y) {
        float dx = x - k.px, dy = y - k.py;
        float dead = k.r * DPAD_DEAD;
        boolean l = dx < -dead, r = dx > dead, u = dy < -dead, d = dy > dead;
        if (!l && !r && !u && !d) return 0;          // dead zone: no direction

        float ax = Math.abs(dx), ay = Math.abs(dy);
        if (l || r) {
            if (u || d) {
                // Both axes moved; keep the second only if it is a genuine
                // diagonal rather than a mostly-horizontal drag.
                float ratio = ay > 0 ? ax / ay : 99f;
                if (ratio < 0.5f) { l = r = false; }
                else if (ratio > 2f) { u = d = false; }
            }
        }
        int m = 0;
        if (l) m |= NativeBridge.BTN_LEFT;
        if (r) m |= NativeBridge.BTN_RIGHT;
        if (u) m |= NativeBridge.BTN_UP;
        if (d) m |= NativeBridge.BTN_DOWN;
        return m;
    }

    /** Is this point on the cross itself? The bounding square's corners are
     *  not part of the pad and must not swallow taps meant for a neighbour. */
    private boolean onDpad(Key k, float x, float y) {
        if (k.box == null) return false;
        float tol = DPAD_TOL_DP * getResources().getDisplayMetrics().density;
        float h = armHalf(k.r) + tol;
        float dx = Math.abs(x - k.px), dy = Math.abs(y - k.py);
        if (dx > k.r + tol || dy > k.r + tol) return false;
        return dx <= h || dy <= h;
    }

    /** Like onDpad, but for a finger already holding the d-pad: the box is
     *  grown by DPAD_SLACK so drifting off the edge keeps steering instead of
     *  dropping the input. */
    private boolean onDpadHeld(Key k, float x, float y) {
        if (k.box == null) return false;
        float slack = k.r * DPAD_SLACK;
        float h = armHalf(k.r) + slack;
        float dx = Math.abs(x - k.px), dy = Math.abs(y - k.py);
        if (dx > k.r + slack || dy > k.r + slack) return false;
        return dx <= h || dy <= h;
    }

    /** Draw the d-pad: one cross, with the arm being pressed lit up.
     *
     *  The path is the union of the two arms so the middle has no seam --
     *  two overlapping round rects would draw their strokes straight through
     *  the centre of the cross. */
    /** The cross outline: clockwise from the left end of the horizontal arm.
     *  R = arm reach (half the pad's span), h = arm half-width.
     *
     *  Corners are rounded rather than square. The sharp 90-degree version
     *  looked stamped out of sheet metal; a radius roughly a third of the arm
     *  width gives it the moulded look of the real part. */
    private static android.graphics.Path crossPath(
            float cx, float cy, float R, float h) {
        final float[] px = {-R, -h, -h, h, h, R, R, h, h, -h, -h, -R};
        final float[] py = {-h, -h, -R, -R, -h, -h, h, h, R, R, h, h};
        // Cap the radius: it must not exceed half the shorter adjacent edge,
        // or neighbouring corners would round into each other.
        float rad = Math.min(h * 0.62f, (R - h) * 0.5f);

        android.graphics.Path p = new android.graphics.Path();
        int n = px.length;
        for (int i = 0; i < n; i++) {
            int prev = (i + n - 1) % n, next = (i + 1) % n;
            float ax = px[i] - px[prev], ay = py[i] - py[prev];
            float bx = px[next] - px[i], by = py[next] - py[i];
            float la = (float) Math.hypot(ax, ay), lb = (float) Math.hypot(bx, by);
            if (la < 0.01f || lb < 0.01f) continue;
            float ra = Math.min(rad, la * 0.5f), rb = Math.min(rad, lb * 0.5f);
            float x0 = cx + px[i] - ax / la * ra, y0 = cy + py[i] - ay / la * ra;
            float x1 = cx + px[i] + bx / lb * rb, y1 = cy + py[i] + by / lb * rb;
            if (i == 0) p.moveTo(x0, y0);
            else p.lineTo(x0, y0);
            p.quadTo(cx + px[i], cy + py[i], x1, y1);
        }
        p.close();
        return p;
    }

    private void drawDpad(Canvas c, Key k, int dm, float lw) {
        // dm is already reduced to the direction bits by the caller.
        float h = armHalf(k.r);
        float reach = k.r;

        // Traced as one twelve-point outline rather than two overlapping
        // rects: filling and stroking separate rects draws their borders
        // straight across the middle of the cross. Path.op() would merge them
        // properly but needs API 19, and this is built against API 14.
        android.graphics.Path cross = crossPath(k.px, k.py, reach, h);

        float cx = k.px, cy = k.py;
        float gr = reach * (dm != 0 ? 0.95f : 0.72f);
        drawGlow(c, Color.argb(dm != 0 ? 96 : 36, 34, 211, 238), cx, cy, gr);

        c.drawPath(cross, dm != 0 ? fillOn : fill);
        c.drawPath(cross, dm != 0 ? rimOn : rim);

        // Light up just the arm being held, so a diagonal reads as two arms
        // rather than as the whole cross flashing.
        int up = NativeBridge.BTN_UP, dn = NativeBridge.BTN_DOWN;
        int lf = NativeBridge.BTN_LEFT, rt = NativeBridge.BTN_RIGHT;
        float tip = reach - h;                  // length of one arm segment
        if ((dm & lf) != 0) c.drawRoundRect(
                new RectF(k.px - reach, k.py - h, k.px - tip + h, k.py + h),
                h * 0.4f, h * 0.4f, fillOn);
        if ((dm & rt) != 0) c.drawRoundRect(
                new RectF(k.px + tip - h, k.py - h, k.px + reach, k.py + h),
                h * 0.4f, h * 0.4f, fillOn);
        if ((dm & up) != 0) c.drawRoundRect(
                new RectF(k.px - h, k.py - reach, k.px + h, k.py - tip + h),
                h * 0.4f, h * 0.4f, fillOn);
        if ((dm & dn) != 0) c.drawRoundRect(
                new RectF(k.px - h, k.py + tip - h, k.px + h, k.py + reach),
                h * 0.4f, h * 0.4f, fillOn);

        // Centre hub: the real pad has one, and on a flat glass screen it is
        // the only cue for where the middle is -- without it there is nothing
        // to aim away from.
        // Smaller hub and a hairline ring only -- a filled disc the size of
        // the old one was another reason the pad looked heavy.
        float hub = h * 0.30f;
        c.drawCircle(cx, cy, hub, fill);
        Paint hubRing = new Paint(Paint.ANTI_ALIAS_FLAG);
        hubRing.setStyle(Paint.Style.STROKE);
        hubRing.setStrokeWidth(lw * 0.7f);
        hubRing.setARGB(dm != 0 ? 150 : 70, 255, 255, 255);
        c.drawCircle(cx, cy, hub, hubRing);

        // Direction notches, so the arms read as directions rather than as
        // two crossed bars.
        drawArrow(c, cx - reach * 0.63f, cy, h * 0.30f, -1, 0, (dm & lf) != 0);
        drawArrow(c, cx + reach * 0.63f, cy, h * 0.30f, 1, 0, (dm & rt) != 0);
        drawArrow(c, cx, cy - reach * 0.63f, h * 0.30f, 0, -1, (dm & up) != 0);
        drawArrow(c, cx, cy + reach * 0.63f, h * 0.30f, 0, 1, (dm & dn) != 0);

        if (editMode) {
            Paint g = new Paint(Paint.ANTI_ALIAS_FLAG);
            g.setStyle(Paint.Style.STROKE);
            g.setStrokeWidth(Math.max(1f, lw * 0.8f));
            g.setColor(0xFF22D3EE);
            g.setPathEffect(new android.graphics.DashPathEffect(
                    new float[]{8f, 6f}, 0f));
            c.drawPath(cross, g);
        }
    }

    /** A small triangle pointing along (dx,dy), sitting at the tip of an arm. */
    private void drawArrow(Canvas c, float cx, float cy, float s,
                           float dx, float dy, boolean on) {
        android.graphics.Path p = new android.graphics.Path();
        float ax = cx + dx * s, ay = cy + dy * s;          // tip
        float bx = cx - dx * s * 0.45f, by = cy - dy * s * 0.45f;
        // Narrower base: the earlier arrows were almost equilateral, which
        // filled the arm ends and added to the bulk.
        float px = -dy * s * 0.52f, py = dx * s * 0.52f;
        p.moveTo(ax, ay);
        p.lineTo(bx + px, by + py);
        p.lineTo(bx - px, by - py);
        p.close();
        Paint f = new Paint(Paint.ANTI_ALIAS_FLAG);
        f.setStyle(Paint.Style.FILL);
        f.setColor(on ? ACCENT : 0x66FFFFFF);
        c.drawPath(p, f);
    }

    private static String label(int bit) {
        switch (bit) {
            case NativeBridge.BTN_A: return "A";
            case NativeBridge.BTN_B: return "B";
            case NativeBridge.BTN_L: return "L";
            case NativeBridge.BTN_R: return "R";
            case NativeBridge.BTN_START: return "ST";
            case NativeBridge.BTN_SELECT: return "SEL";
            case NativeBridge.BTN_UP: return "^";
            case NativeBridge.BTN_DOWN: return "v";
            case NativeBridge.BTN_LEFT: return "<";
            case NativeBridge.BTN_RIGHT: return ">";
            case FN_QUICK_SAVE: return "SAVE";
            case FN_QUICK_LOAD: return "LOAD";
            default: return "";
        }
    }

    @Override
    protected void onDraw(Canvas c) {
        int mask = currentMask();
        float lw = Math.max(1.2f, getResources().getDisplayMetrics().density * 1.3f);
        rim.setStrokeWidth(lw);
        rimOn.setStrokeWidth(lw);
        // Function keys get their own paint set: purple rim/fill so they never
        // read as GBA buttons at a glance.
        fnFill.setStyle(Paint.Style.FILL);
        fnFill.setARGB(58, 40, 20, 62);
        fnFillOn.setStyle(Paint.Style.FILL);
        fnFillOn.setARGB(90, 168, 85, 247);
        fnRim.setStyle(Paint.Style.STROKE);
        fnRim.setARGB(110, 168, 85, 247);
        fnRim.setStrokeWidth(lw);
        fnRimOn.setStyle(Paint.Style.STROKE);
        fnRimOn.setColor(PRIMARY);
        fnRimOn.setStrokeWidth(lw);

        if (editMode) {
            // Dashed guides make it obvious the pad is being rearranged and
            // that dragging moves a key rather than pressing it.
            Paint g = new Paint(Paint.ANTI_ALIAS_FLAG);
            g.setStyle(Paint.Style.STROKE);
            g.setStrokeWidth(Math.max(1f, lw * 0.8f));
            g.setColor(0xFF22D3EE);
            g.setPathEffect(new android.graphics.DashPathEffect(
                    new float[]{8f, 6f}, 0f));
            for (Key k : keys) {
                if (k.box == null || k.dpad) continue;   // d-pad drawn later
                RectF b = new RectF(k.box);
                b.inset(-3f, -3f);
                c.drawOval(b, g);
            }
        }

        int held = 0;
        for (int b : pointers) held |= b;

        for (Key k : keys) {
            if (k.box == null) continue;
            if (k.dpad) { drawDpad(c, k, mask & DPAD_DIRS, lw); continue; }
            boolean fn = isFunctionKey(k.bit);
            // Function keys are held in `pointers` but excluded from `mask`,
            // so their held state has to be read separately.
            boolean on = fn ? (held & k.bit) != 0 : (mask & k.bit) != 0;
            // Inset by half the stroke so the rim stays fully inside the view.
            RectF b = new RectF(k.box);
            b.inset(lw * 0.5f, lw * 0.5f);

            // Soft outer glow under the disc. Held keys get a brighter, wider
            // wash, which is what makes a press feel immediate.
            float cx = b.centerX(), cy = b.centerY();
            float gr = b.width() * (on ? 0.95f : 0.72f);
            int hue = fn ? PRIMARY : (on ? ACCENT : PRIMARY);
            drawGlow(c, Color.argb(on ? 96 : 36,
                    Color.red(hue), Color.green(hue), Color.blue(hue)), cx, cy, gr);

            // Swell the disc a touch while held.
            RectF d = b;
            if (on) {
                d = new RectF(b);
                d.inset(-(b.width() * (PRESSED_SCALE - 1f) * 0.5f),
                        -(b.height() * (PRESSED_SCALE - 1f) * 0.5f));
            }

            if (fn) {
                c.drawOval(d, on ? fnFillOn : fnFill);
                c.drawOval(d, on ? fnRimOn : fnRim);
            } else {
                c.drawOval(d, on ? fillOn : fill);
                c.drawOval(d, on ? rimOn : rim);
            }

            if ((turboKeys & k.bit) != 0) {
                float dr = Math.max(2f, d.width() * 0.07f);
                c.drawCircle(d.centerX(), d.bottom - dr * 2.2f, dr, dot);
            }

            Paint t = on ? textOn : text;
            Paint.FontMetrics fm = t.getFontMetrics();
            c.drawText(label(k.bit), d.centerX(),
                       d.centerY() - (fm.ascent + fm.descent) / 2, t);
        }
    }

    private int currentMask() {
        int m = 0;
        for (int b : pointers) {
            // Function keys are not GBA buttons; folding them in would make
            // the emulator see a key nobody pressed.
            if (isFunctionKey(b)) continue;
            m |= b;
        }
        return m;
    }

    private void publish() {
        int m = currentMask();
        if (listener != null) listener.onButtons(m);
        invalidate();
    }

    @Override
    public boolean onTouchEvent(MotionEvent e) {
        int action = e.getActionMasked();
        int idx = e.getActionIndex();
        int id = e.getPointerId(idx);

        // In edit mode a drag moves the key instead of pressing it, so the
        // game never sees the button that is being repositioned.
        if (editMode) {
            float x = e.getX(Math.min(idx, e.getPointerCount() - 1));
            float y = e.getY(Math.min(idx, e.getPointerCount() - 1));
            switch (action) {
                case MotionEvent.ACTION_DOWN:
                    draggingBit = hit(x, y);
                    if (draggingBit != 0) {
                        Key k = keyFor(draggingBit);
                        dragDx = k.px - x;
                        dragDy = k.py - y;
                    }
                    break;
                case MotionEvent.ACTION_MOVE:
                    if (draggingBit != 0) {
                        Key k = keyFor(draggingBit);
                        float w = getWidth(), h = getHeight();
                        // Keep the whole disc on screen.
                        k.px = Math.max(k.r, Math.min(w - k.r, x + dragDx));
                        k.py = Math.max(k.r, Math.min(h - k.r, y + dragDy));
                        k.box = new RectF(k.px - k.r, k.py - k.r, k.px + k.r, k.py + k.r);
                        invalidate();
                    }
                    break;
                case MotionEvent.ACTION_UP:
                case MotionEvent.ACTION_CANCEL:
                    if (draggingBit != 0 && listener != null) {
                        // Remember the position by re-exporting: the host
                        // persists whatever we hand it.
                        custom = parse(exportLayout());
                        layoutListenerSave();
                    }
                    draggingBit = 0;
                    break;
            }
            return true;
        }

        switch (action) {
            case MotionEvent.ACTION_DOWN:
            case MotionEvent.ACTION_POINTER_DOWN: {
                float x0 = e.getX(idx), y0 = e.getY(idx);
                int bit = hit(x0, y0);
                if (id < pointers.length) {
                    // Remember what was grabbed even when the resulting mask
                    // is 0 (d-pad dead zone), so a slide out of it works.
                    pointerBits[id] = bit;
                    pointers[id] = maskAt(x0, y0);
                }
                // Fire on the down edge only, and only for the two real
                // function keys -- a held SAVE would otherwise write the file
                // continuously, and the d-pad is not a function key at all.
                if (bit == FN_QUICK_SAVE || bit == FN_QUICK_LOAD) {
                    if (fnListener != null) fnListener.onFunctionKey(bit);
                }
                break;
            }
            case MotionEvent.ACTION_MOVE:
                for (int i = 0; i < e.getPointerCount(); i++) {
                    int pid = e.getPointerId(i);
                    if (pid >= pointers.length) continue;
                    int grabbed = pointerBits[pid];
                    if (grabbed == 0) continue;
                    float x = e.getX(i), y = e.getY(i);
                    if (grabbed == DPAD) {
                        Key k = keyFor(DPAD);
                        // Still steering while the finger drifts just off the
                        // pad; release only once it is clearly away.
                        pointers[pid] = (k != null && onDpadHeld(k, x, y))
                                ? dpadMask(k, x, y) : 0;
                    } else {
                        Key k = keyFor(grabbed);
                        pointers[pid] = (k != null && k.box != null
                                && k.box.contains(x, y)) ? grabbed : 0;
                    }
                }
                break;
            case MotionEvent.ACTION_UP:
            case MotionEvent.ACTION_POINTER_UP:
            case MotionEvent.ACTION_CANCEL:
                if (id < pointers.length) { pointers[id] = 0; pointerBits[id] = 0; }
                if (action == MotionEvent.ACTION_UP || action == MotionEvent.ACTION_CANCEL) {
                    java.util.Arrays.fill(pointers, 0);
                    java.util.Arrays.fill(pointerBits, 0);
                }
                break;
        }
        publish();
        return true;
    }

    private void layoutListenerSave() {
        if (layoutSink != null) layoutSink.onLayoutChanged(exportLayout());
    }

    private Key keyFor(int bit) {
        for (Key k : keys) if (k.bit == bit) return k;
        return null;
    }

    /** Which key is under this point, as its identifying bit.
     *
     *  For the d-pad that is DPAD, not a direction: the direction depends on
     *  where on the cross the finger landed, and is resolved by maskAt(). */
    private int hit(float x, float y) {
        for (Key k : keys) {
            if (k.dpad) { if (onDpad(k, x, y)) return k.bit; continue; }
            if (k.box != null && k.box.contains(x, y)) return k.bit;
        }
        return 0;
    }

    /** The button mask a touch at this point produces.
     *
     *  Everywhere except the d-pad this is simply the key's own bit. Kept
     *  separate from hit() because a slide across the cross has to update the
     *  held directions continuously -- without that, changing direction would
     *  need a lift and a fresh press. */
    private int maskAt(float x, float y) {
        for (Key k : keys) {
            if (k.dpad) { if (onDpad(k, x, y)) return dpadMask(k, x, y); continue; }
            if (k.box != null && k.box.contains(x, y)) return k.bit;
        }
        return 0;
    }

    private static final class Key {
        final int bit;
        float px, py, r;                /* pixel centre + radius (or, for the
                                          d-pad, half the arm reach) */
        RectF box;
        final boolean dpad;
        Key(int bit, float px, float py, float r, boolean dpad) {
            this.bit = bit; this.px = px; this.py = py; this.r = r;
            this.dpad = dpad;
        }
    }
}
