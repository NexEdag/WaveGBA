package com.wavegba;

import android.graphics.Bitmap;
import android.util.Log;

import java.io.File;
import java.lang.reflect.Method;
import java.nio.ByteBuffer;

/** H.264 in an MP4 container, via MediaCodec + MediaMuxer.
 *
 *  Everything is reflective. This project builds against an android.jar from
 *  2011 that has neither class, so compiling against them directly is
 *  impossible here -- but the app runs on API 23+, where both have existed
 *  since API 18. Reflection is the only way to get a real .mp4 out of this
 *  build.
 *
 *  Every constant is hard-coded rather than read from the framework, because
 *  the constant classes are missing too. These values are fixed and public in
 *  the platform, so this is safe.
 *
 *  Input is Bitmap -> NV12 (YUV 4:2:0 semi-planar), converted here. Feeding
 *  an encoder Surface would mean re-plumbing the renderer's output target;
 *  at 240x160 a Java-side conversion is cheap and self-contained.
 *
 *  If anything is unavailable at runtime the constructor throws, and the host
 *  falls back to the MJPEG/AVI recorder so recording never just dies. */
public final class Mp4Recorder {

    private static final String TAG = "WaveGBA.mp4";

    /* MediaFormat keys */
    private static final String KEY_BIT_RATE        = "bitrate";
    private static final String KEY_FRAME_RATE      = "frame-rate";
    private static final String KEY_COLOR_FORMAT    = "color-format";
    private static final String KEY_I_FRAME_INTERVAL = "i-frame-interval";

    /* MediaCodecInfo.CodecCapabilities */
    private static final int COLOR_FormatYUV420SemiPlanar = 21;
    private static final int COLOR_FormatYUV420Flexible   = 2135033992;

    /* MediaCodec flags */
    private static final int CONFIGURE_FLAG_ENCODE     = 1;
    private static final int BUFFER_FLAG_CODEC_CONFIG  = 2;
    private static final int BUFFER_FLAG_END_OF_STREAM = 4;

    /* MediaMuxer.OutputFormat */
    private static final int MUXER_OUTPUT_MPEG_4 = 0;
    private static final String KEY_AAC_PROFILE   = "aac-profile";
    private static final int AAC_PROFILE_LC       = 2;

    private final File out;
    private final int width, height;

    private Object codec;        /* MediaCodec, video */
    private Object muxer;        /* MediaMuxer */
    private ByteBuffer[] inBufs;
    private Object[] inInfos;    /* MediaCodec.BufferInfo for input tracking */

    private Object bufferInfo;   /* MediaCodec.BufferInfo */
    private int trackIndex = -1;
    private boolean muxerStarted = false;
    private boolean finished = false;

    /* ---- optional audio track ---- */
    private final boolean withAudio;
    private Object audioCodec;          /* MediaCodec, AAC */
    private Object audioBufferInfo;
    private int audioTrackIndex = -1;
    private int audioSampleRate = 32000;
    private Object audioFormat;         /* MediaFormat for the AAC track */
    private long audioPtsUs = 0;
    private boolean audioFailed = false;
    /* AAC-LC works on 1024-sample frames; hold a partial frame until it fills. */
    private static final int AAC_FRAME_SAMPLES = 1024;
    private final short[] audioAccum;
    private int audioHave = 0;
    private final java.nio.ByteBuffer audioOutBufs;

    private final byte[] nv12;
    private final int[] argb;

    private long ptsUs = 0;
    private final long frameDurUs;

    public Mp4Recorder(File out, int width, int height, int fps) throws Exception {
        this(out, width, height, fps, false, 32000, 2);
    }

    public Mp4Recorder(File out, int width, int height, int fps,
                       boolean audio, int sampleRate, int channels) throws Exception {
        if (width <= 0 || height <= 0) throw new IllegalArgumentException("bad size");
        if ((width & 1) != 0 || (height & 1) != 0) {
            // NV12 subsamples 2x2; odd dimensions would leave a half chroma
            // sample dangling, which most encoders reject.
            throw new IllegalArgumentException("dimensions must be even");
        }
        this.out = out;
        this.width = width;
        this.height = height;
        this.frameDurUs = 1_000_000L / Math.max(1, fps);
        this.withAudio = audio;

        nv12  = new byte[width * height * 3 / 2];
        argb  = new int[width * height];
        audioAccum = new short[AAC_FRAME_SAMPLES * 2];   /* stereo */
        audioOutBufs = java.nio.ByteBuffer.allocateDirect(AAC_FRAME_SAMPLES * 2 * 2);

        out.getParentFile().mkdirs();
        if (out.exists() && !out.delete()) Log.w(TAG, "无法删除旧文件");

        setUp(fps, sampleRate, channels);
    }

    /* ------------------------------------------------------------ setup --- */

    private void setUp(int fps, int sampleRate, int channels) throws Exception {
        Class<?> fmtCls = Class.forName("android.media.MediaFormat");
        Class<?> codecCls = Class.forName("android.media.MediaCodec");
        Class<?> muxerCls = Class.forName("android.media.MediaMuxer");
        Class<?> infoCls = Class.forName("android.media.MediaCodec$BufferInfo");

        Method createVideo = fmtCls.getMethod("createVideoFormat",
                String.class, int.class, int.class);
        Method setInt = fmtCls.getMethod("setInteger", String.class, int.class);

        Object format = createVideo.invoke(null, "video/avc", width, height);
        setInt.invoke(format, KEY_BIT_RATE, bitRateFor(width, height));
        setInt.invoke(format, KEY_FRAME_RATE, fps);
        setInt.invoke(format, KEY_I_FRAME_INTERVAL, 1);
        // Flexible first: the semi-planar constant is not accepted by every
        // encoder, and Flexible lets the codec pick a layout it supports.
        int colorFmt = pickColorFormat();
        setInt.invoke(format, KEY_COLOR_FORMAT, colorFmt);

        Method createEncoder = codecCls.getMethod("createEncoderByType", String.class);
        codec = createEncoder.invoke(null, "video/avc");

        Method configure = codecCls.getMethod("configure",
                fmtCls, android.view.Surface.class,
                Class.forName("android.media.MediaCrypto"), int.class);
        configure.invoke(codec, format, null, null, CONFIGURE_FLAG_ENCODE);

        Method start = codecCls.getMethod("start");
        start.invoke(codec);

        inBufs = (ByteBuffer[]) codecCls.getMethod("getInputBuffers").invoke(codec);

        // MediaMuxer(String path, int format) exists from API 18.
        java.lang.reflect.Constructor<?> ctor = muxerCls.getConstructor(
                String.class, int.class);
        muxer = ctor.newInstance(out.getAbsolutePath(), MUXER_OUTPUT_MPEG_4);

        bufferInfo = infoCls.newInstance();

        audioSampleRate = sampleRate;
        if (withAudio) setUpAudio(fmtCls, codecCls, infoCls, sampleRate, channels);
    }

    /** AAC track. Every step is optional: if the device's encoder refuses,
     *  audioFailed is set and the video still gets recorded silently -- better
     *  a mute file than no file at all. */
    private void setUpAudio(Class<?> fmtCls, Class<?> codecCls, Class<?> infoCls,
                            int sampleRate, int channels) {
        try {
            Method createAudio = fmtCls.getMethod("createAudioFormat",
                    String.class, int.class, int.class);
            Object fmt = createAudio.invoke(null, "audio/mp4a-latm", sampleRate, channels);
            Method setInt = fmtCls.getMethod("setInteger", String.class, int.class);
            setInt.invoke(fmt, KEY_BIT_RATE, 128_000);
            setInt.invoke(fmt, KEY_AAC_PROFILE, AAC_PROFILE_LC);
            // "max-input-size" keeps the encoder from rejecting a buffer it
            // considers too large; 2 bytes per sample per channel is enough.
            try {
                setInt.invoke(fmt, "max-input-size", AAC_FRAME_SAMPLES * 2 * channels);
            } catch (Throwable ignored) { }

            Method createEncoder = codecCls.getMethod("createEncoderByType", String.class);
            audioCodec = createEncoder.invoke(null, "audio/mp4a-latm");
            Method configure = codecCls.getMethod("configure",
                    fmtCls, android.view.Surface.class,
                    Class.forName("android.media.MediaCrypto"), int.class);
            configure.invoke(audioCodec, fmt, null, null, CONFIGURE_FLAG_ENCODE);
            codecCls.getMethod("start").invoke(audioCodec);

            audioBufferInfo = infoCls.newInstance();
            audioFormat = fmt;
        } catch (Throwable t) {
            Log.w(TAG, "AAC 编码器不可用，将录制无声视频", t);
            audioFailed = true;
            audioCodec = null;
            audioFormat = null;
        }
    }

    /** True when an audio track is actually going into the file. */
    public boolean hasAudio() { return withAudio && !audioFailed && audioCodec != null; }

    /** Ask the encoder which YUV layout it will actually accept. */
    private int pickColorFormat() {
        try {
            Object caps = codec.getClass()
                    .getMethod("getCodecInfo").invoke(codec);
            Object c = caps.getClass()
                    .getMethod("getCapabilitiesForType", String.class)
                    .invoke(caps, "video/avc");
            int[] arr = (int[]) c.getClass().getField("colorFormats").get(c);
            if (arr != null) {
                for (int v : arr) {
                    if (v == COLOR_FormatYUV420SemiPlanar) return v;
                }
                for (int v : arr) {
                    if (v == COLOR_FormatYUV420Flexible) return v;
                }
            }
        } catch (Throwable t) {
            Log.w(TAG, "无法查询编码器色彩格式，使用默认值", t);
        }
        return COLOR_FormatYUV420SemiPlanar;
    }

    private static int bitRateFor(int w, int h) {
        // ~2.5 Mbps for a 240x160 screen: small pixels, lots of flat colour,
        // so this is plenty and keeps files modest.
        long br = (long) w * h * 60L;
        return (int) Math.max(1_000_000L, Math.min(8_000_000L, br));
    }

    /* ------------------------------------------------------------ frames -- */

    /** Encode one frame. Must not throw: called from the emulation thread. */
    public void addFrame(Bitmap bmp) {
        if (finished || codec == null || bmp == null) return;
        try {
            bmp.getPixels(argb, 0, width, 0, 0, width, height);
            toNv12(argb, nv12, width, height);
            feedInput(nv12, false);
            drainOutput(false);
            ptsUs += frameDurUs;
        } catch (Throwable t) {
            Log.e(TAG, "写帧失败", t);
        }
    }

    private void feedInput(byte[] data, boolean eos) throws Exception {
        Class<?> codecCls = codec.getClass();
        Method dequeue = codecCls.getMethod("dequeueInputBuffer", long.class);

        long timeoutUs = 10_000L;
        int idx = (Integer) dequeue.invoke(codec, timeoutUs);
        if (idx < 0) return;

        // getInputBuffer(int) is the modern call; fall back to the array.
        ByteBuffer buf;
        try {
            buf = (ByteBuffer) codecCls.getMethod("getInputBuffer", int.class)
                    .invoke(codec, idx);
        } catch (Throwable t) {
            buf = inBufs[idx];
        }
        if (buf == null) return;

        buf.clear();
        buf.put(data);
        Method queue = codecCls.getMethod("queueInputBuffer",
                int.class, int.class, int.class, long.class, int.class);
        queue.invoke(codec, idx, 0, data.length, ptsUs,
                eos ? BUFFER_FLAG_END_OF_STREAM : 0);
    }

    /** Pull encoded output into the muxer. `eos` drains until the end. */
    private void drainOutput(boolean eos) throws Exception {
        Class<?> codecCls = codec.getClass();
        Method dequeue = codecCls.getMethod("dequeueOutputBuffer",
                Class.forName("android.media.MediaCodec$BufferInfo"), long.class);

        while (true) {
            int idx = (Integer) dequeue.invoke(codec, bufferInfo, 10_000L);
            if (idx < 0) break;

            int flags = intField(bufferInfo, "flags");
            int size  = intField(bufferInfo, "size");
            long pts  = longField(bufferInfo, "presentationTimeUs");

            ByteBuffer data;
            try {
                data = (ByteBuffer) codecCls.getMethod("getOutputBuffer", int.class)
                        .invoke(codec, idx);
            } catch (Throwable t) {
                ByteBuffer[] outs = (ByteBuffer[])
                        codecCls.getMethod("getOutputBuffers").invoke(codec);
                data = outs[idx];
            }

            if (data != null && size > 0 && (flags & BUFFER_FLAG_CODEC_CONFIG) == 0) {
                data.position(intField(bufferInfo, "offset"));
                data.limit(intField(bufferInfo, "offset") + size);
                ensureTrack();
                if (muxerStarted) {
                    Method write = muxer.getClass().getMethod("writeSampleData",
                            int.class, ByteBuffer.class,
                            Class.forName("android.media.MediaCodec$BufferInfo"));
                    write.invoke(muxer, trackIndex, data, bufferInfo);
                }
            }

            codecCls.getMethod("releaseOutputBuffer", int.class, boolean.class)
                    .invoke(codec, idx, false);

            if ((flags & BUFFER_FLAG_END_OF_STREAM) != 0) break;
            if (!eos) break;   // one pass per frame while streaming
        }
    }

    /** Add every track, then start the muxer.
     *
     *  MediaMuxer refuses addTrack() after start(), so the audio track has to
     *  be declared here even though no audio sample may have arrived yet. Its
     *  format is known up front -- unlike the video one, which only exists
     *  once the encoder produces output. */
    private void ensureTrack() throws Exception {
        if (trackIndex >= 0) return;
        Object fmt = codec.getClass().getMethod("getOutputFormat").invoke(codec);
        Method addTrack = muxer.getClass().getMethod("addTrack",
                Class.forName("android.media.MediaFormat"));
        trackIndex = (Integer) addTrack.invoke(muxer, fmt);

        if (hasAudio() && audioFormat != null && audioTrackIndex < 0) {
            try {
                audioTrackIndex = (Integer) addTrack.invoke(muxer, audioFormat);
            } catch (Throwable t) {
                Log.w(TAG, "音频轨道添加失败，改为无声", t);
                audioFailed = true;
                audioTrackIndex = -1;
            }
        }

        muxer.getClass().getMethod("start").invoke(muxer);
        muxerStarted = true;
    }

    /* ------------------------------------------------------------- audio -- */

    /** Feed PCM in. Called from the audio thread; must not throw.
     *  `pcm` is interleaved stereo, `frames` counts stereo frames. */
    public void addAudio(short[] pcm, int frames) {
        if (finished || !hasAudio()) return;
        if (pcm == null || frames <= 0) return;
        try {
            int i = 0;
            while (i < frames) {
                int room = AAC_FRAME_SAMPLES - audioHave;
                int take = Math.min(room, frames - i);
                System.arraycopy(pcm, i * 2, audioAccum, audioHave * 2, take * 2);
                audioHave += take;
                i += take;
                if (audioHave == AAC_FRAME_SAMPLES) {
                    encodeAudioFrame();
                    audioHave = 0;
                }
            }
        } catch (Throwable t) {
            Log.e(TAG, "音频写入失败", t);
        }
    }

    private void encodeAudioFrame() throws Exception {
        Class<?> codecCls = audioCodec.getClass();

        // Dequeue with a short timeout: this runs on the audio thread and a
        // long block here would stall playback.
        int idx = (Integer) codecCls.getMethod("dequeueInputBuffer", long.class)
                .invoke(audioCodec, 5_000L);
        if (idx < 0) return;

        java.nio.ByteBuffer buf;
        try {
            buf = (java.nio.ByteBuffer) codecCls
                    .getMethod("getInputBuffer", int.class).invoke(audioCodec, idx);
        } catch (Throwable t) {
            buf = ((java.nio.ByteBuffer[]) codecCls
                    .getMethod("getInputBuffers").invoke(audioCodec))[idx];
        }
        if (buf == null) return;

        audioOutBufs.clear();
        audioOutBufs.asShortBuffer().put(audioAccum, 0, AAC_FRAME_SAMPLES * 2);
        buf.clear();
        buf.put(audioOutBufs);

        codecCls.getMethod("queueInputBuffer",
                int.class, int.class, int.class, long.class, int.class)
                .invoke(audioCodec, idx, 0, AAC_FRAME_SAMPLES * 2 * 2, audioPtsUs, 0);

        audioPtsUs += AAC_FRAME_SAMPLES * 1_000_000L / audioSampleRate;
        drainAudio(false);
    }

    private void drainAudio(boolean eos) throws Exception {
        Class<?> codecCls = audioCodec.getClass();
        Method dequeue = codecCls.getMethod("dequeueOutputBuffer",
                Class.forName("android.media.MediaCodec$BufferInfo"), long.class);

        while (true) {
            int idx = (Integer) dequeue.invoke(audioCodec, audioBufferInfo, 5_000L);
            if (idx < 0) break;

            int flags = intField(audioBufferInfo, "flags");
            int size  = intField(audioBufferInfo, "size");

            java.nio.ByteBuffer data;
            try {
                data = (java.nio.ByteBuffer) codecCls
                        .getMethod("getOutputBuffer", int.class).invoke(audioCodec, idx);
            } catch (Throwable t) {
                data = ((java.nio.ByteBuffer[]) codecCls
                        .getMethod("getOutputBuffers").invoke(audioCodec))[idx];
            }

            // The muxer only exists once the first video frame arrives, so
            // early audio is dropped rather than buffered forever.
            if (data != null && size > 0 && (flags & BUFFER_FLAG_CODEC_CONFIG) == 0
                    && muxerStarted && audioTrackIndex >= 0) {
                data.position(intField(audioBufferInfo, "offset"));
                data.limit(intField(audioBufferInfo, "offset") + size);
                muxer.getClass().getMethod("writeSampleData",
                        int.class, java.nio.ByteBuffer.class,
                        Class.forName("android.media.MediaCodec$BufferInfo"))
                        .invoke(muxer, audioTrackIndex, data, audioBufferInfo);
            }

            codecCls.getMethod("releaseOutputBuffer", int.class, boolean.class)
                    .invoke(audioCodec, idx, false);

            if ((flags & BUFFER_FLAG_END_OF_STREAM) != 0) break;
            if (!eos) break;
        }
    }

    private static int intField(Object o, String name) throws Exception {
        return o.getClass().getField(name).getInt(o);
    }

    private static long longField(Object o, String name) throws Exception {
        return o.getClass().getField(name).getLong(o);
    }

    /** Finish: signal EOS, drain what is left, then close the muxer. */
    public void close() {
        if (finished) return;
        finished = true;
        try {
            if (hasAudio()) {
                try {
                    // Flush a partial frame padded with silence so the tail of
                    // the recording is not cut off mid-word.
                    if (audioHave > 0) {
                        java.util.Arrays.fill(audioAccum, audioHave * 2,
                                audioAccum.length, (short) 0);
                        encodeAudioFrame();
                    }
                    Class<?> cc = audioCodec.getClass();
                    int idx = (Integer) cc.getMethod("dequeueInputBuffer", long.class)
                            .invoke(audioCodec, 10_000L);
                    if (idx >= 0) {
                        cc.getMethod("queueInputBuffer",
                                int.class, int.class, int.class, long.class, int.class)
                                .invoke(audioCodec, idx, 0, 0, audioPtsUs,
                                        BUFFER_FLAG_END_OF_STREAM);
                    }
                    drainAudio(true);
                } catch (Throwable t) {
                    Log.w(TAG, "音频收尾失败", t);
                }
            }
            if (codec != null) {
                try { feedInput(new byte[0], true); } catch (Throwable ignored) { }
                try { drainOutput(true); } catch (Throwable ignored) { }
            }
        } finally {
            try {
                if (muxer != null && muxerStarted) {
                    muxer.getClass().getMethod("stop").invoke(muxer);
                }
            } catch (Throwable t) {
                Log.w(TAG, "muxer stop 失败", t);
            }
            try {
                if (muxer != null) muxer.getClass().getMethod("release").invoke(muxer);
            } catch (Throwable ignored) { }
            try {
                if (codec != null) codec.getClass().getMethod("stop").invoke(codec);
            } catch (Throwable ignored) { }
            try {
                if (codec != null) codec.getClass().getMethod("release").invoke(codec);
            } catch (Throwable ignored) { }
            try {
                if (audioCodec != null)
                    audioCodec.getClass().getMethod("stop").invoke(audioCodec);
            } catch (Throwable ignored) { }
            try {
                if (audioCodec != null)
                    audioCodec.getClass().getMethod("release").invoke(audioCodec);
            } catch (Throwable ignored) { }
            codec = null;
            audioCodec = null;
            muxer = null;
        }
    }

    public File file() { return out; }

    /* ------------------------------------------------------- colour ---- */

    private static int clamp8(int v) { return v < 0 ? 0 : v > 255 ? 255 : v; }

    /** ARGB -> NV12 (full-res Y plane, then interleaved U/V at half res). */
    static void toNv12(int[] argb, byte[] out, int w, int h) {
        int p = 0;
        for (int y = 0; y < h; y++) {
            for (int x = 0; x < w; x++) {
                int c = argb[y * w + x];
                int r = (c >> 16) & 0xFF, g = (c >> 8) & 0xFF, b = c & 0xFF;
                int Y = ((66 * r + 129 * g + 25 * b + 128) >> 8) + 16;
                out[p++] = (byte) clamp8(Y);
            }
        }
        for (int y = 0; y < h; y += 2) {
            for (int x = 0; x < w; x += 2) {
                int r = 0, g = 0, b = 0;
                for (int dy = 0; dy < 2; dy++) {
                    for (int dx = 0; dx < 2; dx++) {
                        int c = argb[(y + dy) * w + (x + dx)];
                        r += (c >> 16) & 0xFF;
                        g += (c >> 8) & 0xFF;
                        b += c & 0xFF;
                    }
                }
                r >>= 2; g >>= 2; b >>= 2;
                int U = ((-38 * r - 74 * g + 112 * b + 128) >> 8) + 128;
                int V = ((112 * r - 94 * g - 18 * b + 128) >> 8) + 128;
                // NV12 interleaves U then V. Writing V first produces NV21,
                // which decodes with red and blue swapped -- the picture looks
                // plausible at a glance, which is exactly why this needs a
                // decode check rather than eyeballing the code.
                out[p++] = (byte) clamp8(U);
                out[p++] = (byte) clamp8(V);
            }
        }
    }
}
