package com.wavegba;

import android.util.Log;

/** Owns the run/render loop. Runs on its own thread; touches the View only
 *  through postInvalidate().
 *
 *  倍速通过"每轮跑几帧"实现：用累加器把小数倍速摊到相邻几轮上，
 *  例如 1.5x 会交替跑 1、2、1、2 帧，长期平均正好 1.5 倍。
 *  这样不需要改动核心，也不会因为取整而让 0.5x 之类的倍速失真。 */
public final class EmulatorThread extends Thread {

    private static final String TAG = "WaveGBA.loop";

    /** Supplies the button mask for each simulated frame. */
    public interface InputSource {
        int onFrame();
    }

    /** Called once per rendered frame. The recorder hooks this to encode a
     *  frame without the emulation loop needing to know about video. */
    public interface FrameSink {
        void onFrameDrawn();
    }

    private final EmulatorView view;
    private volatile InputSource inputSource;
    private volatile FrameSink frameSink;
    private volatile boolean running = false;
    private volatile boolean paused  = false;
    private volatile int buttons = 0;

    /** 倍速，1.0 = 原速 */
    private volatile double speed = 1.0;
    /** Draw one pass in this many. 1 = every pass. */
    private volatile int renderEvery = 1;
    private int renderTick = 0;
    private double frameAccumulator = 0.0;

    private final int[] frameTimes = new int[60];
    private int frameIdx = 0;

    /** 基准帧时长（纳秒），GBA 约 59.73fps */
    /** The GBA refreshes at ~59.73 Hz, not 60: it is a quirk of the hardware's
     *  pixel clock, and getting it wrong drifts a frame every couple of
     *  seconds. Public so the UI can turn measured fps back into a speed
     *  multiple. */
    public static final double BASE_FPS = 59.7275;
    private static final double BASE_FRAME_NS = 1e9 / BASE_FPS;
    /** 一轮最多补多少帧，避免卡顿后疯狂追帧 */
    /** Most frames simulated in one pass.
     *
     *  A cap on burst size, not on speed. The accumulator is debited the full
     *  step before this clamp is applied, so no time is lost and a high speed
     *  still comes out exact -- verified by simulation up to 16x. What it does
     *  bound is how long a single pass can run, which is what keeps one slow
     *  frame from turning into a visible hitch.
     *
     *  Raised from 6 alongside the new speed steps: the time budget scales
     *  with the frame count, so leaving it at 6 would have had 16x wake up
     *  160 times a second for a 6ms sleep each. At 16 it wakes 60 times, as at
     *  1x, which costs less and is not fighting the scheduler's sleep
     *  granularity. */
    /** Most frames simulated in one pass.
     *
     *  A cap on burst size, not on speed: the accumulator is debited the full
     *  step before this clamp is applied, so no time is lost and a high speed
     *  still comes out exact -- verified by simulation to 64x. What it bounds
     *  is how long a single pass runs, which keeps one slow frame from turning
     *  into a visible hitch.
     *
     *  Set to the top offered speed so the loop sleeps once per frame interval
     *  rather than waking repeatedly for short sleeps: at 64x with a cap of 16
     *  it would wake 240 times a second. */
    private static final int MAX_CATCHUP = 64;

    public EmulatorThread(EmulatorView view) {
        super("gba-emu");
        this.view = view;
    }

    public void setButtons(int mask) { buttons = mask; }

    /** When set, the loop calls this every frame instead of using the last
     *  value handed to setButtons(). */
    public void setInputSource(InputSource src) { inputSource = src; }

    public void setFrameSink(FrameSink s) { frameSink = s; }

    /** 设置倍速，范围为 0.25x ~ 8x */
    public void setSpeed(double s) {
        speed = Math.max(0.25, Math.min(MAX_CATCHUP, s));
        // Reset the accumulator: it is a fraction of a frame carried between
        // passes, so leftover from a different speed would be scaled wrongly.
        frameAccumulator = 0.0;
        renderEvery = renderEveryFor(speed);
        renderTick = 0;
    }

    /** Draw one frame in how many passes.
     *
     *  Pulling the framebuffer and redrawing it scaled costs the same whether
     *  the pass simulated one frame or sixty, so at high speeds it is pure
     *  overhead against a picture nobody can follow. Cutting the redraw rate
     *  gives that time back to simulation.
     *
     *  Starts at 8x, where the picture has already stopped being readable as
     *  gameplay. The steps are small on purpose: halving it is a visible
     *  change, and going straight to a quarter makes the screen look frozen
     *  rather than fast. */
    private static int renderEveryFor(double speed) {
        if (speed >= 32.0) return 4;
        if (speed >= 16.0) return 3;
        if (speed >= 8.0) return 2;
        return 1;
    }

    public double getSpeed() { return speed; }

    public void setPaused(boolean p) {
        paused = p;
        if (!p) synchronized (this) { notifyAll(); }
    }

    public boolean isPaused() { return paused; }

    public void stopLoop() {
        running = false;
        interrupt();
        try { join(600); } catch (InterruptedException ignored) {}
    }

    /** 实际渲染帧率（屏幕上每秒刷新几张画面） */
    public double fps() {
        long total = 0;
        int n = 0;
        for (int t : frameTimes) { if (t > 0) { total += t; n++; } }
        return n == 0 ? 0.0 : (n * 1e9) / total;
    }

    /** 等效模拟速度 = 渲染帧率 x 倍速 */
    public double simulatedFps() { return fps() * speed; }

    @Override
    public void run() {
        running = true;
        long lastFrameNs = System.nanoTime();

        while (running) {
            if (paused) {
                synchronized (this) {
                    try { if (paused && running) wait(200); } catch (InterruptedException e) { return; }
                }
                lastFrameNs = System.nanoTime();
                frameAccumulator = 0.0;
                continue;
            }

            long t0 = System.nanoTime();

            // --- 本轮要模拟多少帧 ---
            frameAccumulator += speed;
            int frames = (int) frameAccumulator;
            frameAccumulator -= frames;
            if (frames > MAX_CATCHUP) frames = MAX_CATCHUP;
            if (frames <= 0) {
                // 慢放（<1x）时本轮不模拟，睡到下一轮再算
                sleepNs((long) (BASE_FRAME_NS / speed));
                continue;
            }

            InputSource src = inputSource;
            for (int i = 0; i < frames; i++) {
                NativeBridge.nativeRunFrame(src != null ? src.onFrame() : buttons);
            }
            // Only the last frame of the batch is drawn -- intermediate ones
            // are never visible. At high speeds even that one can be skipped:
            // pulling the framebuffer and redrawing it scaled is fixed cost
            // per pass, and at 16x the picture is a blur anyway.
            //
            // Recording always draws. Skipping frames there would drop them
            // from the video, which is not something to do behind the
            // player's back just because they picked a fast speed.
            boolean draw = frameSink != null || (++renderTick % renderEvery == 0);
            if (draw) view.pullFrame();

            // Once, not twice. This was called two times per pass, which
            // doubled the recorder's frame counter and so halved the playback
            // speed of every recording: the timestamp advanced by a frame's
            // duration on each call while real time advanced once.
            FrameSink fs = frameSink;
            if (fs != null) fs.onFrameDrawn();

            long dt = System.nanoTime() - t0;
            frameTimes[frameIdx = (frameIdx + 1) % frameTimes.length] = (int) dt;

            // --- 限速：目标是每 (基准帧长/倍速) 产出一批帧 ---
            double budget = (BASE_FRAME_NS * frames) / speed;
            long wait = (long) (budget - dt);
            if (wait > 0) sleepNs(wait);
        }
        Log.d(TAG, "循环已退出");
    }

    private void sleepNs(long ns) {
        if (ns <= 0) return;
        long ms = ns / 1_000_000;
        int rem = (int) (ns % 1_000_000);
        try {
            if (ms > 0) Thread.sleep(ms, rem);
            else Thread.sleep(0, rem);
        } catch (InterruptedException e) { running = false; }
    }
}
