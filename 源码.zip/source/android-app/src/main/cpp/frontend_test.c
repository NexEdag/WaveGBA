/* WaveGBA -- frontend self-test
 *
 * Exercises the platform-independent libretro frontend (libretro_frontend.c)
 * on the desktop so the JNI bridge can be layered on top of something that is
 * already known to work.
 *
 * IMPORTANT: the vba-next core is a process-wide singleton -- every retro_*
 * call mutates the same globals. Only ONE emu_frontend_t may exist at a time,
 * so every scenario below that needs a fresh machine does
 * init -> ... -> destroy before the next init.
 *
 *   cc -O1 -g -o ftest frontend_test.c libretro_frontend.c <core sources> -lm
 *   ./ftest <rom.gba> [save_dir] [input_probe.gba]
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>
#include <time.h>
#include <signal.h>
#include <execinfo.h>
#include <unistd.h>
#include <sys/stat.h>
#include <sys/types.h>

#include "libretro_frontend.h"

static void segv(int s)
{
   void *b[64];
   int n = backtrace(b, 64);
   (void)s;
   fprintf(stderr, "\n=== SIGSEGV ===\n");
   backtrace_symbols_fd(b, n, 2);
   _exit(99);
}

static int g_pass, g_fail;

static void check(const char *label, int ok)
{
   printf("  [%s] %s\n", ok ? "PASS" : "FAIL", label);
   if (ok) g_pass++; else g_fail++;
}

static uint8_t *load_file(const char *path, size_t *size)
{
   FILE *f = fopen(path, "rb");
   uint8_t *buf;
   long n;
   if (!f) { fprintf(stderr, "cannot open %s\n", path); return NULL; }
   fseek(f, 0, SEEK_END);
   n = ftell(f);
   fseek(f, 0, SEEK_SET);
   buf = (uint8_t *)malloc(n > 0 ? n : 1);
   if (fread(buf, 1, n, f) != (size_t)n) { fclose(f); free(buf); return NULL; }
   fclose(f);
   *size = (size_t)n;
   return buf;
}

static const char *base_name(const char *path)
{
   const char *s = strrchr(path, '/');
   return s ? s + 1 : path;
}

/* The core is a process-wide singleton, so every helper below finishes and
 * destroys its instance before another one is created. */
static emu_frontend_t *make_emu(const char *rom_path, const char *save_dir,
                                int frameskip)
{
   size_t size = 0;
   uint8_t *data = load_file(rom_path, &size);
   emu_config_t cfg;
   emu_frontend_t *e;
   if (!data) return NULL;
   memset(&cfg, 0, sizeof(cfg));
   cfg.save_dir  = save_dir;
   cfg.rom_name  = base_name(rom_path);
   cfg.frameskip = frameskip;
   e = emu_init(data, size, &cfg);
   free(data);
   return e;
}

static double now_s(void)
{
   struct timespec ts;
   clock_gettime(CLOCK_MONOTONIC, &ts);
   return ts.tv_sec + ts.tv_nsec * 1e-9;
}

static uint64_t fnv(const uint8_t *p, size_t n)
{
   uint64_t h = 1469598103934665603ULL;
   for (size_t i = 0; i < n; i++) { h ^= p[i]; h *= 1099511628211ULL; }
   return h;
}

static uint64_t frame_hash(emu_frontend_t *e)
{
   const uint8_t *p = (const uint8_t *)emu_get_framebuffer(e);
   return fnv(p, (size_t)GBA_SCREEN_W * GBA_SCREEN_H * 2);
}

static uint64_t run_for(emu_frontend_t *e, int frames, uint32_t mask)
{
   int i;
   for (i = 0; i < frames; i++)
      emu_run_frame(e, mask);
   return frame_hash(e);
}

/* scratch for audio: DRAIN_FRAMES frames == 2*DRAIN_FRAMES int16 */
#define DRAIN_FRAMES 4096
static int16_t g_audio_tmp[DRAIN_FRAMES * 2];

/* Drain whatever audio the core produced since the last call. */
static long drain_all(emu_frontend_t *e)
{
   long total = 0;
   int n;
   while ((n = emu_audio_drain(e, g_audio_tmp, DRAIN_FRAMES)) > 0)
      total += n;
   return total;
}

int main(int argc, char **argv)
{
   const char *rom      = (argc > 1) ? argv[1] : "bench_m3.gba";
   const char *save_dir = (argc > 2) ? argv[2] : "/tmp/edag_gba_test";
   const char *probe    = (argc > 3) ? argv[3] : "input_probe.gba";
   emu_frontend_t *e;
   int i, lit = 0, silent;
   long samples;
   uint16_t *fb;
   uint64_t hA, hB, href;

   mkdir(save_dir, 0777);
   setvbuf(stdout, NULL, _IONBF, 0);
   signal(SIGSEGV, segv);
   signal(SIGBUS, segv);

   printf("WaveGBA -- frontend self-test\n");
   printf("core: %s / %s\n", emu_get_core_name(), emu_get_core_version());
   printf("rom: %s   save dir: %s\n\n", rom, save_dir);

   /* ---------------------------------------------------------------- */
   printf("[1] load a ROM\n");
   e = make_emu(rom, save_dir, 0);
   check("emu_init returns an instance", e != NULL);
   if (!e) return 1;

   printf("[2] the core paints the framebuffer\n");
   run_for(e, 30, 0);
   fb = emu_get_framebuffer(e);
   for (i = 0; i < GBA_SCREEN_W * GBA_SCREEN_H; i++)
      if (fb[i] != 0) { lit++; if (lit > 500) break; }
   printf("    %d non-black pixels out of %d\n", lit, GBA_SCREEN_W * GBA_SCREEN_H);
   check("framebuffer is not blank", lit > 0);

   printf("[3] audio is drained (the bench ROM itself is silent)\n");
   emu_audio_flush(e);
   run_for(e, 30, 0);
   samples = drain_all(e);
   printf("    drained %ld samples\n", samples);
   check("audio buffer drains", samples > 0);
   silent = 1;
   {
      int n = emu_audio_drain(e, g_audio_tmp, DRAIN_FRAMES), j;
      for (j = 0; j < n * 2; j++) if (g_audio_tmp[j] != 0) { silent = 0; break; }
      printf("    note: bench ROM emits %s (no APU usage in it)\n",
            silent ? "silence" : "sound");
   }

   printf("[4] battery save round-trip\n");
   check("emu_save_battery writes the .sav", emu_save_battery(e) != 0);
   check("emu_load_battery reads it back", emu_load_battery(e) != 0);

   printf("[5] sustained throughput\n");
   {
      double t0 = now_s();
      run_for(e, 600, 0);
      double t1 = now_s();
      printf("    600 frames in %.3fs -> %.1f fps (reported %.1f)\n",
            t1 - t0, 600.0 / (t1 - t0), emu_get_fps(e));
      check("600 frames complete", 1);
   }
   emu_destroy(&e);
   check("emu_destroy clears the handle", e == NULL);

   /* ---------------------------------------------------------------- */
   printf("\n[6] input plumbing (core must see the buttons)\n");
   emu_frontend_t *p1 = make_emu(probe, save_dir, 0);
   hA = run_for(p1, 40, 0);
   emu_destroy(&p1);
   emu_frontend_t *p2 = make_emu(probe, save_dir, 0);
   hB = run_for(p2, 40, GBA_BTN_START);
   emu_destroy(&p2);
   printf("    no input   %016llx\n", (unsigned long long)hA);
   printf("    START held %016llx\n", (unsigned long long)hB);
   check("holding START changes the picture", hA != hB);

   /* ---------------------------------------------------------------- */
   printf("\n[7] save state round-trip is deterministic\n");
   emu_frontend_t *s1 = make_emu(rom, save_dir, 0);
   href = run_for(s1, 180, 0);
   emu_destroy(&s1);

   emu_frontend_t *s2 = make_emu(rom, save_dir, 0);
   run_for(s2, 100, 0);
   check("emu_save_state(slot 3) writes a file", emu_save_state(s2, 3) == 0);
   run_for(s2, 20, 0);          /* drift away from the snapshot */
   check("emu_load_state(slot 3) restores it", emu_load_state(s2, 3) == 0);
   hB = run_for(s2, 80, 0);     /* 100 + 80 == the 180-frame reference */
   emu_destroy(&s2);
   printf("    reference %016llx\n", (unsigned long long)href);
   printf("    restored  %016llx\n", (unsigned long long)hB);
   check("restored state converges to the reference", href == hB);

   /* ---------------------------------------------------------------- */
   printf("\n[8] reset and frame skipping\n");
   emu_frontend_t *r1 = make_emu(rom, save_dir, 0);
   run_for(r1, 50, 0);
   emu_reset(r1);
   hA = run_for(r1, 50, 0);
   printf("    after reset + 50 frames %016llx\n", (unsigned long long)hA);
   check("emu_reset produces a runnable machine", hA != 0);
   printf("    frame pacing hint: %.1f us/frame\n", emu_frame_delay_us(r1));
   check("frame delay is sane", emu_frame_delay_us(r1) > 0 &&
                               emu_frame_delay_us(r1) < 100000);
   emu_destroy(&r1);

   emu_frontend_t *r2 = make_emu(rom, save_dir, 2);
   hB = run_for(r2, 60, 0);
   emu_destroy(&r2);
   printf("    frameskip=2 runs: %016llx\n", (unsigned long long)hB);
   check("frameskip path runs", hB != 0);

   printf("\n%d passed, %d failed\n", g_pass, g_fail);
   return g_fail ? 1 : 0;
}
