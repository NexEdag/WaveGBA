/* WaveGBA -- native emulation frontend
 * Author: Edag
 *
 * Minimal libretro host: wires the vba-next core's callbacks to plain
 * buffers so a UI (Android JNI, or the desktop test harness) only has to
 * pump emu_run_frame() and drain audio.
 *
 * Deliberately free of any Android header so this file can be compiled
 * and exercised on the host -- see tools/frontend_test.c.
 */

#include "libretro_frontend.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <stdarg.h>

#include <libretro.h>

/* ---- ring buffer for audio ---------------------------------------- */
#define AUDIO_RING_FRAMES  8192          /* stereo frames; ~137 ms */

struct emu_frontend {
   uint16_t framebuf[GBA_SCREEN_W * GBA_SCREEN_H];   /* packed RGB565 */
   int16_t  audio_ring[AUDIO_RING_FRAMES * 2];
   int      audio_head;                  /* write position, in frames */
   int      audio_count;                 /* frames currently buffered  */
   uint32_t input_mask;

   char     save_dir[512];
   char     rom_name[256];
   char     sav_path[768];
   emu_log_fn log;

   int      frameskip;
   int      skip_counter;
   int      got_frame;

   double   fps;
   struct timespec last_frame_time;
   int      have_last_time;

   /* battery save (cartridge RAM) exposed by the core */
   void    *sram_data;
   size_t   sram_size;

   void    *state_buf;
   size_t   state_size;

};

/* ---- core function pointers --------------------------------------- */
static void (*f_set_environment)(retro_environment_t);
static void (*f_set_video_refresh)(retro_video_refresh_t);
static void (*f_set_audio_sample)(retro_audio_sample_t);
static void (*f_set_audio_sample_batch)(retro_audio_sample_batch_t);
static void (*f_set_input_poll)(retro_input_poll_t);
static void (*f_set_input_state)(retro_input_state_t);
static void (*f_init)(void);
static void (*f_deinit)(void);
static void (*f_run)(void);
static void (*f_reset)(void);
static bool (*f_load_game)(const struct retro_game_info *);
static void (*f_unload_game)(void);
static void (*f_get_system_info)(struct retro_system_info *);
static void (*f_get_system_av_info)(struct retro_system_av_info *);
static size_t (*f_serialize_size)(void);
static bool (*f_serialize)(void *, size_t);
static bool (*f_unserialize)(const void *, size_t);
static void *(*f_get_memory_data)(unsigned);
static size_t (*f_get_memory_size)(unsigned);
static unsigned (*f_api_version)(void);

/* The core is linked straight into this shared library, so the retro_*
 * symbols resolve at link time rather than through dlopen. */
#define BIND(sym)  f_##sym = retro_##sym

static void bind_core(void)
{
   BIND(set_environment);
   BIND(set_video_refresh);
   BIND(set_audio_sample);
   BIND(set_audio_sample_batch);
   BIND(set_input_poll);
   BIND(set_input_state);
   BIND(init);
   BIND(deinit);
   BIND(run);
   BIND(reset);
   BIND(load_game);
   BIND(unload_game);
   BIND(get_system_info);
   BIND(get_system_av_info);
   BIND(serialize_size);
   BIND(serialize);
   BIND(unserialize);
   BIND(get_memory_data);
   BIND(get_memory_size);
   BIND(api_version);
}

/* ---- per-instance state for the C-style callbacks ----------------- */
static emu_frontend_t *g_active = NULL;

static void emu_log(emu_frontend_t *emu, const char *fmt, ...)
{
   char buf[512];
   va_list ap;
   va_start(ap, fmt);
   vsnprintf(buf, sizeof(buf), fmt, ap);
   va_end(ap);
   if (emu && emu->log)
      emu->log(0, buf);
   else
      fprintf(stderr, "[WaveGBA] %s\n", buf);
}

/* ---- real-time clock ------------------------------------------------
 *
 * The core reads the wall clock itself (time() + localtime() in
 * core/src/memory.c) but only reports it while its "vbanext_rtc" option says
 * the cartridge has an RTC. Left on "auto" the core consults its
 * vba-over.ini table, so any game missing from that list -- most of them --
 * gets no clock at all and its date-based events never fire.
 *
 * This frontend answers the option itself, so the mode can be driven from the
 * app. Default is ON: a cartridge without an RTC never touches 0x80000c4/c6/c8
 * so leaving it enabled is harmless, while leaving it off silently breaks
 * every game that does have one. */
static int  g_rtc_mode  = 1;   /* 0 = auto (per-ROM table), 1 = on, 2 = off */
static bool g_rtc_dirty = false;

void emu_set_rtc_mode(int mode)
{
   if (mode < 0) mode = 0;
   if (mode > 2) mode = 2;
   if (mode == g_rtc_mode) return;
   g_rtc_mode  = mode;
   /* The core only re-reads its options inside retro_run() when this
    * environment call reports a change. Without it a mode switch would sit
    * unused until the next time a game is loaded. */
   g_rtc_dirty = true;
}

int emu_get_rtc_mode(void)
{
   return g_rtc_mode;
}

/* ---- libretro environment callback -------------------------------- */
static bool env_cb(unsigned cmd, void *data)
{
   emu_frontend_t *emu = g_active;
   (void)emu;

   switch (cmd) {
   case RETRO_ENVIRONMENT_SET_PIXEL_FORMAT: {
      /* RGB565 matches Android's Bitmap.Config.RGB_565 directly, so no
       * conversion is needed when blitting into the SurfaceView. */
      int fmt = *(const int *)data;
      if (fmt != RETRO_PIXEL_FORMAT_RGB565)
         return false;                 /* ask the core to fall back */
      return true;
   }
   case RETRO_ENVIRONMENT_GET_CAN_DUPE:
      *(bool *)data = true;
      return true;
   case RETRO_ENVIRONMENT_GET_VARIABLE_UPDATE:
      if (g_rtc_dirty) {
         *(bool *)data = true;
         g_rtc_dirty = false;      /* one-shot: only report the change once */
         return true;
      }
      return false;
   case RETRO_ENVIRONMENT_GET_VARIABLE: {
      struct retro_variable *var = data;
      /* Keep the core defaults; the meaningful knobs (frameskip) are
       * applied by this frontend rather than through core options. */
      if (var->key && !strcmp(var->key, "vbanext_frameskip"))
         var->value = "0";
      else if (var->key && !strcmp(var->key, "vbanext_threaded_renderer"))
         var->value = "disabled";
      else if (var->key && !strcmp(var->key, "vbanext_rtc"))
         /* "auto" defers to the core's per-ROM table, which is what left most
          * games without a clock. */
         var->value = (g_rtc_mode == 1) ? "enabled"
                    : (g_rtc_mode == 2) ? "disabled" : "auto";
      else
         return false;
      return true;
   }
   case RETRO_ENVIRONMENT_GET_SYSTEM_DIRECTORY:
      if (emu && emu->save_dir[0])
         *(const char **)data = emu->save_dir;
      else
         return false;
      return true;
   case RETRO_ENVIRONMENT_GET_LOG_INTERFACE: {
      struct retro_log_callback *cb = data;
      /* No per-level Android plumbing here; native-lib.cpp re-logs via
       * the frontend's log hook if one is installed. */
      cb->log = NULL;
      return false;
   }
   default:
      return false;
   }
}

/* ---- libretro video / audio callbacks ----------------------------- */
static void video_cb(const void *data, unsigned width, unsigned height,
                     size_t pitch)
{
   emu_frontend_t *emu = g_active;
   if (!emu || !data)
      return;

   unsigned h = height < GBA_SCREEN_H ? height : GBA_SCREEN_H;
   unsigned w = width  < GBA_SCREEN_W ? width  : GBA_SCREEN_W;
   const uint8_t *src = data;
   uint8_t *dst = (uint8_t *)emu->framebuf;
   unsigned y;

   for (y = 0; y < h; y++)
      memcpy(dst + y * GBA_SCREEN_W * 2, src + y * pitch, w * 2);

   emu->got_frame = 1;
}

static void audio_sample_cb(int16_t left, int16_t right)
{
   emu_frontend_t *emu = g_active;
   if (!emu)
      return;
   if (emu->audio_count < AUDIO_RING_FRAMES) {
      int i = emu->audio_head;
      emu->audio_ring[i * 2 + 0] = left;
      emu->audio_ring[i * 2 + 1] = right;
      emu->audio_head = (i + 1) % AUDIO_RING_FRAMES;
      emu->audio_count++;
   }
}

static size_t audio_batch_cb(const int16_t *data, size_t frames)
{
   emu_frontend_t *emu = g_active;
   size_t n;
   if (!emu || !data)
      return frames;

   n = frames;
   if (n > (size_t)(AUDIO_RING_FRAMES - emu->audio_count))
      n = (size_t)(AUDIO_RING_FRAMES - emu->audio_count);

   for (size_t i = 0; i < n; i++) {
      int p = emu->audio_head;
      emu->audio_ring[p * 2 + 0] = data[i * 2 + 0];
      emu->audio_ring[p * 2 + 1] = data[i * 2 + 1];
      emu->audio_head = (p + 1) % AUDIO_RING_FRAMES;
   }
   emu->audio_count += (int)n;
   return frames;
}

static void input_poll_cb(void) { }

static int16_t input_state_cb(unsigned port, unsigned device,
                              unsigned index, unsigned id)
{
   emu_frontend_t *emu = g_active;
   (void)index;
   if (!emu || port != 0 || device != RETRO_DEVICE_JOYPAD)
      return 0;
   return (emu->input_mask >> id) & 1;
}

/* ---- public API --------------------------------------------------- */

emu_frontend_t *emu_init(const uint8_t *rom_data, size_t rom_size,
                         const emu_config_t *cfg)
{
   emu_frontend_t *emu;
   struct retro_system_av_info av;
   struct retro_game_info gi;

   if (!rom_data || rom_size == 0)
      return NULL;

   bind_core();

   emu = (emu_frontend_t *)calloc(1, sizeof(*emu));
   if (!emu)
      return NULL;

   if (cfg) {
      if (cfg->save_dir) snprintf(emu->save_dir, sizeof(emu->save_dir), "%s", cfg->save_dir);
      if (cfg->rom_name) snprintf(emu->rom_name, sizeof(emu->rom_name), "%s", cfg->rom_name);
      emu->log = cfg->log;
      emu->frameskip = cfg->frameskip < 0 ? 0 : cfg->frameskip;
   }
   if (!emu->rom_name[0])
      snprintf(emu->rom_name, sizeof(emu->rom_name), "rom");
   if (emu->save_dir[0])
      snprintf(emu->sav_path, sizeof(emu->sav_path), "%s/%s.sav",
               emu->save_dir, emu->rom_name);

   g_active = emu;

   f_set_environment(env_cb);
   f_set_video_refresh(video_cb);
   f_set_audio_sample(audio_sample_cb);
   f_set_audio_sample_batch(audio_batch_cb);
   f_set_input_poll(input_poll_cb);
   f_set_input_state(input_state_cb);
   f_init();

   memset(&gi, 0, sizeof(gi));
   gi.data = rom_data;
   gi.size = rom_size;
   gi.path = emu->rom_name;

   if (!f_load_game(&gi)) {
      emu_log(emu, "load_game failed for '%s'", emu->rom_name);
      f_deinit();
      g_active = NULL;
      free(emu);
      return NULL;
   }

   f_get_system_av_info(&av);
   emu->fps = av.timing.fps > 1.0 ? av.timing.fps : 59.7275;

   emu->sram_data = f_get_memory_data(RETRO_MEMORY_SAVE_RAM);
   emu->sram_size = f_get_memory_size(RETRO_MEMORY_SAVE_RAM);
   emu->state_size = f_serialize_size();
   if (emu->state_size)
      emu->state_buf = malloc(emu->state_size);

   emu_log(emu, "loaded '%s' (%u bytes), %.2f fps, sram %u bytes",
           emu->rom_name, (unsigned)rom_size, emu->fps,
           (unsigned)emu->sram_size);
   return emu;
}


void emu_destroy(emu_frontend_t **handle)
{
   emu_frontend_t *emu;

   if (!handle || !*handle)
      return;

   /* Take the handle first: the core is a process-wide singleton and every
    * callback below still routes through g_active, so it must stay valid
    * until after retro_deinit() has run. */
   emu = *handle;
   *handle = NULL;
   g_active = emu;

   f_unload_game();
   f_deinit();

   g_active = NULL;
   free(emu->state_buf);
   free(emu);
}

void emu_reset(emu_frontend_t *emu)
{
   if (!emu)
      return;
   g_active = emu;
   f_reset();
   emu->audio_count = 0;
   emu->audio_head = 0;
}

static void push_audio_timing(emu_frontend_t *emu)
{
   struct timespec now;
   clock_gettime(CLOCK_MONOTONIC, &now);
   emu->last_frame_time = now;
   emu->have_last_time = 1;
}


int emu_run_frame(emu_frontend_t *emu, uint32_t input_mask)
{
   if (!emu)
      return 0;

   g_active = emu;
   emu->input_mask = input_mask;
   emu->got_frame = 0;

   /* Frameskip: keep emulating (audio/timing stay correct) but only let
    * the core's frame reach the display every N+1th time. */
   if (emu->frameskip > 0 && emu->skip_counter < emu->frameskip) {
      emu->skip_counter++;
      /* still run the frame, just don't publish it */
      f_run();
      push_audio_timing(emu);
      return 0;
   }
   emu->skip_counter = 0;

   {
      int guard = 0;
      do {
         f_run();
         guard++;
      } while (!emu->got_frame && guard < 8);
   }

   push_audio_timing(emu);
   return emu->got_frame;
}

long emu_frame_delay_us(emu_frontend_t *emu)
{
   struct timespec now;
   double elapsed, target;
   if (!emu || !emu->have_last_time)
      return 0;

   clock_gettime(CLOCK_MONOTONIC, &now);
   elapsed = (now.tv_sec - emu->last_frame_time.tv_sec) * 1e6
           + (now.tv_nsec - emu->last_frame_time.tv_nsec) / 1e3;
   target = 1e6 / emu->fps;
   if (elapsed >= target)
      return 0;
   return (long)(target - elapsed);
}

const uint16_t *emu_get_framebuffer(emu_frontend_t *emu)
{
   return emu ? emu->framebuf : NULL;
}

int emu_audio_drain(emu_frontend_t *emu, int16_t *dst, int max_frames)
{
   int n, i, tail;
   if (!emu || !dst || max_frames <= 0)
      return 0;

   n = emu->audio_count < max_frames ? emu->audio_count : max_frames;
   tail = (emu->audio_head - emu->audio_count + AUDIO_RING_FRAMES)
          % AUDIO_RING_FRAMES;

   for (i = 0; i < n; i++) {
      int p = (tail + i) % AUDIO_RING_FRAMES;
      dst[i * 2 + 0] = emu->audio_ring[p * 2 + 0];
      dst[i * 2 + 1] = emu->audio_ring[p * 2 + 1];
   }
   emu->audio_count -= n;
   return n;
}

void emu_audio_flush(emu_frontend_t *emu)
{
   if (!emu)
      return;
   emu->audio_count = 0;
   emu->audio_head = 0;
}

int emu_save_battery(emu_frontend_t *emu)
{
   FILE *fp;
   if (!emu || !emu->sram_data || !emu->sram_size || !emu->sav_path[0])
      return 0;

   fp = fopen(emu->sav_path, "wb");
   if (!fp)
      return 0;
   if (fwrite(emu->sram_data, 1, emu->sram_size, fp) != emu->sram_size) {
      fclose(fp);
      return 0;
   }
   fclose(fp);
   return 1;
}

int emu_load_battery(emu_frontend_t *emu)
{
   FILE *fp;
   size_t got;
   if (!emu || !emu->sram_data || !emu->sram_size || !emu->sav_path[0])
      return 0;

   fp = fopen(emu->sav_path, "rb");
   if (!fp)
      return 0;
   got = fread(emu->sram_data, 1, emu->sram_size, fp);
   fclose(fp);
   return got > 0;
}

static void state_path(emu_frontend_t *emu, char *out, size_t n, int slot)
{
   snprintf(out, n, "%s/%s.state%d", emu->save_dir, emu->rom_name, slot);
}

int emu_save_state(emu_frontend_t *emu, int slot)
{
   char path[800];
   FILE *fp;
   if (!emu || !emu->state_buf || !emu->state_size || slot < 0 || slot > 9)
      return -1;
   if (!emu->save_dir[0])
      return -1;

   g_active = emu;
   if (!f_serialize(emu->state_buf, emu->state_size))
      return -1;

   state_path(emu, path, sizeof(path), slot);
   fp = fopen(path, "wb");
   if (!fp)
      return -1;
   if (fwrite(emu->state_buf, 1, emu->state_size, fp) != emu->state_size) {
      fclose(fp);
      return -1;
   }
   fclose(fp);
   emu_log(emu, "saved state slot %d -> %s", slot, path);
   return 0;
}

int emu_load_state(emu_frontend_t *emu, int slot)
{
   char path[800];
   FILE *fp;
   size_t got;
   if (!emu || !emu->state_buf || !emu->state_size || slot < 0 || slot > 9)
      return -1;
   if (!emu->save_dir[0])
      return -1;

   state_path(emu, path, sizeof(path), slot);
   fp = fopen(path, "rb");
   if (!fp)
      return -1;
   got = fread(emu->state_buf, 1, emu->state_size, fp);
   fclose(fp);
   if (got != emu->state_size)
      return -1;

   g_active = emu;
   if (!f_unserialize(emu->state_buf, emu->state_size))
      return -1;
   emu_audio_flush(emu);
   emu_log(emu, "loaded state slot %d <- %s", slot, path);
   return 0;
}

double emu_get_fps(emu_frontend_t *emu)
{
   return emu ? emu->fps : 0.0;
}

const char *emu_get_core_name(void)
{
   static char name[128] = "";
   struct retro_system_info info;
   if (!name[0]) {
      bind_core();
      memset(&info, 0, sizeof(info));
      f_get_system_info(&info);
      snprintf(name, sizeof(name), "%s",
               info.library_name ? info.library_name : "WaveGBA");
   }
   return name;
}

const char *emu_get_core_version(void)
{
   static char ver[128] = "";
   struct retro_system_info info;
   if (!ver[0]) {
      bind_core();
      memset(&info, 0, sizeof(info));
      f_get_system_info(&info);
      snprintf(ver, sizeof(ver), "%s",
               info.library_version ? info.library_version : "");
   }
   return ver;
}
