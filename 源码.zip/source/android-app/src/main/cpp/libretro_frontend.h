/* WaveGBA -- native emulation frontend
 * Author: Edag
 *
 * Platform-independent layer that drives the vba-next libretro core.
 * It contains no Android/JNI dependency so it can be compiled and tested
 * on the desktop; native-lib.cpp is a thin JNI wrapper on top of it.
 */
#ifndef LIBRETRO_FRONTEND_H
#define LIBRETRO_FRONTEND_H

#include <stdint.h>
#include <stddef.h>

#ifdef __cplusplus
extern "C" {
#endif

/* GBA button mask -- bit position matches the libretro joypad id so the
 * value can be handed to the core's input_state callback unchanged. */
#define GBA_BTN_A        (1u << 8)
#define GBA_BTN_B        (1u << 0)
#define GBA_BTN_SELECT   (1u << 2)
#define GBA_BTN_START    (1u << 3)
#define GBA_BTN_RIGHT    (1u << 7)
#define GBA_BTN_LEFT     (1u << 6)
#define GBA_BTN_UP       (1u << 4)
#define GBA_BTN_DOWN     (1u << 5)
/* Must match the libretro joypad ids: JOYPAD_L = 10, JOYPAD_R = 11. The
 * frontend hands the mask to the core as raw joypad ids, not as GBA bits. */
#define GBA_BTN_L        (1u << 10)
#define GBA_BTN_R        (1u << 11)

/* Screen geometry of the GBA. */
#define GBA_SCREEN_W     240
#define GBA_SCREEN_H     160

/* Native audio rate the core produces. */
#define GBA_SAMPLE_RATE  32000

/* Opaque emulator instance. */
typedef struct emu_frontend emu_frontend_t;

/* Logging hook; defaults to a no-op. */
typedef void (*emu_log_fn)(int level, const char *msg);

typedef struct {
   const char *save_dir;      /* directory for .sav and state files */
   const char *rom_name;      /* base name used for save files */
   emu_log_fn  log;           /* optional */
   int         frameskip;     /* 0 = draw every frame, N = skip N of N+1 */
} emu_config_t;

/* Lifecycle ---------------------------------------------------------- */

/* Load a ROM image already in memory. Returns NULL on failure. */
emu_frontend_t *emu_init(const uint8_t *rom_data, size_t rom_size,
                         const emu_config_t *cfg);

void emu_destroy(emu_frontend_t **emu);

/* Reset the machine (like pressing the console reset). */
void emu_reset(emu_frontend_t *emu);

/* Running ------------------------------------------------------------ */

/* Real-time clock mode: 0 = auto, 1 = always on, 2 = off.
 * Only meaningful for cartridges that actually have an RTC; harmless for the
 * rest. Takes effect from the next frame. */
void emu_set_rtc_mode(int mode);
int  emu_get_rtc_mode(void);

/* Emulate one frame. `input_mask` is a GBA_BTN_* combination.
 * Returns 1 when a new video frame was produced, 0 when it was skipped
 * (frameskip). The audio produced is appended to the internal ring buffer
 * and must be drained with emu_audio_drain(). */
int emu_run_frame(emu_frontend_t *emu, uint32_t input_mask);

/* Frame pacing helper: microseconds to sleep to hold ~59.73 fps.
 * Returns 0 when the emulator is running ahead of real time already. */
long emu_frame_delay_us(emu_frontend_t *emu);

/* Video -------------------------------------------------------------- */

/* Returns a tightly packed 240x160 RGB565 buffer (480 pixels * 2 bytes
 * per row, no stride). Valid until the next emu_run_frame(). */
const uint16_t *emu_get_framebuffer(emu_frontend_t *emu);

/* Audio -------------------------------------------------------------- */

/* Copy up to max_frames stereo frames (2 int16 each) out of the ring
 * buffer. Returns the number of frames written. */
int emu_audio_drain(emu_frontend_t *emu, int16_t *dst, int max_frames);

/* Drop pending audio (used when resuming from pause). */
void emu_audio_flush(emu_frontend_t *emu);

/* Save data ---------------------------------------------------------- */

/* Cartridge battery save (SRAM/EEPROM/Flash). emu_save_battery() flushes
 * to <save_dir>/<rom_name>.sav ; emu_load_battery() restores it. */
int emu_save_battery(emu_frontend_t *emu);
int emu_load_battery(emu_frontend_t *emu);

/* Instant save states, slot 0..9.  0 on success, -1 on failure. */
int emu_save_state(emu_frontend_t *emu, int slot);

int emu_load_state(emu_frontend_t *emu, int slot);

/* Info --------------------------------------------------------------- */

double emu_get_fps(emu_frontend_t *emu);
const char *emu_get_core_name(void);
const char *emu_get_core_version(void);

#ifdef __cplusplus
}
#endif

#endif /* LIBRETRO_FRONTEND_H */
