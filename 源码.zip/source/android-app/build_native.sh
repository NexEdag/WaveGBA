#!/bin/bash
# Build libwavegba.so for all Android ABIs using the NDK toolchain directly.
#
# CRITICAL: native-lib.cpp (the JNI bridge) MUST be in the source list.
# If it is missing the .so links fine but exports zero Java_* symbols, and
# the app dies with UnsatisfiedLinkError the moment the first native call
# happens (i.e. right after picking a ROM). verify() below guards that.
set -e
ulimit -f unlimited 2>/dev/null || true

NDK=${NDK:-/opt/android-sdk/android-ndk-r27c}
TOOL=$NDK/toolchains/llvm/prebuilt/linux-x86_64
ROOT=/data/workspace/WaveGBA/source/android-app
CPP=$ROOT/src/main/cpp
OUT=/data/workspace/WaveGBA/build/native
API=23

DEFS="-D__LIBRETRO__ -DHAVE_HLE_BIOS -DINLINE=inline -DFRONTEND_SUPPORTS_RGB565 \
-DLOAD_FROM_MEMORY -DTILED_RENDERING -DHAVE_STDINT_H -DHAVE_INTTYPES_H -DNDEBUG -DANDROID"
INCS="-I$CPP -I$CPP/core/src -I$CPP/core/libretro-common/include"
CFLAGS="-O3 -fPIC -ffast-math -fno-math-errno -fno-strict-aliasing -fvisibility=hidden"

CORE_SRC="
$CPP/core/src/gba.c
$CPP/core/src/memory.c
$CPP/core/src/sound.c
$CPP/core/src/system.c
$CPP/core/libretro/libretro.c
$CPP/libretro_frontend.c
"
COMMON_SRC=$(find "$CPP/core/libretro-common" -name '*.c' | grep -vE 'rthreads|neon')

build_abi () {
    abi=$1; cc=$2; cxx=$3
    echo "=== $abi ==="
    objdir=$OUT/obj/$abi
    rm -rf "$objdir"; mkdir -p "$objdir" "$OUT/$abi"

    for f in $CORE_SRC $COMMON_SRC; do
        n=$(echo "$f" | sed "s|$CPP/||; s|/|_|g; s|\.c$||")
        $cc $DEFS $INCS $CFLAGS -c "$f" -o "$objdir/$n.o"
    done

    # The JNI bridge. -static-libstdc++ keeps libc++_shared.so out of the
    # dependency list so the APK needs no extra runtime .so.
    $cxx $DEFS $INCS -std=c++17 $CFLAGS -fexceptions -frtti \
        -c "$CPP/native-lib.cpp" -o "$objdir/native-lib.o"

    # -static-libstdc++ bakes the C++ runtime in so the APK does not need
    # to ship libc++_shared.so.
    $cc -shared -static-libstdc++ -o "$OUT/$abi/libwavegba.so" "$objdir"/*.o \
        -llog -ljnigraphics -landroid -lm -lz -latomic
    $TOOL/bin/llvm-strip "$OUT/$abi/libwavegba.so"
    echo "  -> $(stat -c%s "$OUT/$abi/libwavegba.so") bytes"
}

build_abi arm64-v8a   "$TOOL/bin/aarch64-linux-android${API}-clang"   "$TOOL/bin/aarch64-linux-android${API}-clang++"
build_abi armeabi-v7a "$TOOL/bin/armv7a-linux-androideabi${API}-clang" "$TOOL/bin/armv7a-linux-androideabi${API}-clang++"
build_abi x86_64      "$TOOL/bin/x86_64-linux-android${API}-clang"      "$TOOL/bin/x86_64-linux-android${API}-clang++"

echo
echo "== verifying JNI symbols =="
# Every native method declared in NativeBridge.java must exist in the .so,
# otherwise the app crashes on the first call instead of failing here.
declared=$(grep -oE 'native [A-Za-z]+[[:space:]]+[A-Za-z]+ *\(' \
           "$ROOT/src/main/java/com/wavegba/NativeBridge.java" | wc -l)
for abi in arm64-v8a armeabi-v7a x86_64; do
    n=$($TOOL/bin/llvm-nm -D --defined-only "$OUT/$abi/libwavegba.so" | grep -c 'Java_com_wavegba_NativeBridge_' || true)
    echo "  $abi: $n Java_* symbols (java declares $declared native methods)"
    if [ "$n" -lt "$declared" ]; then
        echo "  ERROR: $abi is missing JNI symbols - native-lib.cpp was not linked!"
        exit 1
    fi
done

echo "== checking for unwanted shared-lib deps =="
for abi in arm64-v8a armeabi-v7a x86_64; do
    d=$($TOOL/bin/llvm-readelf -d "$OUT/$abi/libwavegba.so" | grep NEEDED | \
        sed 's/.*\[\(.*\)\]/\1/' | tr '\n' ' ')
    echo "  $abi needs: $d"
done

echo "native build OK"
