/* WaveGBA -- PC frontend (SDL2)
 * Author: Edag
 *
 * Desktop host for the same core used by the Android build. Reuses
 * libretro_frontend.c verbatim, so the emulation behaviour is identical
 * across PC and phone.
 *
 * Build:  see pc/Makefile
 * Run:    ./WaveGBA <rom.gba>
 *
 * Keys:
 *   Arrows / Z X A S Q W      GBA d-pad, B A, L R, Select Start
 *   Enter                     Start
 *   Space                     pause
 *   1 2 3 4 5 6               speed 0.5x 1x 1.5x 2x 3x 4x
 *   F1                        help overlay
 *   F5 / F7                   save / load state slot 0
 *   F2                        write battery save (.sav)
 *   Esc                       quit
 *   Drag a .gba onto the window to load it
 */
#include <SDL.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>
#include <time.h>

#include "libretro_frontend.h"

#define BASE_FPS 59.7275
#define MAX_CATCHUP 6
#define MUTE_ABOVE 2.0

static const double SPEEDS[] = {0.5, 1.0, 1.5, 2.0, 3.0, 4.0};
static const int NSPEEDS = (int)(sizeof(SPEEDS) / sizeof(SPEEDS[0]));

static SDL_Window *g_win = NULL;
static SDL_Renderer *g_ren = NULL;
static SDL_Texture *g_tex = NULL;
static SDL_AudioDeviceID g_audio = 0;

static emu_frontend_t *g_emu = NULL;
static char g_rom_path[1024];
static char g_save_dir[1024];
static char g_rom_name[256];

static volatile double g_speed = 1.0;
static volatile int g_paused = 0;
static volatile int g_quit = 0;
static int g_show_help = 0;

/* ------------------------------------------------------------------ audio */
static void audio_cb(void *userdata, Uint8 *stream, int len)
{
   static int16_t tmp[4096];
   int want = len / 4;                    /* stereo frames of int16 */
   int got = 0;
   (void)userdata;

   if (want > 4096) want = 4096;
   if (g_emu) got = emu_audio_drain(g_emu, tmp, want);

   double sp = g_speed;
   if (g_paused || got <= 0 || sp >= MUTE_ABOVE) {
      memset(stream, 0, len);
      return;
   }

   /* resample so pitch stays constant: sp>1 decimates, sp<1 repeats */
   int out = 0;
   for (double idx = 0; idx < got && out < want; idx += sp) {
      int16_t l = tmp[(int)idx * 2];
      int16_t r = tmp[(int)idx * 2 + 1];
      tmp[out * 2] = l; tmp[out * 2 + 1] = r;
      out++;
   }
   memcpy(stream, tmp, out * 4);
   if (out * 4 < len) memset(stream + out * 4, 0, len - out * 4);
}

/* ------------------------------------------------------------------ paths */
static const char *base_name(const char *p)
{
   const char *s = strrchr(p, '/');
#ifdef _WIN32
   const char *b = strrchr(p, '\\');
   if (b && (!s || b > s)) s = b;
#endif
   return s ? s + 1 : p;
}

static void strip_ext(char *dst, size_t n, const char *name)
{
   const char *dot;
   snprintf(dst, n, "%s", name);
   dot = strrchr(dst, '.');
   if (dot) *((char *)dot) = '\0';
   for (char *c = dst; *c; c++)
      if (!((*c >= 'A' && *c <= 'Z') || (*c >= 'a' && *c <= 'z') ||
            (*c >= '0' && *c <= '9') || *c == '_' || *c == '-')) *c = '_';
}

/* ------------------------------------------------------------------- load */
static uint8_t *read_file(const char *path, size_t *size)
{
   FILE *f = fopen(path, "rb");
   uint8_t *buf; long n;
   if (!f) return NULL;
   fseek(f, 0, SEEK_END); n = ftell(f); fseek(f, 0, SEEK_SET);
   buf = malloc(n > 0 ? n : 1);
   if (!buf) { fclose(f); return NULL; }
   if (fread(buf, 1, n, f) != (size_t)n) { fclose(f); free(buf); return NULL; }
   fclose(f);
   *size = (size_t)n;
   return buf;
}

static int load_rom(const char *path)
{
   size_t size = 0;
   uint8_t *data = read_file(path, &size);
   emu_config_t cfg;
   int ok;

   if (!data) { fprintf(stderr, "cannot read: %s\n", path); return 0; }
   if (size < 0x200) { fprintf(stderr, "not a GBA rom: %s\n", path); free(data); return 0; }

   emu_destroy(&g_emu);
   memset(&cfg, 0, sizeof(cfg));
   cfg.save_dir = g_save_dir;
   strip_ext(g_rom_name, sizeof(g_rom_name), base_name(path));
   cfg.rom_name = g_rom_name;

   g_emu = emu_init(data, size, &cfg);
   free(data);
   ok = g_emu != NULL;
   if (ok) {
      snprintf(g_rom_path, sizeof(g_rom_path), "%s", path);
      emu_load_battery(g_emu);
      printf("loaded: %s (%zu bytes)\n", path, size);
   }
   return ok;
}

/* ------------------------------------------------------------------ input */
/* Keyboard state is polled once per frame: this keeps held keys working even
 * when the OS sends repeated keydown events only for the first press. */
static uint32_t poll_keys(void)
{
   const Uint8 *st = SDL_GetKeyboardState(NULL);
   uint32_t m = 0;
   if (st[SDL_SCANCODE_LEFT]   || st[SDL_SCANCODE_A]) m |= GBA_BTN_LEFT;
   if (st[SDL_SCANCODE_RIGHT]  || st[SDL_SCANCODE_D]) m |= GBA_BTN_RIGHT;
   if (st[SDL_SCANCODE_UP]     || st[SDL_SCANCODE_W]) m |= GBA_BTN_UP;
   if (st[SDL_SCANCODE_DOWN]   || st[SDL_SCANCODE_S]) m |= GBA_BTN_DOWN;
   if (st[SDL_SCANCODE_Z]      || st[SDL_SCANCODE_J]) m |= GBA_BTN_B;
   if (st[SDL_SCANCODE_X]      || st[SDL_SCANCODE_K]) m |= GBA_BTN_A;
   if (st[SDL_SCANCODE_Q]      || st[SDL_SCANCODE_U]) m |= GBA_BTN_L;
   if (st[SDL_SCANCODE_E]      || st[SDL_SCANCODE_I]) m |= GBA_BTN_R;
   if (st[SDL_SCANCODE_RSHIFT] || st[SDL_SCANCODE_LSHIFT] || st[SDL_SCANCODE_BACKSPACE])
      m |= GBA_BTN_SELECT;
   if (st[SDL_SCANCODE_RETURN]) m |= GBA_BTN_START;
   return m;
}

/* ------------------------------------------------------------------- help */
static void draw_help(void)
{
   /* Cheap on-screen legend drawn with SDL primitives so no font asset is
    * needed: a translucent panel with a few labelled bars. */
   SDL_Rect panel = {20, 20, 380, 200};
   SDL_SetRenderDrawBlendMode(g_ren, SDL_BLENDMODE_BLEND);
   SDL_SetRenderDrawColor(g_ren, 0, 0, 0, 200);
   SDL_RenderFillRect(g_ren, &panel);
   SDL_SetRenderDrawColor(g_ren, 255, 255, 255, 255);
   SDL_RenderDrawRect(g_ren, &panel);

   /* a simple "F1 = help" glyph: three horizontal bars */
   for (int i = 0; i < 3; i++) {
      SDL_Rect bar = {40, 50 + i * 40, 300 - i * 60, 14};
      SDL_SetRenderDrawColor(g_ren, 90, 200, 255, 255);
      SDL_RenderFillRect(g_ren, &bar);
   }
}

int main(int argc, char **argv)
{
   const char *rom = (argc > 1) ? argv[1] : NULL;
   int bench_frames = 0;                 /* >0 = run N frames headless and exit */
   const char *home;
   Uint32 last = 0, frames_drawn = 0;
   Uint32 fps_timer = 0; int fps_frames = 0; double fps = 0.0;
   double accum = 0.0;
   char title[256];

   printf("WaveGBA -- %s %s\n", emu_get_core_name(), emu_get_core_version());
   printf("author: Edag\n\n");

   home = getenv("HOME");
   snprintf(g_save_dir, sizeof(g_save_dir), "%s/.wavegba", home ? home : ".");
#ifdef _WIN32
   mkdir(g_save_dir);
#else
   { char cmd[1200]; snprintf(cmd, sizeof(cmd), "mkdir -p \"%s\" 2>/dev/null", g_save_dir); if (system(cmd)) {} }
#endif

   for (int i = 1; i < argc; i++)
      if (!strcmp(argv[i], "--frames") && i + 1 < argc) bench_frames = atoi(argv[++i]);

   if (!rom) {
      printf("usage: %s <rom.gba>\n", argv[0]);
      printf("drag a .gba file onto the window, or pass it on the command line\n");
      return 1;
   }
   if (!load_rom(rom)) return 1;

   /* Headless self-test: drive the core directly and report, no window. */
   if (bench_frames > 0) {
      uint32_t mask = 0;
      struct timespec t0, t1;
      const uint16_t *fb;
      int lit = 0;
      long audio = 0;
      static int16_t tmp[8192];
      clock_gettime(CLOCK_MONOTONIC, &t0);
      for (int i = 0; i < bench_frames; i++) {
         emu_run_frame(g_emu, mask);
         audio += emu_audio_drain(g_emu, tmp, 4096);
      }
      clock_gettime(CLOCK_MONOTONIC, &t1);
      fb = emu_get_framebuffer(g_emu);
      for (int i = 0; i < GBA_SCREEN_W * GBA_SCREEN_H; i++) if (fb[i]) lit++;
      double secs = (t1.tv_sec - t0.tv_sec) + (t1.tv_nsec - t0.tv_nsec) / 1e9;
      printf("frames        : %d\n", bench_frames);
      printf("elapsed       : %.3f s\n", secs);
      printf("fps           : %.1f (%.1fx realtime)\n", bench_frames / secs,
             (bench_frames / secs) / BASE_FPS);
      printf("nonblack px   : %d / %d\n", lit, GBA_SCREEN_W * GBA_SCREEN_H);
      printf("audio frames  : %ld\n", audio);
      printf("save state    : %s\n", emu_save_state(g_emu, 0) == 0 ? "ok" : "FAILED");
      printf("load state    : %s\n", emu_load_state(g_emu, 0) == 0 ? "ok" : "FAILED");
      emu_destroy(&g_emu);
      return (lit > 0 && audio > 0) ? 0 : 2;
   }

   if (SDL_Init(SDL_INIT_VIDEO | SDL_INIT_AUDIO) != 0) {
      fprintf(stderr, "SDL_Init: %s\n", SDL_GetError());
      return 1;
   }

   g_win = SDL_CreateWindow("WaveGBA", SDL_WINDOWPOS_CENTERED, SDL_WINDOWPOS_CENTERED,
                            GBA_SCREEN_W * 3, GBA_SCREEN_H * 3,
                            SDL_WINDOW_RESIZABLE | SDL_WINDOW_ALLOW_HIGHDPI);
   if (!g_win) { fprintf(stderr, "window: %s\n", SDL_GetError()); return 1; }

   g_ren = SDL_CreateRenderer(g_win, -1, SDL_RENDERER_ACCELERATED | SDL_RENDERER_PRESENTVSYNC);
   if (!g_ren) g_ren = SDL_CreateRenderer(g_win, -1, SDL_RENDERER_SOFTWARE);
   if (!g_ren) { fprintf(stderr, "renderer: %s\n", SDL_GetError()); return 1; }
   SDL_SetHint(SDL_HINT_RENDER_SCALE_QUALITY, "linear");
   SDL_RenderSetLogicalSize(g_ren, GBA_SCREEN_W, GBA_SCREEN_H);

   /* RGB565 is the exact format the core emits, so the texture takes the
    * framebuffer with no conversion. */
   g_tex = SDL_CreateTexture(g_ren, SDL_PIXELFORMAT_RGB565,
                             SDL_TEXTUREACCESS_STREAMING,
                             GBA_SCREEN_W, GBA_SCREEN_H);
   if (!g_tex) { fprintf(stderr, "texture: %s\n", SDL_GetError()); return 1; }

   {
      SDL_AudioSpec want, have;
      SDL_zero(want);
      want.freq = GBA_SAMPLE_RATE;
      want.format = AUDIO_S16SYS;
      want.channels = 2;
      want.samples = 512;
      want.callback = audio_cb;
      g_audio = SDL_OpenAudioDevice(NULL, 0, &want, &have, SDL_AUDIO_ALLOW_FREQUENCY_CHANGE);
      if (g_audio == 0)
         fprintf(stderr, "audio unavailable: %s\n", SDL_GetError());
      else
         SDL_PauseAudioDevice(g_audio, 0);
   }

   SDL_EventState(SDL_DROPFILE, SDL_ENABLE);
   last = SDL_GetTicks();
   fps_timer = last;

   while (!g_quit) {
      SDL_Event e;
      Uint32 now;
      while (SDL_PollEvent(&e)) {
         if (e.type == SDL_QUIT) { g_quit = 1; break; }
         if (e.type == SDL_DROPFILE) {
            if (load_rom(e.drop.file)) {
               accum = 0;
               SDL_SetWindowTitle(g_win, (snprintf(title, sizeof(title),
                     "WaveGBA - %s", g_rom_name), title));
            }
            SDL_free(e.drop.file);
            continue;
         }
         if (e.type == SDL_KEYDOWN) {
            SDL_Keycode k = e.key.keysym.sym;
            if (k == SDLK_ESCAPE) { g_quit = 1; break; }
            if (k == SDLK_F1) g_show_help = !g_show_help;
            if (k == SDLK_p) g_paused = !g_paused;
            if (k >= SDLK_1 && k <= SDLK_6) {
               g_speed = SPEEDS[k - SDLK_1];
               accum = 0.0;
               printf("speed %.1fx%s\n", g_speed, g_speed >= MUTE_ABOVE ? " (muted)" : "");
            }
            if (k == SDLK_F5) { if (emu_save_state(g_emu, 0) == 0) printf("state saved\n"); }
            if (k == SDLK_F7) { if (emu_load_state(g_emu, 0) == 0) printf("state loaded\n"); }
            if (k == SDLK_F2) { if (emu_save_battery(g_emu) == 0) printf("battery saved\n"); }
            if (k == SDLK_F3) { emu_reset(g_emu); printf("reset\n"); }
         }
      }
      if (g_quit) break;

      now = SDL_GetTicks();
      {
         double elapsed = (now - last) / 1000.0;
         last = now;
         if (elapsed > 0.25) elapsed = 0.25;      /* do not avalanche after a stall */

         if (!g_paused) {
            accum += elapsed * BASE_FPS * g_speed;
            int frames = (int)accum;
            accum -= frames;
            if (frames > MAX_CATCHUP) frames = MAX_CATCHUP;
            uint32_t mask = poll_keys();
            for (int i = 0; i < frames; i++)
               emu_run_frame(g_emu, mask);
            if (frames > 0) frames_drawn++;
         }
      }

      /* present */
      {
         const uint16_t *fb = emu_get_framebuffer(g_emu);
         if (fb) SDL_UpdateTexture(g_tex, NULL, fb, GBA_SCREEN_W * 2);
      }
      SDL_RenderClear(g_ren);
      SDL_RenderCopy(g_ren, g_tex, NULL, NULL);
      if (g_show_help) draw_help();
      SDL_RenderPresent(g_ren);

      fps_frames++;
      if (now - fps_timer >= 1000) {
         fps = fps_frames * 1000.0 / (now - fps_timer);
         fps_frames = 0; fps_timer = now;
         snprintf(title, sizeof(title), "WaveGBA - %s - %.0f fps - %.1fx",
                  g_rom_name, fps, g_speed);
         SDL_SetWindowTitle(g_win, title);
      }
      (void)frames_drawn;
   }

   emu_save_battery(g_emu);
   emu_destroy(&g_emu);
   if (g_audio) SDL_CloseAudioDevice(g_audio);
   SDL_DestroyTexture(g_tex);
   SDL_DestroyRenderer(g_ren);
   SDL_DestroyWindow(g_win);
   SDL_Quit();
   return 0;
}
