/* JNI bridge: com.wavegba.NativeBridge <-> libretro_frontend.c
 *
 * The emulator core is a process-wide singleton (the libretro core keeps all
 * of its state in file-scope globals), so this layer keeps exactly one live
 * handle and every entry point serialises on g_lock.
 */
#include <jni.h>
#include <android/bitmap.h>
#include <android/log.h>
#include <pthread.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>

extern "C" {
#include "libretro_frontend.h"
}

#define LOGI(...) __android_log_print(ANDROID_LOG_INFO,  "WaveGBA", __VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, "WaveGBA", __VA_ARGS__)

static emu_frontend_t *g_emu = NULL;
static pthread_mutex_t g_lock = PTHREAD_MUTEX_INITIALIZER;

/* Env cache: the render thread calls in hot, so resolve jclass/method once. */
static JavaVM *g_vm = NULL;

extern "C" JNIEXPORT jint JNICALL JNI_OnLoad(JavaVM *vm, void *)
{
   g_vm = vm;
   return JNI_VERSION_1_6;
}

extern "C" JNIEXPORT void JNICALL JNI_OnUnload(JavaVM *, void *)
{
   pthread_mutex_lock(&g_lock);
   if (g_emu) { emu_destroy(&g_emu); g_emu = NULL; }
   pthread_mutex_unlock(&g_lock);
}

static void log_sink(int level, const char *msg)
{
   if (level >= 1) LOGE("%s", msg); else LOGI("%s", msg);
}

extern "C" JNIEXPORT jboolean JNICALL
Java_com_wavegba_NativeBridge_nativeInit(JNIEnv *env, jclass,
                                             jbyteArray rom,
                                             jstring saveDir,
                                             jstring romName,
                                             jint frameskip)
{
   pthread_mutex_lock(&g_lock);
   if (g_emu) { emu_destroy(&g_emu); g_emu = NULL; }

   emu_config_t cfg;
   memset(&cfg, 0, sizeof(cfg));

   /* cfg keeps borrowed pointers: the strings must stay alive until
    * emu_init() has copied them, so release only afterwards. */
   const char *sd = env->GetStringUTFChars(saveDir, NULL);
   const char *rn = env->GetStringUTFChars(romName, NULL);
   cfg.save_dir  = sd ? sd : "";
   cfg.rom_name  = rn ? rn : "rom";
   cfg.log       = log_sink;
   cfg.frameskip = frameskip;

   jsize   n   = env->GetArrayLength(rom);
   jbyte *buf  = env->GetByteArrayElements(rom, NULL);
   jboolean ok = JNI_FALSE;
   if (buf && n > 0) {
      g_emu = emu_init((const uint8_t *)buf, (size_t)n, &cfg);
      ok = g_emu ? JNI_TRUE : JNI_FALSE;
   }
   if (buf) env->ReleaseByteArrayElements(rom, buf, JNI_ABORT);
   if (sd) env->ReleaseStringUTFChars(saveDir, sd);
   if (rn) env->ReleaseStringUTFChars(romName, rn);

   LOGI("nativeInit rom=%d bytes frameskip=%d -> %s", (int)n, (int)frameskip,
        ok ? "ok" : "FAILED");
   pthread_mutex_unlock(&g_lock);
   return ok;
}

extern "C" JNIEXPORT void JNICALL
Java_com_wavegba_NativeBridge_nativeDestroy(JNIEnv *, jclass)
{
   pthread_mutex_lock(&g_lock);
   if (g_emu) { emu_destroy(&g_emu); g_emu = NULL; }
   pthread_mutex_unlock(&g_lock);
}

extern "C" JNIEXPORT jboolean JNICALL
Java_com_wavegba_NativeBridge_nativeRunFrame(JNIEnv *, jclass, jint buttons)
{
   pthread_mutex_lock(&g_lock);
   jboolean ok = JNI_FALSE;
   if (g_emu) { emu_run_frame(g_emu, (uint32_t)buttons); ok = JNI_TRUE; }
   pthread_mutex_unlock(&g_lock);
   return ok;
}

/* Copy the 240x160 RGB565 framebuffer into the Java Bitmap the view owns.
 * Returns false if the bitmap is not the expected size/format. */
extern "C" JNIEXPORT jboolean JNICALL
Java_com_wavegba_NativeBridge_nativeRender(JNIEnv *env, jclass, jobject bitmap)
{
   if (!bitmap) return JNI_FALSE;
   AndroidBitmapInfo info;
   if (AndroidBitmap_getInfo(env, bitmap, &info) != ANDROID_BITMAP_RESULT_SUCCESS)
      return JNI_FALSE;
   if (info.width != GBA_SCREEN_W || info.height != GBA_SCREEN_H)
      return JNI_FALSE;

   void *pixels = NULL;
   if (AndroidBitmap_lockPixels(env, bitmap, &pixels) != ANDROID_BITMAP_RESULT_SUCCESS)
      return JNI_FALSE;
   if (!pixels) { AndroidBitmap_unlockPixels(env, bitmap); return JNI_FALSE; }

   pthread_mutex_lock(&g_lock);
   if (g_emu) {
      const uint16_t *src = emu_get_framebuffer(g_emu);
      if (src) memcpy(pixels, src, (size_t)GBA_SCREEN_W * GBA_SCREEN_H * 2);
   }
   pthread_mutex_unlock(&g_lock);

   AndroidBitmap_unlockPixels(env, bitmap);
   return JNI_TRUE;
}

/* Drain audio into a Java short[]. Returns frames written (each frame is
 * 2 int16 = one stereo sample); the caller caps the array length. */
extern "C" JNIEXPORT jint JNICALL
Java_com_wavegba_NativeBridge_nativeAudioDrain(JNIEnv *env, jclass, jshortArray dst)
{
   if (!dst) return 0;
   jsize cap = env->GetArrayLength(dst);
   if (cap <= 0) return 0;

   jshort *buf = env->GetShortArrayElements(dst, NULL);
   if (!buf) return 0;

   size_t want = (size_t)(cap / 2);
   size_t got  = 0;
   pthread_mutex_lock(&g_lock);
   if (g_emu) got = emu_audio_drain(g_emu, (int16_t *)buf, want);
   pthread_mutex_unlock(&g_lock);

   env->ReleaseShortArrayElements(dst, buf, 0);
   return (jint)got;
}

extern "C" JNIEXPORT jint JNICALL
Java_com_wavegba_NativeBridge_nativeSaveState(JNIEnv *, jclass, jint slot)
{
   pthread_mutex_lock(&g_lock);
   int r = g_emu ? emu_save_state(g_emu, slot) : -1;
   pthread_mutex_unlock(&g_lock);
   return r;
}

extern "C" JNIEXPORT jint JNICALL
Java_com_wavegba_NativeBridge_nativeLoadState(JNIEnv *, jclass, jint slot)
{
   pthread_mutex_lock(&g_lock);
   int r = g_emu ? emu_load_state(g_emu, slot) : -1;
   pthread_mutex_unlock(&g_lock);
   return r;
}

extern "C" JNIEXPORT jint JNICALL
Java_com_wavegba_NativeBridge_nativeSaveBattery(JNIEnv *, jclass)
{
   pthread_mutex_lock(&g_lock);
   int r = g_emu ? emu_save_battery(g_emu) : -1;
   pthread_mutex_unlock(&g_lock);
   return r;
}

extern "C" JNIEXPORT jint JNICALL
Java_com_wavegba_NativeBridge_nativeLoadBattery(JNIEnv *, jclass)
{
   pthread_mutex_lock(&g_lock);
   int r = g_emu ? emu_load_battery(g_emu) : -1;
   pthread_mutex_unlock(&g_lock);
   return r;
}

extern "C" JNIEXPORT void JNICALL
Java_com_wavegba_NativeBridge_nativeReset(JNIEnv *, jclass)
{
   pthread_mutex_lock(&g_lock);
   if (g_emu) emu_reset(g_emu);
   pthread_mutex_unlock(&g_lock);
}

/* Frame-pacing hint in microseconds; the Java thread uses it as a sleep
 * target so we do not spin the CPU when the machine is way ahead of 60fps. */
extern "C" JNIEXPORT jint JNICALL
Java_com_wavegba_NativeBridge_nativeFrameDelayUs(JNIEnv *, jclass)
{
   pthread_mutex_lock(&g_lock);
   int d = g_emu ? (int)emu_frame_delay_us(g_emu) : 0;
   pthread_mutex_unlock(&g_lock);
   return d;
}

extern "C" JNIEXPORT jstring JNICALL
Java_com_wavegba_NativeBridge_nativeVersion(JNIEnv *env, jclass)
{
   return env->NewStringUTF("WaveGBA v1.0 - core: vba-next (opt) by Edag");
}
