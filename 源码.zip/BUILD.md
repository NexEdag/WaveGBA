# 构建说明

需要先准备 Android SDK（build-tools 34.0.0 + platform android-34）与 NDK r26d，
并把它们的路径填进构建脚本里。仓库里的脚本是在一个固定目录结构的沙箱里写的，
路径是硬编码的，换机器前需要先改这几处：

| 脚本 | 需要改的常量 |
|---|---|
| `build_full.sh` | `BT`（build-tools 路径）、`PJ`（android.jar 路径）、`cd` 到的工程目录 |
| `build_native.sh` | `NDK`（NDK 根目录）、`ROOT`（cpp 源码目录） |
| `sign_shm.sh` | `BT`、签名用的 keystore 路径 |

## 顺序

```bash
bash build_native.sh     # 三个 ABI 的 libwavegba.so
bash build_full.sh       # aapt2 -> javac -> d8 -> 打包
bash sign_shm.sh         # 签名 + zipalign
```

## 签名

仓库**不包含**签名密钥。用 `keytool` 自己生成一个，再填进 `sign_shm.sh`：

```bash
keytool -genkeypair -v -keystore my.jks -keyalg RSA -keysize 2048 \
        -validity 10000 -alias wavegba
```

## 关于 HAVE_NEON

核心里有三处 `#if HAVE_NEON` 调用 `neon_memcpy()`，但整个源码树没有这个函数的
实现，`gba.c` 也从未 include `neon.h`——所以构建脚本**不定义** `HAVE_NEON`。

这不是遗漏。补上实现后实测（详见 README）：`-O3` 已经把这几处 `memcpy` 自动展开
为 NEON 寄存器直写，手写版按指令数计反而更慢；端到端基准差值落在噪声内。
